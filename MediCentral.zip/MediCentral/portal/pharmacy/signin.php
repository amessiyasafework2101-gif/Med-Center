<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/username_format.php';
require_once dirname(__DIR__) . '/includes/auth_helpers.php';
require_once dirname(__DIR__) . '/includes/signin_handlers.php';
require_once dirname(__DIR__) . '/includes/signin_view.php';

mc_session_start();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
	mc_auth_redirect_if_logged_in($conn, 'pharmacy');
}

$error = '';
$uname_display = '';
$role = isset($_POST['role']) ? (string) $_POST['role'] : 'admin';
if (!in_array($role, ['admin', 'staff'], true)) {
	$role = 'admin';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
	$uname = isset($_POST['uname']) ? trim((string) $_POST['uname']) : '';
	$pwd = isset($_POST['pwd']) ? trim((string) $_POST['pwd']) : '';

	if ($uname === '' || $pwd === '') {
		$error = 'Enter both username and password to continue.';
		$uname_display = $uname !== '' ? mc_format_signin_username($uname) : '';
	} else {
		$uname_display = mc_format_signin_username($uname);
		$userNorm = mc_normalize_login_username($uname);

		if ($role === 'admin') {
			$result = mc_signin_attempt_admin($conn, $userNorm, $pwd);
			$error = $result['error'];
		} else {
			$result = mc_signin_attempt_pharmacist_pos($conn, $userNorm, $pwd);
			$error = $result['error'];
		}
	}
}

mc_render_signin_page([
	'portal' => 'pharmacy',
	'page_title' => 'Pharmacy operations · MediCentral',
	'badge' => 'Inventory & pharmacy management',
	'headline' => 'Run your pharmacy.',
	'headline_span' => 'Stock, sales, and control.',
	'blurb' => 'Sign in to manage inventory, barcodes, purchases, member orders, and the point-of-sale workspace for your location.',
	'card_title' => 'Operations sign in',
	'card_sub' => 'For pharmacy administrators and on-site staff assigned to a pharmacy. Staff accounts are created by your pharmacy admin.',
	'roles' => [
		['id' => 'roleAdmin', 'value' => 'admin', 'label' => 'Administrator', 'checked' => $role === 'admin'],
		['id' => 'roleStaff', 'value' => 'staff', 'label' => 'Staff / POS', 'checked' => $role === 'staff'],
	],
	'error' => $error,
	'uname_display' => $uname_display,
	'mini_link_html' => 'New pharmacy? <a href="register.php">Register pharmacy &amp; admin account</a>',
	'foot_html' => '<a href="../index.php">Network sign-in</a>',
	'switch_label' => '→ Network sign-in (members & pharmacists)',
	'switch_href' => '../index.php',
	'form_action' => '',
	'asset_prefix' => '../',
]);
