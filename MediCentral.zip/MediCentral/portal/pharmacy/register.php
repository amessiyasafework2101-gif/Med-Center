<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/username_format.php';
require_once dirname(__DIR__) . '/includes/auth_helpers.php';
require_once dirname(__DIR__) . '/includes/admin_chat.php';
require_once dirname(__DIR__) . '/includes/site_footer.php';
require_once dirname(__DIR__) . '/includes/site_nav.php';

mc_session_start();
mc_auth_redirect_if_logged_in($conn, 'pharmacy');

$error = '';
$success = '';
$v = static function (string $k) use (&$error): string {
	return htmlspecialchars((string) ($_POST[$k] ?? ''), ENT_QUOTES, 'UTF-8');
};

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_pharmacy'])) {
	$res = mc_register_pharmacy_admin($conn, $_POST);
	if ($res['ok']) {
		$success = (string) $res['msg'];
	} else {
		$error = (string) $res['msg'];
	}
}

$alertClass = $error !== '' ? 'mc-alert mc-show' : 'mc-alert';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register pharmacy · MediCentral</title>
	<link rel="stylesheet" href="../css/signin.css">
	<link rel="stylesheet" href="../css/signin-pharmacy.css">
	<link rel="stylesheet" href="../css/public-pages.css">
</head>
<body class="mc-pharmacy-signin mc-signin-has-nav">
	<header class="mc-pub-top mc-signin-top">
		<a href="../index.php" class="mc-pub-brand"><strong>MediCentral</strong></a>
		<?php mc_render_site_nav_bar('home', mc_site_nav_items('public', '../')); ?>
	</header>
	<div class="mc-wrap">
		<div class="mc-signin-shell" style="max-width:520px;margin:2rem auto;">
			<div class="mc-signin-card">
				<a class="mc-portal-switch" href="signin.php">← Back to operations sign-in</a>
				<h3 class="mc-title">Register your pharmacy</h3>
				<p class="mc-sub">Create your pharmacy profile and administrator account for inventory, sales, and messaging.</p>
				<?php if ($success !== ''): ?>
					<div class="mc-alert mc-show success" role="status"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?> <a href="signin.php">Sign in now</a></div>
				<?php endif; ?>
				<?php if ($error !== ''): ?>
					<div class="<?php echo $alertClass; ?>" role="alert"><span><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></span></div>
				<?php endif; ?>
				<?php if ($success === ''): ?>
				<form method="post" class="mc-reg-form">
					<input type="hidden" name="register_pharmacy" value="1">
					<p class="mc-reg-section">Pharmacy</p>
					<div class="mc-field"><input type="text" name="pharmacy_name" required placeholder=" " value="<?php echo $v('pharmacy_name'); ?>"><label class="mc-float-label">Pharmacy name</label></div>
					<div class="mc-field"><input type="text" name="city" placeholder=" " value="<?php echo $v('city'); ?>"><label class="mc-float-label">City</label></div>
					<div class="mc-field"><input type="text" name="address" placeholder=" " value="<?php echo $v('address'); ?>"><label class="mc-float-label">Address</label></div>
					<div class="mc-field"><input type="text" name="pharmacy_phone" placeholder=" " value="<?php echo $v('pharmacy_phone'); ?>"><label class="mc-float-label">Pharmacy phone</label></div>
					<p class="mc-reg-section">Administrator account</p>
					<div class="mc-field"><input type="text" name="first_name" required placeholder=" " value="<?php echo $v('first_name'); ?>"><label class="mc-float-label">Your first name</label></div>
					<div class="mc-field"><input type="text" name="last_name" placeholder=" " value="<?php echo $v('last_name'); ?>"><label class="mc-float-label">Last name</label></div>
					<div class="mc-field"><input type="email" name="email" placeholder=" " value="<?php echo $v('email'); ?>"><label class="mc-float-label">Email (optional)</label></div>
					<div class="mc-field"><input type="text" name="username" required placeholder=" " value="<?php echo $v('username'); ?>" autocapitalize="none"><label class="mc-float-label">Username</label></div>
					<div class="mc-field mc-pw"><input type="password" name="password" required placeholder=" "><label class="mc-float-label">Password</label></div>
					<div class="mc-field mc-pw"><input type="password" name="password2" required placeholder=" "><label class="mc-float-label">Confirm password</label></div>
					<button type="submit" class="mc-btn">Create pharmacy account</button>
				</form>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php mc_render_site_footer(); ?>
</body>
</html>
