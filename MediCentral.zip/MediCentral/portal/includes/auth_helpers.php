<?php

declare(strict_types=1);

require_once __DIR__ . '/username_format.php';

/** @var mysqli $conn */

/**
 * Web path to portal root (e.g. /MediCentral/portal/) from the current script location.
 */
function mc_portal_root_web_path(): string
{
	static $cached = null;
	if ($cached !== null) {
		return $cached;
	}
	$dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
	$portalSubs = ['pharmacy', 'admin', 'member', 'system', 'pharmacist', 'api'];
	while (true) {
		$base = basename($dir);
		if ($base === '' || $base === '.' || !in_array($base, $portalSubs, true)) {
			break;
		}
		$dir = dirname($dir);
	}
	$cached = rtrim($dir, '/') . '/';

	return $cached;
}

function mc_portal_url(string $relativePath): string
{
	return mc_portal_root_web_path() . ltrim(str_replace('\\', '/', $relativePath), '/');
}

function mc_portal_redirect(string $relativePath): void
{
	header('Location: ' . mc_portal_url($relativePath));
	exit;
}

function mc_auth_redirect_if_logged_in(mysqli $conn, string $portal = 'any'): void
{
	$role = (string) ($_SESSION['mc_role'] ?? '');
	if ($role === 'system') {
		mc_portal_redirect('system/dashboard.php');
	}
	if ($portal === 'network') {
		if ($role === 'member') {
			mc_portal_redirect('member/index.php');
		}
		if ($role === 'pharmacist') {
			mc_pharmacist_redirect_after_login($conn);
		}
		if ($role === 'admin') {
			mc_portal_redirect('admin/dashboard.php');
		}

		return;
	}
	if ($portal === 'pharmacy') {
		if ($role === 'admin') {
			mc_portal_redirect('admin/dashboard.php');
		}
		if ($role === 'pharmacist') {
			mc_portal_redirect('pharmacist-home.php');
		}
		if ($role === 'member') {
			mc_portal_redirect('member/index.php');
		}

		return;
	}
	if ($role === 'admin') {
		mc_portal_redirect('admin/dashboard.php');
	}
	if ($role === 'pharmacist') {
		mc_pharmacist_redirect_after_login($conn);
	}
	if ($role === 'member') {
		mc_portal_redirect('member/index.php');
	}
}

function mc_normalize_login_username(string $raw): string
{
	$formatted = mc_format_signin_username(trim($raw));

	return mb_strtolower($formatted, 'UTF-8');
}

function mc_member_username_available(mysqli $conn, string $username): bool
{
	$stmt = $conn->prepare('SELECT 1 FROM mc_members WHERE username = ? LIMIT 1');
	if (!$stmt) {
		return false;
	}
	$stmt->bind_param('s', $username);
	if (!$stmt->execute()) {
		$stmt->close();

		return false;
	}
	$stmt->store_result();
	$free = $stmt->num_rows === 0;
	$stmt->close();

	return $free;
}

function mc_member_email_available(mysqli $conn, ?string $email): bool
{
	if ($email === null || $email === '') {
		return true;
	}
	$stmt = $conn->prepare('SELECT 1 FROM mc_members WHERE email = ? LIMIT 1');
	if (!$stmt) {
		return false;
	}
	$stmt->bind_param('s', $email);
	if (!$stmt->execute()) {
		$stmt->close();

		return false;
	}
	$stmt->store_result();
	$free = $stmt->num_rows === 0;
	$stmt->close();

	return $free;
}

function mc_touch_member_login(mysqli $conn, int $memberId): void
{
	if ($memberId <= 0) {
		return;
	}
	if ($upd = $conn->prepare('UPDATE mc_members SET last_login_at = CURRENT_TIMESTAMP WHERE member_id = ? LIMIT 1')) {
		$upd->bind_param('i', $memberId);
		@$upd->execute();
		$upd->close();
	}
}

function mc_set_signin_portal(string $portal): void
{
	if ($portal === 'pharmacy' || $portal === 'network') {
		$_SESSION['mc_signin_portal'] = $portal;
	}
}

function mc_signout_target(string $explicit = ''): string
{
	if ($explicit === 'pharmacy' || $explicit === 'network') {
		return $explicit === 'pharmacy' ? 'pharmacy/signin.php' : 'index.php';
	}
	$stored = (string) ($_SESSION['mc_signin_portal'] ?? 'network');

	return $stored === 'pharmacy' ? 'pharmacy/signin.php' : 'index.php';
}

function mc_start_member_session(int $memberId, string $usernameNorm): void
{
	session_regenerate_id(true);
	$_SESSION['mc_role'] = 'member';
	$_SESSION['mc_member_id'] = $memberId;
	$_SESSION['mc_username'] = $usernameNorm;
	mc_set_signin_portal('network');
}

function mc_start_pharmacist_session(int $pharmacistId, string $usernameNorm, string $portal = 'network'): void
{
	session_regenerate_id(true);
	$_SESSION['mc_role'] = 'pharmacist';
	$_SESSION['mc_pharmacist_id'] = $pharmacistId;
	$_SESSION['mc_username'] = $usernameNorm;
	mc_set_signin_portal($portal);
}

function mc_pharmacist_redirect_after_login(mysqli $conn): void
{
	require_once __DIR__ . '/pharmacist_pro.php';
	$pid = (int) ($_SESSION['mc_pharmacist_id'] ?? 0);
	if ($pid <= 0) {
		mc_portal_redirect('index.php');
	}
	$p = mc_pharmacist_load($conn, $pid);
	if ($p === null) {
		mc_portal_redirect('index.php');
	}
	if (mc_pharmacist_has_approval_columns($conn)) {
		$status = (string) ($p['approval_status'] ?? 'pending');
		if ($status === 'rejected') {
			mc_portal_redirect('index.php?pharmacist=rejected');
		}
		if (!mc_pharmacist_is_approved($p)) {
			mc_portal_redirect('pharmacist/pending.php');
		}
	} elseif ((int) ($p['is_active'] ?? 0) !== 1) {
		mc_portal_redirect('index.php');
	}
	mc_portal_redirect('pharmacist/index.php');
}
