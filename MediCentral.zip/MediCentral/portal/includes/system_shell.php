<?php

declare(strict_types=1);

require_once __DIR__ . '/site_footer.php';

/**
 * @param 'dashboard'|'pharmacies'|'pharmacy'|'members'|'admins'|'phapps'|'orders'|'audit'|'settings' $active
 */
function mc_system_shell_start(string $pageTitle, string $active): void
{
	$nav = [
		'dashboard' => ['Command center', 'dashboard.php'],
		'pharmacies' => ['Pharmacies', 'pharmacies.php'],
		'phapps' => ['Pharmacist applications', 'pharmacist-applications.php'],
		'admins' => ['Pharmacy admins', 'admins.php'],
		'members' => ['Members', 'members.php'],
		'orders' => ['Member orders', 'orders.php'],
		'audit' => ['Audit log', 'audit.php'],
		'settings' => ['Security', 'settings.php'],
	];
	$display = htmlspecialchars((string) ($_SESSION['mc_system_display'] ?? $_SESSION['mc_username'] ?? ''), ENT_QUOTES, 'UTF-8');
	$user = htmlspecialchars((string) ($_SESSION['mc_username'] ?? ''), ENT_QUOTES, 'UTF-8');
	$d = 'div';

	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
	echo '<title>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . ' · MediCentral System</title>';
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
	echo '<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">';
	echo '<link rel="stylesheet" href="../css/system-admin.css">';
	echo '</head><body class="sys-body"><' . $d . ' class="sys-grid-bg" aria-hidden="true"></' . $d . '>';
	echo '<' . $d . ' class="sys-layout"><aside class="sys-sidebar">';
	echo '<a href="../member/index.php" class="sys-brand sys-brand-link" title="Open public member site"><span class="sys-shield" aria-hidden="true">⬡</span><' . $d . '><strong>MediCentral</strong><small>System control</small></' . $d . '></a>';
	echo '<p class="sys-url-hint">Direct access only · gated</p>';
	echo '<' . $d . ' class="sys-pub-links"><span class="sys-pub-label">Public site</span>';
	echo '<a class="sys-nav-link sys-nav-public" href="../member/index.php">Member portal</a>';
	echo '<a class="sys-nav-link sys-nav-public" href="../pharmacy/signin.php">Operations sign-in</a>';
	echo '<a class="sys-nav-link sys-nav-public" href="../index.php">Network sign-in</a>';
	echo '</' . $d . '><nav class="sys-nav">';
	foreach ($nav as $slug => $pair) {
		$cls = ($active === $slug || ($active === 'pharmacy' && $slug === 'pharmacies')) ? ' sys-nav-link is-active' : ' sys-nav-link';
		echo '<a class="' . trim($cls) . '" href="' . htmlspecialchars($pair[1], ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($pair[0], ENT_QUOTES, 'UTF-8') . '</a>';
	}
	echo '</nav><' . $d . ' class="sys-sidefoot">';
	echo '<span class="sys-user-name">' . $display . '</span><span class="sys-user-id">@' . $user . '</span>';
	echo '<a class="sys-out" href="logout.php">Sign out</a></' . $d . '></aside>';
	echo '<main class="sys-main"><header class="sys-top"><h1>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . '</h1>';
	echo '<' . $d . ' class="sys-top-actions"><a class="sys-top-link" href="../member/index.php" target="_blank" rel="noopener">View member site ↗</a>';
	echo '<a class="sys-top-link" href="../pharmacy/signin.php">Operations sign-in</a>';
	echo '<a class="sys-top-link" href="../index.php">Network sign-in</a><span class="sys-badge-live">Live network</span></' . $d . '></header><' . $d . ' class="sys-content">';
}

function mc_system_shell_end(): void
{
	$d = 'div';
	echo '</' . $d . '>';
	mc_render_site_footer();
	echo '</main></' . $d . '></body></html>';
}

function mc_system_flash(string $msg, string $kind = 'info'): void
{
	$c = $kind === 'success' ? 'sys-flash success' : ($kind === 'error' ? 'sys-flash error' : 'sys-flash');
	$d = 'div';
	echo '<' . $d . ' class="' . htmlspecialchars($c, ENT_QUOTES, 'UTF-8') . '" role="status">' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</' . $d . '>';
}
