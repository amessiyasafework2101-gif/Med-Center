<?php

declare(strict_types=1);

/** Gate password for system control panel (change in production). */
define('MC_SYSTEM_GATE_PASSWORD', 'MediCentral-System-2026');
