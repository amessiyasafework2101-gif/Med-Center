<?php

declare(strict_types=1);

function mc_bootstrap_admin_chat_schema(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_admins', 'admin_id')) {
		return;
	}
	$sql = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_admin_pharmacist_chat` (
  `connection_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int unsigned NOT NULL,
  `pharmacist_id` bigint unsigned NOT NULL,
  `status` enum('pending','approved','declined') NOT NULL DEFAULT 'pending',
  `requested_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `responded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`connection_id`),
  UNIQUE KEY `ux_admin_ph_chat` (`admin_id`,`pharmacist_id`),
  KEY `ix_admin_ph_chat_pharmacist` (`pharmacist_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
	@$conn->query($sql);
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_admin_chat_list_pharmacists(mysqli $conn, int $adminId): array
{
	mc_bootstrap_admin_chat_schema($conn);
	$rows = [];
	$where = mc_pharmacist_has_approval_columns($conn)
		? "p.approval_status = 'approved' AND p.is_active = 1"
		: 'p.is_active = 1';
	$sql = "SELECT p.pharmacist_id, p.username, p.first_name, p.last_name, p.bio, p.performance_score, p.rating_count,
		c.connection_id, c.status AS chat_status, c.requested_at
		FROM mc_pharmacists p
		LEFT JOIN mc_admin_pharmacist_chat c ON c.pharmacist_id = p.pharmacist_id AND c.admin_id = ?
		WHERE {$where}
		ORDER BY p.first_name ASC, p.last_name ASC
		LIMIT 200";
	$st = $conn->prepare($sql);
	if (!$st) {
		return $rows;
	}
	$st->bind_param('i', $adminId);
	$st->execute();
	$res = $st->get_result();
	while ($r = $res->fetch_assoc()) {
		$rows[] = $r;
	}
	$st->close();

	return $rows;
}

function mc_admin_chat_request(mysqli $conn, int $adminId, int $pharmacistId): array
{
	mc_bootstrap_admin_chat_schema($conn);
	if ($adminId <= 0 || $pharmacistId <= 0) {
		return ['ok' => false, 'msg' => 'Invalid request.'];
	}
	$st = $conn->prepare(
		'SELECT connection_id, status FROM mc_admin_pharmacist_chat WHERE admin_id = ? AND pharmacist_id = ? LIMIT 1'
	);
	if (!$st) {
		return ['ok' => false, 'msg' => 'Could not send request.'];
	}
	$st->bind_param('ii', $adminId, $pharmacistId);
	$st->execute();
	$res = $st->get_result();
	$existing = $res ? $res->fetch_assoc() : null;
	$st->close();

	if ($existing) {
		$stt = (string) $existing['status'];
		if ($stt === 'approved') {
			return ['ok' => true, 'msg' => 'You are already connected. Open chat below.'];
		}
		if ($stt === 'pending') {
			return ['ok' => true, 'msg' => 'Chat request already pending approval.'];
		}
		$upd = $conn->prepare(
			"UPDATE mc_admin_pharmacist_chat SET status = 'pending', requested_at = CURRENT_TIMESTAMP, responded_at = NULL WHERE connection_id = ?"
		);
		if ($upd) {
			$cid = (int) $existing['connection_id'];
			$upd->bind_param('i', $cid);
			$upd->execute();
			$upd->close();
		}

		return ['ok' => true, 'msg' => 'Chat request sent again.'];
	}

	$ins = $conn->prepare(
		'INSERT INTO mc_admin_pharmacist_chat (admin_id, pharmacist_id, status) VALUES (?,?,\'pending\')'
	);
	if (!$ins || !$ins->bind_param('ii', $adminId, $pharmacistId) || !$ins->execute()) {
		if ($ins) {
			$ins->close();
		}

		return ['ok' => false, 'msg' => 'Could not send chat request.'];
	}
	$ins->close();

	require_once __DIR__ . '/pharmacist_pro.php';
	mc_pharmacist_post_message(
		$conn,
		$pharmacistId,
		'admin',
		'system',
		'A pharmacy administrator requested to chat with you. Approve the request in Messages → Admin chat.',
		null,
		$adminId,
		null
	);

	return ['ok' => true, 'msg' => 'Chat request sent. The pharmacist must approve before you can message.'];
}

function mc_admin_chat_can_message(mysqli $conn, int $adminId, int $pharmacistId): bool
{
	mc_bootstrap_admin_chat_schema($conn);
	$st = $conn->prepare(
		"SELECT 1 FROM mc_admin_pharmacist_chat WHERE admin_id = ? AND pharmacist_id = ? AND status = 'approved' LIMIT 1"
	);
	if (!$st) {
		return false;
	}
	$st->bind_param('ii', $adminId, $pharmacistId);
	$st->execute();
	$st->store_result();
	$ok = $st->num_rows > 0;
	$st->close();

	return $ok;
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_pharmacist_pending_chat_requests(mysqli $conn, int $pharmacistId): array
{
	mc_bootstrap_admin_chat_schema($conn);
	$rows = [];
	$sql = <<<'SQL'
SELECT c.connection_id, c.admin_id, c.requested_at, a.username, a.first_name, a.last_name, ph.name AS pharmacy_name
FROM mc_admin_pharmacist_chat c
INNER JOIN mc_admins a ON a.admin_id = c.admin_id
LEFT JOIN mc_pharmacies ph ON ph.pharmacy_id = a.pharmacy_id
WHERE c.pharmacist_id = ? AND c.status = 'pending'
ORDER BY c.requested_at DESC
SQL;
	$st = $conn->prepare($sql);
	if (!$st) {
		return $rows;
	}
	$st->bind_param('i', $pharmacistId);
	$st->execute();
	$res = $st->get_result();
	while ($r = $res->fetch_assoc()) {
		$rows[] = $r;
	}
	$st->close();

	return $rows;
}

function mc_pharmacist_respond_chat_request(mysqli $conn, int $pharmacistId, int $connectionId, bool $approve): array
{
	mc_bootstrap_admin_chat_schema($conn);
	$st = $conn->prepare(
		'SELECT admin_id FROM mc_admin_pharmacist_chat WHERE connection_id = ? AND pharmacist_id = ? AND status = \'pending\' LIMIT 1'
	);
	if (!$st) {
		return ['ok' => false, 'msg' => 'Request not found.'];
	}
	$st->bind_param('ii', $connectionId, $pharmacistId);
	$st->execute();
	$res = $st->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$st->close();
	if (!$row) {
		return ['ok' => false, 'msg' => 'Request not found or already handled.'];
	}
	$adminId = (int) $row['admin_id'];
	$newStatus = $approve ? 'approved' : 'declined';
	$upd = $conn->prepare(
		'UPDATE mc_admin_pharmacist_chat SET status = ?, responded_at = CURRENT_TIMESTAMP WHERE connection_id = ? AND pharmacist_id = ?'
	);
	if (!$upd || !$upd->bind_param('sii', $newStatus, $connectionId, $pharmacistId) || !$upd->execute()) {
		if ($upd) {
			$upd->close();
		}

		return ['ok' => false, 'msg' => 'Could not update request.'];
	}
	$upd->close();

	require_once __DIR__ . '/pharmacist_pro.php';
	$msg = $approve
		? 'You approved the chat request. You can now message each other in Admin chat.'
		: 'You declined the chat request.';
	mc_pharmacist_post_message($conn, $pharmacistId, 'admin', 'pharmacist', $msg, null, null, $pharmacistId);

	return [
		'ok' => true,
		'msg' => $approve ? 'Chat approved. You can now reply to this administrator.' : 'Request declined.',
	];
}

/**
 * Register pharmacy + first administrator (operations portal).
 *
 * @param array<string, string> $in
 * @return array{ok: bool, msg: string, admin_id?: int}
 */
function mc_register_pharmacy_admin(mysqli $conn, array $in): array
{
	require_once __DIR__ . '/system_pharmacies.php';

	$phName = trim((string) ($in['pharmacy_name'] ?? ''));
	$city = trim((string) ($in['city'] ?? ''));
	$address = trim((string) ($in['address'] ?? ''));
	$phPhone = trim((string) ($in['pharmacy_phone'] ?? ''));
	$uname = trim((string) ($in['username'] ?? ''));
	$pwd = (string) ($in['password'] ?? '');
	$pwd2 = (string) ($in['password2'] ?? '');
	$fn = trim((string) ($in['first_name'] ?? ''));
	$ln = trim((string) ($in['last_name'] ?? ''));
	$email = trim((string) ($in['email'] ?? ''));

	$unameNorm = mc_normalize_login_username($uname);
	if ($phName === '' || $fn === '' || $unameNorm === '' || $pwd === '') {
		return ['ok' => false, 'msg' => 'Pharmacy name, your name, username, and password are required.'];
	}
	if (strlen($pwd) < 8) {
		return ['ok' => false, 'msg' => 'Password must be at least 8 characters.'];
	}
	if ($pwd !== $pwd2) {
		return ['ok' => false, 'msg' => 'Passwords do not match.'];
	}
	if (!preg_match('/^[a-z0-9_.-]{3,50}$/', $unameNorm)) {
		return ['ok' => false, 'msg' => 'Username must be 3–50 characters: lowercase letters, numbers, or ._-'];
	}
	if (!mc_admin_username_available($conn, $unameNorm)) {
		return ['ok' => false, 'msg' => 'That username is already taken.'];
	}
	$emailDb = $email === '' ? null : mb_strtolower($email, 'UTF-8');
	if ($emailDb !== null) {
		$chk = $conn->prepare('SELECT 1 FROM mc_admins WHERE email = ? LIMIT 1');
		if ($chk) {
			$chk->bind_param('s', $emailDb);
			$chk->execute();
			$chk->store_result();
			if ($chk->num_rows > 0) {
				$chk->close();

				return ['ok' => false, 'msg' => 'That email is already registered to an admin.'];
			}
			$chk->close();
		}
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$conn->begin_transaction();

		$phSave = mc_system_pharmacy_save($conn, [
			'name' => $phName,
			'city' => $city,
			'address' => $address,
			'phone' => $phPhone,
			'license_number' => 'PENDING-' . date('Ymd'),
			'is_active' => '1',
			'is_verified' => '',
		], 0);
		if (!$phSave['ok']) {
			throw new RuntimeException($phSave['error'] ?? 'pharmacy');
		}
		$pharmacyId = (int) $phSave['id'];

		$hash = password_hash($pwd, PASSWORD_DEFAULT);
		$lnDb = $ln === '' ? null : $ln;
		$hasPh = mc_table_has_column($conn, 'mc_admins', 'pharmacy_id');
		if ($hasPh) {
			$sql = 'INSERT INTO mc_admins (username, password_hash, first_name, last_name, email, pharmacy_id) VALUES (?,?,?,?,?,?)';
			$ins = $conn->prepare($sql);
			if (!$ins || !$ins->bind_param('sssssi', $unameNorm, $hash, $fn, $lnDb, $emailDb, $pharmacyId) || !$ins->execute()) {
				throw new RuntimeException('admin');
			}
		} else {
			$sql = 'INSERT INTO mc_admins (username, password_hash, first_name, last_name, email) VALUES (?,?,?,?,?)';
			$ins = $conn->prepare($sql);
			if (!$ins || !$ins->bind_param('sssss', $unameNorm, $hash, $fn, $lnDb, $emailDb) || !$ins->execute()) {
				throw new RuntimeException('admin');
			}
		}
		$adminId = (int) $conn->insert_id;
		$ins->close();

		$conn->commit();

		return ['ok' => true, 'msg' => 'Pharmacy registered. You can sign in now.', 'admin_id' => $adminId];
	} catch (Throwable $e) {
		@$conn->rollback();

		return ['ok' => false, 'msg' => 'Registration failed: ' . ($e->getMessage() === 'pharmacy' ? 'could not create pharmacy.' : 'try again.')];
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}
