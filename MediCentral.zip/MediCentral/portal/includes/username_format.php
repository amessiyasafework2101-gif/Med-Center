<?php

declare(strict_types=1);

/**
 * Auto-format sign-in username: uppercase first letter of each segment separated by space, ._-
 * Single segment (no delimiter) uppercases only the leading letter.
 */
function mc_format_signin_username(string $raw): string
{
	$s = trim($raw);
	if ($s === '') {
		return '';
	}

	$s = mb_strtolower($s, 'UTF-8');

	return preg_replace_callback(
			'/(^|[\\s._-])([^\\s._-]+)/u',
		static function (array $m): string {
			$seg = $m[2];
			$first = mb_strtoupper(mb_substr($seg, 0, 1, 'UTF-8'), 'UTF-8');
			$tail = mb_substr($seg, 1, null, 'UTF-8');

			return $m[1] . $first . $tail;
		},
		$s
	) ?? $s;
}
