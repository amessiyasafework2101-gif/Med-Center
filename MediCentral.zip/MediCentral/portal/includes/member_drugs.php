<?php

declare(strict_types=1);

/**
 * @return array<int, array<string, mixed>>|null
 */
function mc_drug_lookup_by_code(mysqli $conn, string $code): ?array
{
	$code = trim($code);
	if ($code === '') {
		return null;
	}

	$sql = <<<'SQL'
SELECT d.drug_id, d.name, d.category, d.manufacturer, d.description, d.barcode, d.qr_code,
  d.quantity AS global_qty, d.unit_price AS global_price, d.reorder_level, d.expiry_date,
  ph.pharmacy_id, ph.name AS pharmacy_name, ph.city AS pharmacy_city,
  COALESCE(i.quantity, d.quantity) AS shelf_qty,
  COALESCE(i.unit_price, d.unit_price) AS shelf_price
FROM mc_drugs d
LEFT JOIN mc_pharmacy_inventory i ON i.drug_id = d.drug_id
LEFT JOIN mc_pharmacies ph ON ph.pharmacy_id = i.pharmacy_id AND ph.is_active = 1
WHERE d.barcode = ? OR d.qr_code = ?
ORDER BY i.quantity DESC, ph.name ASC
SQL;

	$st = $conn->prepare($sql);
	if (!$st) {
		return null;
	}
	$st->bind_param('ss', $code, $code);
	if (!$st->execute()) {
		$st->close();

		return null;
	}

	$rows = [];
	$did = $drugId = 0;
	$name = $cat = $mfr = $desc = $bc = $qr = '';
	$gqty = $gprice = 0.0;
	$reorder = 0;
	$exp = null;
	$phId = 0;
	$phName = $phCity = '';
	$shelfQty = 0;
	$shelfPrice = 0.0;

	$st->bind_result(
		$drugId,
		$name,
		$cat,
		$mfr,
		$desc,
		$bc,
		$qr,
		$gqty,
		$gprice,
		$reorder,
		$exp,
		$phId,
		$phName,
		$phCity,
		$shelfQty,
		$shelfPrice
	);

	while ($st->fetch()) {
		$rows[] = [
			'drug_id' => $drugId,
			'name' => $name,
			'category' => $cat,
			'manufacturer' => $mfr,
			'description' => $desc,
			'barcode' => $bc,
			'qr_code' => $qr,
			'global_qty' => (int) $gqty,
			'global_price' => (float) $gprice,
			'reorder_level' => (int) $reorder,
			'expiry_date' => $exp,
			'pharmacy_id' => $phId ? (int) $phId : null,
			'pharmacy_name' => $phName,
			'pharmacy_city' => $phCity,
			'shelf_qty' => (int) $shelfQty,
			'shelf_price' => (float) $shelfPrice,
		];
	}
	$st->close();

	return $rows === [] ? null : $rows;
}

/**
 * @return array{rows: array<int, array<string, mixed>>, categories: array<int, string>}
 */
function mc_member_search_drugs(mysqli $conn, array $filters): array
{
	$q = trim((string) ($filters['q'] ?? ''));
	$pharmacyId = (int) ($filters['pharmacy_id'] ?? 0);
	$category = trim((string) ($filters['category'] ?? ''));
	$inStock = !empty($filters['in_stock']);
	$sort = (string) ($filters['sort'] ?? 'name');

	$where = ['ph.is_active = 1'];
	$types = '';
	$params = [];

	if ($pharmacyId > 0) {
		$where[] = 'ph.pharmacy_id = ?';
		$types .= 'i';
		$params[] = $pharmacyId;
	}
	if ($category !== '') {
		$where[] = 'd.category = ?';
		$types .= 's';
		$params[] = $category;
	}
	if ($inStock) {
		$where[] = 'COALESCE(i.quantity, 0) > 0';
	}
	if ($q !== '') {
		$where[] = '(d.name LIKE ? OR d.category LIKE ? OR d.barcode LIKE ? OR d.manufacturer LIKE ?)';
		$types .= 'ssss';
		$like = '%' . $q . '%';
		$params[] = $like;
		$params[] = $like;
		$params[] = $like;
		$params[] = $like;
	}

	$order = match ($sort) {
		'price_asc' => 'shelf_price ASC, d.name ASC',
		'price_desc' => 'shelf_price DESC, d.name ASC',
		'stock_desc' => 'shelf_qty DESC, d.name ASC',
		default => 'd.name ASC',
	};

	$sql = '
SELECT d.drug_id, d.name, d.category, d.manufacturer, d.expiry_date, d.barcode,
  ph.pharmacy_id, ph.name AS pharmacy_name, ph.city,
  COALESCE(i.quantity, 0) AS shelf_qty,
  COALESCE(i.unit_price, d.unit_price) AS shelf_price,
  i.inventory_id
FROM mc_pharmacy_inventory i
INNER JOIN mc_drugs d ON d.drug_id = i.drug_id
INNER JOIN mc_pharmacies ph ON ph.pharmacy_id = i.pharmacy_id
WHERE ' . implode(' AND ', $where) . '
ORDER BY ' . $order . '
LIMIT 80';

	$rows = [];
	$st = $conn->prepare($sql);
	if ($st) {
		if ($types !== '') {
			$st->bind_param($types, ...$params);
		}
		if ($st->execute()) {
			$st->bind_result(
				$did,
				$dn,
				$dcat,
				$dmfr,
				$dexp,
				$dbc,
				$phid,
				$phn,
				$phcity,
				$sqty,
				$sprice,
				$invId
			);
			while ($st->fetch()) {
				$rows[] = [
					'drug_id' => $did,
					'name' => $dn,
					'category' => $dcat,
					'manufacturer' => $dmfr,
					'expiry_date' => $dexp,
					'barcode' => $dbc,
					'pharmacy_id' => $phid,
					'pharmacy_name' => $phn,
					'pharmacy_city' => $phcity,
					'shelf_qty' => $sqty,
					'shelf_price' => $sprice,
					'inventory_id' => $invId,
				];
			}
		}
		$st->close();
	}

	$cats = [];
	$cr = $conn->query('SELECT DISTINCT category FROM mc_drugs ORDER BY category ASC');
	if ($cr) {
		while ($c = $cr->fetch_assoc()) {
			$cats[] = (string) $c['category'];
		}
	}

	return ['rows' => $rows, 'categories' => $cats];
}

function mc_member_place_order(
	mysqli $conn,
	int $memberId,
	int $pharmacyId,
	int $drugId,
	int $qty,
	?string $note
): array {
	if ($memberId <= 0 || $pharmacyId <= 0 || $drugId <= 0 || $qty <= 0) {
		return ['ok' => false, 'msg' => 'Invalid order request.'];
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$conn->begin_transaction();

		$st = $conn->prepare(
			'SELECT i.quantity, COALESCE(i.unit_price, d.unit_price) AS price
			FROM mc_pharmacy_inventory i
			INNER JOIN mc_drugs d ON d.drug_id = i.drug_id
			WHERE i.pharmacy_id = ? AND i.drug_id = ? LIMIT 1 FOR UPDATE'
		);
		if (!$st) {
			throw new RuntimeException('prep');
		}
		$st->bind_param('ii', $pharmacyId, $drugId);
		$st->execute();
		$stk = 0;
		$price = 0.0;
		$st->bind_result($stk, $price);
		if (!$st->fetch()) {
			$st->close();
			throw new RuntimeException('notfound');
		}
		$st->close();

		if ($stk < $qty) {
			throw new RuntimeException('stock');
		}

		$lineTotal = round($qty * (float) $price, 2);

		$ins = $conn->prepare(
			'INSERT INTO mc_member_orders (member_id, pharmacy_id, status, total_amount, order_note) VALUES (?,?,?,?,?)'
		);
		if (!$ins) {
			throw new RuntimeException('order');
		}
		$status = 'pending';
		$ins->bind_param('iisds', $memberId, $pharmacyId, $status, $lineTotal, $note);
		if (!$ins->execute()) {
			$ins->close();
			throw new RuntimeException('order');
		}
		$orderId = (int) $conn->insert_id;
		$ins->close();

		$ln = $conn->prepare(
			'INSERT INTO mc_member_order_lines (order_id, drug_id, qty, unit_price, line_total) VALUES (?,?,?,?,?)'
		);
		if (!$ln || !$ln->bind_param('iiidd', $orderId, $drugId, $qty, $price, $lineTotal) || !$ln->execute()) {
			if ($ln) {
				$ln->close();
			}
			throw new RuntimeException('line');
		}
		$ln->close();

		$upd = $conn->prepare(
			'UPDATE mc_pharmacy_inventory SET quantity = quantity - ? WHERE pharmacy_id = ? AND drug_id = ? AND quantity >= ?'
		);
		if (!$upd || !$upd->bind_param('iiii', $qty, $pharmacyId, $drugId, $qty) || !$upd->execute() || $upd->affected_rows !== 1) {
			if ($upd) {
				$upd->close();
			}
			throw new RuntimeException('stock');
		}
		$upd->close();

		$conn->commit();

		return ['ok' => true, 'msg' => 'Order #' . $orderId . ' placed with the pharmacy.', 'order_id' => $orderId];
	} catch (Throwable $e) {
		@$conn->rollback();
		$code = $e->getMessage();

		return match ($code) {
			'stock' => ['ok' => false, 'msg' => 'Not enough stock at that pharmacy.'],
			'notfound' => ['ok' => false, 'msg' => 'This product is not listed at the selected pharmacy.'],
			default => ['ok' => false, 'msg' => 'Could not place order. Try again.'],
		};
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}
