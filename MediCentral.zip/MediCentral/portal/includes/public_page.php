<?php

declare(strict_types=1);

require_once __DIR__ . '/site_footer.php';
require_once __DIR__ . '/site_nav.php';

/**
 * @param 'home'|'about'|'contact'|'ai' $active
 */
function mc_public_page_start(string $pageTitle, string $active = 'home', string $assetPrefix = ''): void
{
	$navItems = mc_site_nav_items('public', $assetPrefix);
	?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?> · MediCentral</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo htmlspecialchars($assetPrefix . 'css/signin.css', ENT_QUOTES, 'UTF-8'); ?>">
	<link rel="stylesheet" href="<?php echo htmlspecialchars($assetPrefix . 'css/public-pages.css', ENT_QUOTES, 'UTF-8'); ?>">
</head>
<body class="mc-public-body">
	<div class="mc-backdrop" aria-hidden="true"><div class="mc-grid"></div><div class="mc-orbits"><div class="mc-orbit"></div></div></div>
	<header class="mc-pub-top">
		<a href="<?php echo htmlspecialchars($navItems[0]['href'], ENT_QUOTES, 'UTF-8'); ?>" class="mc-pub-brand"><strong>MediCentral</strong></a>
		<?php mc_render_site_nav_bar($active, $navItems); ?>
	</header>
	<main class="mc-pub-main">
	<?php
}

function mc_public_page_end(string $assetPrefix = ''): void
{
	?>
	</main>
	<?php mc_render_site_footer($assetPrefix); ?>
</body>
</html>
	<?php
}
