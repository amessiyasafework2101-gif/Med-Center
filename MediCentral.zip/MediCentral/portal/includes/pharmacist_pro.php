<?php

declare(strict_types=1);

function mc_pharmacist_has_approval_columns(mysqli $conn): bool
{
	return mc_table_has_column($conn, 'mc_pharmacists', 'approval_status');
}

/**
 * @return array<string, mixed>|null
 */
function mc_pharmacist_load(mysqli $conn, int $pharmacistId): ?array
{
	$stmt = $conn->prepare('SELECT * FROM mc_pharmacists WHERE pharmacist_id = ? LIMIT 1');
	if (!$stmt) {
		return null;
	}
	$stmt->bind_param('i', $pharmacistId);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();

	return $row ?: null;
}

function mc_pharmacist_is_approved(array $pharmacist): bool
{
	if (!isset($pharmacist['approval_status'])) {
		return (int) ($pharmacist['is_active'] ?? 0) === 1;
	}

	return (string) $pharmacist['approval_status'] === 'approved' && (int) ($pharmacist['is_active'] ?? 0) === 1;
}

function mc_pharmacist_username_available(mysqli $conn, string $username): bool
{
	$stmt = $conn->prepare('SELECT 1 FROM mc_pharmacists WHERE username = ? LIMIT 1');
	if (!$stmt) {
		return false;
	}
	$stmt->bind_param('s', $username);
	$stmt->execute();
	$stmt->store_result();
	$free = $stmt->num_rows === 0;
	$stmt->close();

	return $free;
}

/**
 * @param array<string, string> $data
 * @return array{ok: bool, error: string, id?: int, auto_approved?: bool}
 */
function mc_pharmacist_register(mysqli $conn, array $data): array
{
	$user = mb_strtolower(trim($data['username'] ?? ''), 'UTF-8');
	$pw = (string) ($data['password'] ?? '');
	$fname = trim($data['first_name'] ?? '');
	if ($user === '' || $fname === '' || strlen($pw) < 10) {
		return ['ok' => false, 'error' => 'Username, first name, and password (min 10) are required.'];
	}
	if (!preg_match('/^[a-z0-9_.-]{3,50}$/', $user)) {
		return ['ok' => false, 'error' => 'Invalid username format.'];
	}
	if (!mc_pharmacist_username_available($conn, $user)) {
		return ['ok' => false, 'error' => 'Username already taken.'];
	}

	$h = password_hash($pw, PASSWORD_DEFAULT);
	$lname = trim($data['last_name'] ?? '');
	$email = trim($data['email'] ?? '');
	$phone = trim($data['phone'] ?? '');
	$bio = trim($data['bio'] ?? '');
	$cv = trim($data['cv_summary'] ?? '');
	$cvUrl = trim($data['cv_document_url'] ?? '');
	$licNo = trim($data['license_number'] ?? '');
	$licAuth = trim($data['license_authority'] ?? '');
	$licExp = trim($data['license_expiry'] ?? '');
	$licUrl = trim($data['license_document_url'] ?? '');

	// Optional credentials: if CV or license is supplied, admin reviews; otherwise instant access + Dr. Aklilu.
	$submittedForReview = $licNo !== '' || $cv !== '';
	$approvalStatus = $submittedForReview ? 'pending' : 'approved';
	$isActive = $submittedForReview ? 0 : 1;

	$mail = $email === '' ? null : $email;
	$licExpVal = $licExp !== '' ? $licExp : null;
	$cvVal = $cv === '' ? null : $cv;
	$cvUrlVal = $cvUrl === '' ? null : $cvUrl;
	$licNoVal = $licNo === '' ? null : $licNo;
	$licAuthVal = $licAuth === '' ? null : $licAuth;
	$licUrlVal = $licUrl === '' ? null : $licUrl;
	$lnameVal = $lname === '' ? null : $lname;
	$phoneVal = $phone === '' ? null : $phone;
	$bioVal = $bio === '' ? null : $bio;

	if (mc_pharmacist_has_approval_columns($conn)) {
		$sql = <<<'SQL'
INSERT INTO mc_pharmacists (
  username, password_hash, first_name, last_name, email, phone, bio,
  cv_summary, cv_document_url, license_number, license_authority, license_expiry, license_document_url,
  is_active, approval_status
) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
SQL;
		$stmt = $conn->prepare($sql);
		if (!$stmt) {
			return ['ok' => false, 'error' => 'Registration failed.'];
		}
		$stmt->bind_param(
			'sssssssssssssis',
			$user,
			$h,
			$fname,
			$lnameVal,
			$mail,
			$phoneVal,
			$bioVal,
			$cvVal,
			$cvUrlVal,
			$licNoVal,
			$licAuthVal,
			$licExpVal,
			$licUrlVal,
			$isActive,
			$approvalStatus
		);
	} else {
		$stmt = $conn->prepare(
			'INSERT INTO mc_pharmacists (username, password_hash, first_name, last_name, email, is_active) VALUES (?,?,?,?,?,1)'
		);
		if (!$stmt) {
			return ['ok' => false, 'error' => 'Registration failed.'];
		}
		$stmt->bind_param('sssss', $user, $h, $fname, $lname, $mail);
	}

	if (!$stmt->execute()) {
		$stmt->close();

		return ['ok' => false, 'error' => 'Could not save registration.'];
	}
	$id = (int) $conn->insert_id;
	$stmt->close();

	return ['ok' => true, 'error' => '', 'id' => $id, 'auto_approved' => !$submittedForReview];
}

function mc_pharmacist_recalc_performance(mysqli $conn, int $pharmacistId): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacist_ratings', 'rating_id')) {
		return;
	}
	$res = $conn->query(
		"SELECT AVG(score) AS avg_s, COUNT(*) AS c FROM mc_pharmacist_ratings WHERE pharmacist_id = {$pharmacistId}"
	);
	if (!$res || !($row = $res->fetch_assoc())) {
		return;
	}
	$avg = round((float) ($row['avg_s'] ?? 0), 2);
	$cnt = (int) ($row['c'] ?? 0);
	$stmt = $conn->prepare(
		'UPDATE mc_pharmacists SET performance_score = ?, rating_count = ? WHERE pharmacist_id = ? LIMIT 1'
	);
	if ($stmt) {
		$stmt->bind_param('dii', $avg, $cnt, $pharmacistId);
		$stmt->execute();
		$stmt->close();
	}
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_pharmacist_list_approved(mysqli $conn, int $limit = 50): array
{
	$rows = [];
	$limit = max(1, min(200, $limit));
	$where = mc_pharmacist_has_approval_columns($conn)
		? "approval_status = 'approved' AND is_active = 1"
		: 'is_active = 1';
	$res = $conn->query(
		"SELECT pharmacist_id, username, first_name, last_name, bio, performance_score, rating_count, pharmacy_id
		FROM mc_pharmacists WHERE {$where} ORDER BY performance_score DESC, rating_count DESC LIMIT {$limit}"
	);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$rows[] = $r;
		}
	}

	return $rows;
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_pharmacist_messages(mysqli $conn, int $pharmacistId, string $channel): array
{
	$rows = [];
	if (!mc_table_has_column($conn, 'mc_pharmacist_messages', 'message_id')) {
		return $rows;
	}
	$allowed = ['user', 'admin', 'work'];
	if (!in_array($channel, $allowed, true)) {
		$channel = 'user';
	}
	$stmt = $conn->prepare(
		'SELECT message_id, channel, sender_type, body, created_at, member_id, admin_id, sender_pharmacist_id
		FROM mc_pharmacist_messages WHERE pharmacist_id = ? AND channel = ? ORDER BY message_id ASC LIMIT 200'
	);
	if ($stmt) {
		$stmt->bind_param('is', $pharmacistId, $channel);
		$stmt->execute();
		$res = $stmt->get_result();
		while ($r = $res->fetch_assoc()) {
			$rows[] = $r;
		}
		$stmt->close();
	}

	return $rows;
}

function mc_pharmacist_post_message(
	mysqli $conn,
	int $pharmacistId,
	string $channel,
	string $senderType,
	string $body,
	?int $memberId = null,
	?int $adminId = null,
	?int $senderPharmacistId = null
): bool {
	if (!mc_table_has_column($conn, 'mc_pharmacist_messages', 'message_id') || trim($body) === '') {
		return false;
	}
	$stmt = $conn->prepare(
		'INSERT INTO mc_pharmacist_messages (pharmacist_id, channel, sender_type, member_id, admin_id, sender_pharmacist_id, body)
		VALUES (?,?,?,?,?,?,?)'
	);
	if (!$stmt) {
		return false;
	}
	$mid = $memberId ?? 0;
	$aid = $adminId ?? 0;
	$spid = $senderPharmacistId ?? 0;
	$stmt->bind_param('issiiis', $pharmacistId, $channel, $senderType, $mid, $aid, $spid, $body);
	$ok = $stmt->execute();
	$stmt->close();

	return $ok;
}
