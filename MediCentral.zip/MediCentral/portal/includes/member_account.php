<?php

declare(strict_types=1);

function mc_member_update_profile(
	mysqli $conn,
	int $memberId,
	string $firstName,
	string $lastName,
	?string $email,
	?string $phone
): array {
	if ($memberId <= 0) {
		return ['ok' => false, 'msg' => 'Not signed in.'];
	}
	$firstName = trim($firstName);
	if ($firstName === '') {
		return ['ok' => false, 'msg' => 'First name is required.'];
	}
	$lastName = trim($lastName);
	$email = $email !== null && trim($email) !== '' ? trim($email) : null;
	$phone = $phone !== null && trim($phone) !== '' ? trim($phone) : null;

	if ($email !== null) {
		$chk = $conn->prepare('SELECT 1 FROM mc_members WHERE email = ? AND member_id != ? LIMIT 1');
		if ($chk) {
			$chk->bind_param('si', $email, $memberId);
			$chk->execute();
			$chk->store_result();
			if ($chk->num_rows > 0) {
				$chk->close();

				return ['ok' => false, 'msg' => 'That email is already used by another account.'];
			}
			$chk->close();
		}
	}

	$st = $conn->prepare(
		'UPDATE mc_members SET first_name = ?, last_name = ?, email = ?, phone = ? WHERE member_id = ? LIMIT 1'
	);
	if (!$st) {
		return ['ok' => false, 'msg' => 'Could not update profile.'];
	}
	$st->bind_param('ssssi', $firstName, $lastName, $email, $phone, $memberId);
	$ok = $st->execute();
	$st->close();

	return $ok
		? ['ok' => true, 'msg' => 'Profile updated successfully.']
		: ['ok' => false, 'msg' => 'Could not update profile.'];
}

function mc_member_change_password(
	mysqli $conn,
	int $memberId,
	string $current,
	string $newPassword
): array {
	if ($memberId <= 0) {
		return ['ok' => false, 'msg' => 'Not signed in.'];
	}
	if (strlen($newPassword) < 8) {
		return ['ok' => false, 'msg' => 'New password must be at least 8 characters.'];
	}

	$st = $conn->prepare('SELECT password_hash FROM mc_members WHERE member_id = ? LIMIT 1');
	if (!$st) {
		return ['ok' => false, 'msg' => 'Could not verify password.'];
	}
	$st->bind_param('i', $memberId);
	$st->execute();
	$hash = '';
	$st->bind_result($hash);
	$found = $st->fetch();
	$st->close();

	if (!$found || !password_verify($current, $hash)) {
		return ['ok' => false, 'msg' => 'Current password is incorrect.'];
	}

	$newHash = password_hash($newPassword, PASSWORD_DEFAULT);
	$upd = $conn->prepare('UPDATE mc_members SET password_hash = ? WHERE member_id = ? LIMIT 1');
	if (!$upd) {
		return ['ok' => false, 'msg' => 'Could not save new password.'];
	}
	$upd->bind_param('si', $newHash, $memberId);
	$ok = $upd->execute();
	$upd->close();

	return $ok
		? ['ok' => true, 'msg' => 'Password changed successfully.']
		: ['ok' => false, 'msg' => 'Could not save new password.'];
}
