<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/auth_helpers.php';

mc_session_start();

if (($_SESSION['mc_role'] ?? '') !== 'admin') {
	mc_portal_redirect('pharmacy/signin.php');
}
