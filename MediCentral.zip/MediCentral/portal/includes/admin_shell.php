<?php

declare(strict_types=1);

require_once __DIR__ . '/auth_helpers.php';
require_once __DIR__ . '/site_footer.php';
require_once __DIR__ . '/site_contact.php';
require_once __DIR__ . '/site_nav.php';

function mc_admin_db_conn(): mysqli
{
	if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli) {
		return $GLOBALS['conn'];
	}
	require_once dirname(__DIR__) . '/config.php';
	if (!isset($GLOBALS['conn']) || !($GLOBALS['conn'] instanceof mysqli)) {
		throw new RuntimeException('Database connection unavailable.');
	}

	return $GLOBALS['conn'];
}

/**
 * @param 'dashboard'|'pharmacists'|'messages'|'recruitment'|'inventory'|'suppliers'|'purchases'|'customers'|'morders'|'sales'|'sold'|'stock'|'settings'|'contact'|'detail' $active
 */
function mc_admin_shell_start(string $pageTitle, string $active): void
{
	$conn = mc_admin_db_conn();
	mc_set_signin_portal('pharmacy');
	$nav = [
		'dashboard' => ['Overview', 'dashboard.php'],
		'messages' => ['Messages & chat', 'messages.php'],
		'recruitment' => ['Recruitment', 'recruitment.php'],
		'pharmacists' => ['Pharmacy staff', 'pharmacists.php'],
		'inventory' => ['Drugs & barcodes', 'inventory.php'],
		'suppliers' => ['Suppliers', 'suppliers.php'],
		'purchases' => ['Purchases', 'purchases.php'],
		'customers' => ['Customers', 'customers.php'],
		'morders' => ['Member orders', 'member-orders.php'],
		'stock' => ['Stock health', 'stock-health.php'],
		'sales' => ['Sales report', 'sales-report.php'],
		'sold' => ['Sold lines', 'sold-products.php'],
		'settings' => ['Account', 'settings.php'],
		'contact' => ['Contact inbox', 'contact-inbox.php'],
	];
	$user = htmlspecialchars((string) ($_SESSION['mc_username'] ?? ''), ENT_QUOTES, 'UTF-8');
	$adminId = (int) ($_SESSION['mc_admin_id'] ?? 0);
	$contactUnread = mc_contact_unread_count($conn, $adminId);
	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
	echo '<title>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . ' · MediCentral Admin</title>';
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
	echo '<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">';
	echo '<link rel="stylesheet" href="../css/admin-dashboard.css">';
	echo '<link rel="stylesheet" href="../css/dr-aklilu.css">';
	echo '</head><body class="adm-body"><div class="adm-layout">';
	echo '<aside class="adm-sidebar">';
	echo '<a href="../member/index.php" class="adm-brand adm-brand-link" title="Open public member site"><span class="adm-mark"></span><div><strong>MediCentral</strong><small>Administrator</small></div></a>';
	$pubNav = mc_site_nav_items('admin_public', '../');
	echo '<div class="adm-pub-links"><span class="adm-pub-label">Site</span>';
	foreach ($pubNav as $item) {
		echo '<a class="adm-nav-link adm-nav-public" href="' . htmlspecialchars($item['href'], ENT_QUOTES, 'UTF-8') . '">'
			. htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') . '</a>';
	}
	echo '</div>';
	echo '<nav class="adm-nav">';
	foreach ($nav as $slug => $pair) {
		$lbl = htmlspecialchars($pair[0], ENT_QUOTES, 'UTF-8');
		$href = htmlspecialchars($pair[1], ENT_QUOTES, 'UTF-8');
		$isSaleDetailPage = ($active === 'detail' && $slug === 'sales');
		$cls = ($active === $slug || $isSaleDetailPage) ? ' adm-nav-link is-active' : ' adm-nav-link';
		$badge = ($slug === 'contact' && $contactUnread > 0)
			? ' <span class="adm-nav-badge">' . $contactUnread . '</span>' : '';
		echo '<a class="' . trim($cls) . '" href="' . $href . '">' . $lbl . $badge . '</a>';
	}
	echo '</nav>';
	echo '<div class="adm-sidefoot"><span class="adm-user">' . $user . '</span>';
	echo '<a class="adm-out" href="../logout.php?to=pharmacy">Sign out</a>';
	echo '</div></aside>';
	echo '<main class="adm-main"><header class="adm-top"><h1>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . '</h1>';
	echo '<div class="adm-top-actions"><a class="adm-top-link" href="../member/index.php" target="_blank" rel="noopener">View member site ↗</a>';
	echo '<a class="adm-top-link" href="../pharmacy/signin.php">Operations sign-in</a>';
	echo '<a class="adm-top-link" href="../index.php">Network sign-in</a></div></header>';
	echo '<div class="adm-content">';
}

function mc_admin_shell_end(): void
{
	echo '</div>';
	mc_render_site_footer();
	require_once __DIR__ . '/dr_aklilu_panel.php';
	mc_dr_aklilu_render_panel('pharmacy', '../');
	echo '<script src="../js/dr-aklilu-format.js" defer></script>';
	echo '<script src="../js/dr-aklilu.js" defer></script>';
	echo '</main></div></body></html>';
}

function mc_admin_flash(string $msg, string $kind = 'info'): void
{
	$c = $kind === 'success' ? 'adm-flash success' : ($kind === 'error' ? 'adm-flash error' : 'adm-flash');
	echo '<div class="' . htmlspecialchars($c, ENT_QUOTES, 'UTF-8') . '" role="status">' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</div>';
}
