<?php

declare(strict_types=1);

require_once __DIR__ . '/currency.php';

function mc_upgrade_member_order_payment_schema(mysqli $conn): void
{
	$orderCols = [
		'prescription_path' => 'VARCHAR(500) NULL AFTER `order_note`',
		'prescription_qr_text' => 'TEXT NULL AFTER `prescription_path`',
		'telebirr_transaction_id' => 'VARCHAR(80) NULL AFTER `prescription_qr_text`',
		'telebirr_submitted_at' => 'TIMESTAMP NULL DEFAULT NULL AFTER `telebirr_transaction_id`',
	];
	foreach ($orderCols as $col => $def) {
		if (mc_table_has_column($conn, 'mc_member_orders', 'order_id') && !mc_table_has_column($conn, 'mc_member_orders', $col)) {
			@$conn->query("ALTER TABLE `mc_member_orders` ADD COLUMN `{$col}` {$def}");
		}
	}
	if (mc_table_has_column($conn, 'mc_pharmacies', 'pharmacy_id') && !mc_table_has_column($conn, 'mc_pharmacies', 'telebirr_phone')) {
		@$conn->query('ALTER TABLE `mc_pharmacies` ADD COLUMN `telebirr_phone` VARCHAR(40) NULL AFTER `phone`');
	}
}

function mc_prescription_upload_dir(): string
{
	return dirname(__DIR__) . '/uploads/prescriptions';
}

/**
 * @return array{ok: bool, path: string, error: string}
 */
function mc_member_save_prescription_upload(int $memberId, array $file): array
{
	if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
		return ['ok' => false, 'path' => '', 'error' => 'Prescription photo is required (upload an image or scan a QR).'];
	}
	$size = (int) ($file['size'] ?? 0);
	if ($size <= 0 || $size > 5_000_000) {
		return ['ok' => false, 'path' => '', 'error' => 'Prescription image must be under 5 MB.'];
	}
	$tmp = (string) ($file['tmp_name'] ?? '');
	if ($tmp === '' || !is_readable($tmp)) {
		return ['ok' => false, 'path' => '', 'error' => 'Could not read uploaded file.'];
	}
	$finfo = new finfo(FILEINFO_MIME_TYPE);
	$mime = $finfo->file($tmp) ?: '';
	$allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
	if (!isset($allowed[$mime])) {
		return ['ok' => false, 'path' => '', 'error' => 'Use a JPG, PNG, WebP, or PDF prescription.'];
	}
	$base = mc_prescription_upload_dir();
	if (!is_dir($base) && !mkdir($base, 0755, true) && !is_dir($base)) {
		return ['ok' => false, 'path' => '', 'error' => 'Upload folder is not writable.'];
	}
	$memberDir = $base . '/' . $memberId;
	if (!is_dir($memberDir) && !mkdir($memberDir, 0755, true) && !is_dir($memberDir)) {
		return ['ok' => false, 'path' => '', 'error' => 'Could not create upload folder.'];
	}
	$name = 'rx_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];
	$dest = $memberDir . '/' . $name;
	if (!move_uploaded_file($tmp, $dest)) {
		return ['ok' => false, 'path' => '', 'error' => 'Could not save prescription file.'];
	}

	return ['ok' => true, 'path' => 'uploads/prescriptions/' . $memberId . '/' . $name, 'error' => ''];
}

function mc_pharmacy_telebirr_phone(array $pharmacyRow): string
{
	$tb = trim((string) ($pharmacyRow['telebirr_phone'] ?? ''));
	if ($tb !== '') {
		return $tb;
	}

	return trim((string) ($pharmacyRow['phone'] ?? ''));
}

/**
 * @param array{pharmacy_id: int, drug_id: int, qty: int, note?: ?string, prescription_path: string, prescription_qr?: ?string} $in
 * @return array{ok: bool, msg: string, order_id?: int}
 */
function mc_member_place_order_with_prescription(mysqli $conn, int $memberId, array $in): array
{
	mc_upgrade_member_order_payment_schema($conn);

	$pharmacyId = (int) ($in['pharmacy_id'] ?? 0);
	$drugId = (int) ($in['drug_id'] ?? 0);
	$qty = (int) ($in['qty'] ?? 0);
	$note = isset($in['note']) ? trim((string) $in['note']) : '';
	$noteDb = $note === '' ? null : $note;
	$rxPath = trim((string) ($in['prescription_path'] ?? ''));
	$rxQr = trim((string) ($in['prescription_qr'] ?? ''));
	$rxQrDb = $rxQr === '' ? null : mb_substr($rxQr, 0, 2000);

	if ($memberId <= 0 || $pharmacyId <= 0 || $drugId <= 0 || $qty <= 0) {
		return ['ok' => false, 'msg' => 'Invalid order request.'];
	}
	if ($rxPath === '' && $rxQrDb === null) {
		return ['ok' => false, 'msg' => 'Upload a prescription photo or scan the prescription QR code.'];
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$conn->begin_transaction();

		$st = $conn->prepare(
			'SELECT i.quantity, COALESCE(i.unit_price, d.unit_price) AS price
			FROM mc_pharmacy_inventory i
			INNER JOIN mc_drugs d ON d.drug_id = i.drug_id
			WHERE i.pharmacy_id = ? AND i.drug_id = ? LIMIT 1 FOR UPDATE'
		);
		if (!$st) {
			throw new RuntimeException('prep');
		}
		$st->bind_param('ii', $pharmacyId, $drugId);
		$st->execute();
		$stk = 0;
		$price = 0.0;
		$st->bind_result($stk, $price);
		if (!$st->fetch()) {
			$st->close();
			throw new RuntimeException('notfound');
		}
		$st->close();

		if ($stk < $qty) {
			throw new RuntimeException('stock');
		}

		$lineTotal = round($qty * (float) $price, 2);
		$status = 'awaiting_payment';
		$rxPathDb = $rxPath === '' ? null : $rxPath;

		$ins = $conn->prepare(
			'INSERT INTO mc_member_orders (member_id, pharmacy_id, status, total_amount, order_note, prescription_path, prescription_qr_text)
			 VALUES (?,?,?,?,?,?,?)'
		);
		if (!$ins) {
			throw new RuntimeException('order');
		}
		$ins->bind_param('iisdsss', $memberId, $pharmacyId, $status, $lineTotal, $noteDb, $rxPathDb, $rxQrDb);
		if (!$ins->execute()) {
			$ins->close();
			throw new RuntimeException('order');
		}
		$orderId = (int) $conn->insert_id;
		$ins->close();

		$ln = $conn->prepare(
			'INSERT INTO mc_member_order_lines (order_id, drug_id, qty, unit_price, line_total) VALUES (?,?,?,?,?)'
		);
		if (!$ln || !$ln->bind_param('iiidd', $orderId, $drugId, $qty, $price, $lineTotal) || !$ln->execute()) {
			if ($ln) {
				$ln->close();
			}
			throw new RuntimeException('line');
		}
		$ln->close();

		$conn->commit();

		return [
			'ok' => true,
			'msg' => 'Prescription received. Complete Tele Birr payment to confirm order #' . $orderId . '.',
			'order_id' => $orderId,
		];
	} catch (Throwable $e) {
		@$conn->rollback();

		return match ($e->getMessage()) {
			'stock' => ['ok' => false, 'msg' => 'Not enough stock at that pharmacy.'],
			'notfound' => ['ok' => false, 'msg' => 'This product is not listed at the selected pharmacy.'],
			default => ['ok' => false, 'msg' => 'Could not place order. Try again.'],
		};
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

/**
 * @return array{ok: bool, msg: string}
 */
function mc_member_submit_telebirr_payment(mysqli $conn, int $memberId, int $orderId, string $transactionId): array
{
	mc_upgrade_member_order_payment_schema($conn);
	$transactionId = trim($transactionId);
	if ($orderId <= 0 || $transactionId === '') {
		return ['ok' => false, 'msg' => 'Enter your Tele Birr transaction ID.'];
	}
	if (!preg_match('/^[A-Za-z0-9\-]{6,40}$/', $transactionId)) {
		return ['ok' => false, 'msg' => 'Transaction ID looks invalid. Copy it exactly from your Tele Birr SMS or receipt.'];
	}

	require_once __DIR__ . '/telebirr_verify.php';
	$verify = mc_telebirr_verify_transaction($conn, $memberId, $orderId, $transactionId);
	if (!$verify['ok']) {
		return ['ok' => false, 'msg' => $verify['msg']];
	}
	$verifyStatus = (string) $verify['verdict'];
	$verifyNote = mb_substr((string) $verify['ai_note'], 0, 500);

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$conn->begin_transaction();

		$st = $conn->prepare(
			'SELECT pharmacy_id, status FROM mc_member_orders WHERE order_id = ? AND member_id = ? LIMIT 1 FOR UPDATE'
		);
		if (!$st) {
			throw new RuntimeException('prep');
		}
		$st->bind_param('ii', $orderId, $memberId);
		$st->execute();
		$res = $st->get_result();
		$row = $res ? $res->fetch_assoc() : null;
		$st->close();
		if (!$row) {
			throw new RuntimeException('notfound');
		}
		if ((string) $row['status'] !== 'awaiting_payment') {
			throw new RuntimeException('status');
		}
		$pharmacyId = (int) $row['pharmacy_id'];

		$lines = [];
		$lst = $conn->prepare('SELECT drug_id, qty FROM mc_member_order_lines WHERE order_id = ?');
		if (!$lst) {
			throw new RuntimeException('lines');
		}
		$lst->bind_param('i', $orderId);
		$lst->execute();
		$lres = $lst->get_result();
		if ($lres) {
			while ($ln = $lres->fetch_assoc()) {
				$lines[] = $ln;
			}
			$lres->free();
		}
		$lst->close();

		foreach ($lines as $ln) {
			$qty = (int) $ln['qty'];
			$did = (int) $ln['drug_id'];
			$upd = $conn->prepare(
				'UPDATE mc_pharmacy_inventory SET quantity = quantity - ? WHERE pharmacy_id = ? AND drug_id = ? AND quantity >= ?'
			);
			if (!$upd || !$upd->bind_param('iiii', $qty, $pharmacyId, $did, $qty) || !$upd->execute() || $upd->affected_rows !== 1) {
				if ($upd) {
					$upd->close();
				}
				throw new RuntimeException('stock');
			}
			$upd->close();
		}

		mc_upgrade_telebirr_verify_schema($conn);
		$hasVerifyCols = mc_table_has_column($conn, 'mc_member_orders', 'telebirr_verify_status');
		if ($hasVerifyCols) {
			$updOrder = $conn->prepare(
				"UPDATE mc_member_orders SET status = 'pending', telebirr_transaction_id = ?, telebirr_submitted_at = CURRENT_TIMESTAMP, telebirr_verify_status = ?, telebirr_verify_note = ? WHERE order_id = ? AND member_id = ?"
			);
			$bound = $updOrder && $updOrder->bind_param('sssii', $transactionId, $verifyStatus, $verifyNote, $orderId, $memberId) && $updOrder->execute();
		} else {
			$updOrder = $conn->prepare(
				"UPDATE mc_member_orders SET status = 'pending', telebirr_transaction_id = ?, telebirr_submitted_at = CURRENT_TIMESTAMP WHERE order_id = ? AND member_id = ?"
			);
			$bound = $updOrder && $updOrder->bind_param('sii', $transactionId, $orderId, $memberId) && $updOrder->execute();
		}
		if (!$bound) {
			if ($updOrder) {
				$updOrder->close();
			}
			throw new RuntimeException('pay');
		}
		$updOrder->close();

		$conn->commit();

		$msg = 'Payment recorded. Order #' . $orderId . ' is pending pharmacy confirmation.';
		if ($verifyStatus === 'uncertain') {
			$msg = 'Payment submitted. The pharmacy will verify your Tele Birr reference before confirming.';
		} elseif (!empty($verify['ai_used'])) {
			$msg .= ' Dr. Aklilu checked the transaction ID format.';
		}

		return ['ok' => true, 'msg' => $msg];
	} catch (Throwable $e) {
		@$conn->rollback();

		return match ($e->getMessage()) {
			'notfound' => ['ok' => false, 'msg' => 'Order not found.'],
			'status' => ['ok' => false, 'msg' => 'This order is not waiting for payment.'],
			'stock' => ['ok' => false, 'msg' => 'Item went out of stock before payment could be confirmed.'],
			default => ['ok' => false, 'msg' => 'Could not save payment. Try again.'],
		};
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

/**
 * @return array<string, mixed>|null
 */
function mc_member_load_order_for_payment(mysqli $conn, int $memberId, int $orderId): ?array
{
	mc_upgrade_member_order_payment_schema($conn);
	$sql = <<<'SQL'
SELECT o.order_id, o.status, o.total_amount, o.order_note, o.prescription_path, o.prescription_qr_text,
  o.telebirr_transaction_id, o.created_at,
  ph.name AS pharmacy_name, ph.phone, ph.telebirr_phone, ph.city
FROM mc_member_orders o
INNER JOIN mc_pharmacies ph ON ph.pharmacy_id = o.pharmacy_id
WHERE o.order_id = ? AND o.member_id = ?
SQL;
	$st = $conn->prepare($sql);
	if (!$st) {
		return null;
	}
	$st->bind_param('ii', $orderId, $memberId);
	$st->execute();
	$res = $st->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$st->close();
	if (!$row) {
		return null;
	}
	$row['telebirr_display_phone'] = mc_pharmacy_telebirr_phone($row);
	$row['lines'] = [];
	$lst = $conn->prepare(
		'SELECT l.qty, l.line_total, d.name FROM mc_member_order_lines l INNER JOIN mc_drugs d ON d.drug_id = l.drug_id WHERE l.order_id = ?'
	);
	if ($lst) {
		$lst->bind_param('i', $orderId);
		$lst->execute();
		$lr = $lst->get_result();
		while ($ln = $lr->fetch_assoc()) {
			$row['lines'][] = $ln;
		}
		$lst->close();
	}

	return $row;
}
