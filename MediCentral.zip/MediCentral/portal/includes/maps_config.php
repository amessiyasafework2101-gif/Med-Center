<?php

declare(strict_types=1);

/**
 * Google Maps JavaScript API key for the nearby-pharmacy map.
 *
 * Easiest (WAMP/local): copy maps_config.local.php.example → maps_config.local.php
 * and set your key there (that file is not committed).
 *
 * Or set MC_GOOGLE_MAPS_API_KEY in the server environment.
 * Enable: Maps JavaScript API + Places API in Google Cloud Console.
 */
$localMaps = __DIR__ . '/maps_config.local.php';
if (is_readable($localMaps)) {
	require_once $localMaps;
}
if (!defined('MC_GOOGLE_MAPS_KEY')) {
	define('MC_GOOGLE_MAPS_KEY', '');
}

function mc_google_maps_api_key(): string
{
	if (defined('MC_GOOGLE_MAPS_KEY') && MC_GOOGLE_MAPS_KEY !== '') {
		return (string) MC_GOOGLE_MAPS_KEY;
	}
	$env = getenv('MC_GOOGLE_MAPS_API_KEY');

	return $env !== false ? trim($env) : '';
}

/** Map ID for Advanced Markers / Locator Plus (optional; DEMO_MAP_ID works for dev). */
function mc_google_maps_map_id(): string
{
	if (defined('MC_GOOGLE_MAPS_MAP_ID') && MC_GOOGLE_MAPS_MAP_ID !== '') {
		return (string) MC_GOOGLE_MAPS_MAP_ID;
	}
	$env = getenv('MC_GOOGLE_MAPS_MAP_ID');

	return $env !== false && trim($env) !== '' ? trim($env) : 'DEMO_MAP_ID';
}
