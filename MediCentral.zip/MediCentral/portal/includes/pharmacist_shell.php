<?php

declare(strict_types=1);

require_once __DIR__ . '/auth_helpers.php';
require_once __DIR__ . '/site_footer.php';

function mc_pharmacist_shell_start(string $pageTitle, string $displayName): void
{
	mc_set_signin_portal('pharmacy');
	$name = htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8');
	$initial = mb_strtoupper(mb_substr(trim($displayName), 0, 1, 'UTF-8'), 'UTF-8');
	if ($initial === '') {
		$initial = 'P';
	}

	$d = 'div';

	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
	echo '<title>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . ' · MediCentral</title>';
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
	echo '<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet">';
	echo '<link rel="stylesheet" href="css/signin.css">';
	echo '<link rel="stylesheet" href="css/pharmacist.css">';
	echo '<link rel="stylesheet" href="css/dr-aklilu.css">';
	echo '</head><body class="ph-body">';
	echo '<' . $d . ' class="ph-backdrop" aria-hidden="true"><' . $d . ' class="mc-backdrop"><' . $d . ' class="mc-grid"></' . $d . '>';
	echo '<' . $d . ' class="mc-orbits"><span class="mc-orbit"></span><span class="mc-orbit"></span><span class="mc-orbit"></span></' . $d . '></' . $d . '></' . $d . '>';
	echo '<' . $d . ' class="ph-shell">';
	echo '<header class="ph-top"><' . $d . ' class="ph-top-inner">';
	echo '<a href="pharmacist-home.php" class="ph-brand"><span class="ph-mark" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M12 4v16M4 12h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg></span>';
	echo '<' . $d . '><strong>MediCentral</strong><span>Pharmacist workspace</span></' . $d . '></a>';
	echo '<nav class="ph-toolbar" aria-label="Workspace actions">';
	echo '<a class="ph-tool" href="#pos-sale"><span class="ph-tool-ico" aria-hidden="true">◫</span> New sale</a>';
	echo '<a class="ph-tool" href="#recent-sales"><span class="ph-tool-ico" aria-hidden="true">◎</span> History</a>';
	echo '</nav>';
	echo '<' . $d . ' class="ph-user-bar">';
	echo '<span class="ph-avatar" aria-hidden="true">' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '</span>';
	echo '<span class="ph-user-name">' . $name . '</span>';
	echo '<a class="ph-signout" href="logout.php?to=pharmacy">Sign out</a>';
	echo '</' . $d . '></' . $d . '></header>';
	echo '<main class="ph-main">';
}

function mc_pharmacist_shell_end(): void
{
	$d = 'div';
	echo '</main>';
	mc_render_site_footer();
	echo '</' . $d . '>';
	require_once __DIR__ . '/dr_aklilu_panel.php';
	mc_dr_aklilu_render_panel('pharmacy', '');
	echo '<script src="js/dr-aklilu-format.js" defer></script>';
	echo '<script src="js/dr-aklilu.js" defer></script>';
	echo '</body></html>';
}

function mc_pharmacist_flash(string $msg, string $kind = 'info'): void
{
	$c = $kind === 'success' ? 'ph-flash success' : ($kind === 'error' ? 'ph-flash error' : 'ph-flash');
	echo '<div class="' . htmlspecialchars($c, ENT_QUOTES, 'UTF-8') . '" role="status">' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</div>';
}
