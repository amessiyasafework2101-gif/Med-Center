<?php

declare(strict_types=1);

/**
 * Paste your Google Maps API key below (between the quotes).
 * https://console.cloud.google.com/google/maps-apis/credentials
 * Enable: Maps JavaScript API + Places API
 */
define('MC_GOOGLE_MAPS_KEY', '');
