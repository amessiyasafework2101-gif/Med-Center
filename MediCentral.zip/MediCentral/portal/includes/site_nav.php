<?php

declare(strict_types=1);

/**
 * Standard site nav order: Home → About → Contact → other links.
 *
 * @return list<array{slug: string, label: string, href: string, icon?: string}>
 */
function mc_site_nav_items(string $context, string $assetPrefix = '../'): array
{
	$role = (string) ($_SESSION['mc_role'] ?? '');
	$items = [];

	if ($context === 'member') {
		$items = [
			['slug' => 'home', 'label' => 'Home', 'href' => 'index.php', 'icon' => '⌂'],
			['slug' => 'about', 'label' => 'About', 'href' => $assetPrefix . 'about.php', 'icon' => 'ℹ'],
			['slug' => 'contact', 'label' => 'Contact', 'href' => $assetPrefix . 'contact.php', 'icon' => '✉'],
			['slug' => 'nearby', 'label' => 'Nearby', 'href' => 'nearby.php', 'icon' => '⌖'],
			['slug' => 'pharmacists', 'label' => 'Pharmacists', 'href' => 'pharmacists.php', 'icon' => '◈'],
			['slug' => 'pharmacies', 'label' => 'Pharmacies', 'href' => 'pharmacies.php', 'icon' => '✚'],
			['slug' => 'search', 'label' => 'Search', 'href' => 'search.php', 'icon' => '⌕'],
			['slug' => 'orders', 'label' => 'Orders', 'href' => 'orders.php', 'icon' => '◫'],
			['slug' => 'scan', 'label' => 'Scan', 'href' => 'scan.php', 'icon' => '◎'],
			['slug' => 'ai', 'label' => 'Dr. Aklilu', 'href' => $assetPrefix . 'ai/index.php', 'icon' => '✦'],
			['slug' => 'account', 'label' => 'Account', 'href' => 'account.php', 'icon' => '◉'],
		];
	} elseif ($context === 'pharmacist') {
		$items = [
			['slug' => 'home', 'label' => 'Home', 'href' => 'index.php'],
			['slug' => 'about', 'label' => 'About', 'href' => $assetPrefix . 'about.php'],
			['slug' => 'contact', 'label' => 'Contact', 'href' => $assetPrefix . 'contact.php'],
			['slug' => 'chat', 'label' => 'Messages', 'href' => 'chat.php'],
			['slug' => 'opportunities', 'label' => 'Work offers', 'href' => 'opportunities.php'],
			['slug' => 'pos', 'label' => 'POS workspace', 'href' => $assetPrefix . 'pharmacist-home.php'],
			['slug' => 'ai', 'label' => 'Dr. Aklilu AI', 'href' => $assetPrefix . 'ai/index.php'],
		];
	} elseif ($context === 'ai') {
		$homeHref = $assetPrefix . 'index.php';
		$homeLabel = 'Home';
		if ($role === 'member' && (int) ($_SESSION['mc_member_id'] ?? 0) > 0) {
			$homeHref = $assetPrefix . 'member/index.php';
		} elseif ($role === 'pharmacist' && (int) ($_SESSION['mc_pharmacist_id'] ?? 0) > 0) {
			$homeHref = $assetPrefix . 'pharmacist/index.php';
		}
		$items = [
			['slug' => 'home', 'label' => $homeLabel, 'href' => $homeHref],
			['slug' => 'about', 'label' => 'About', 'href' => $assetPrefix . 'about.php'],
			['slug' => 'contact', 'label' => 'Contact', 'href' => $assetPrefix . 'contact.php'],
			['slug' => 'ai', 'label' => 'Dr. Aklilu AI', 'href' => $assetPrefix . 'ai/index.php'],
		];
	} elseif ($context === 'admin_public') {
		$items = [
			['slug' => 'home', 'label' => 'Home', 'href' => $assetPrefix . 'index.php'],
			['slug' => 'about', 'label' => 'About', 'href' => $assetPrefix . 'about.php'],
			['slug' => 'contact', 'label' => 'Contact', 'href' => $assetPrefix . 'contact.php'],
			['slug' => 'member', 'label' => 'Member portal', 'href' => $assetPrefix . 'member/index.php'],
			['slug' => 'ops', 'label' => 'Operations', 'href' => $assetPrefix . 'pharmacy/signin.php'],
		];
	} else {
		$homeHref = $assetPrefix . 'index.php';
		if ($role === 'member' && (int) ($_SESSION['mc_member_id'] ?? 0) > 0) {
			$homeHref = $assetPrefix . 'member/index.php';
		} elseif ($role === 'pharmacist' && (int) ($_SESSION['mc_pharmacist_id'] ?? 0) > 0) {
			$homeHref = $assetPrefix . 'pharmacist/index.php';
		}
		$items = [
			['slug' => 'home', 'label' => 'Home', 'href' => $homeHref],
			['slug' => 'about', 'label' => 'About us', 'href' => $assetPrefix . 'about.php'],
			['slug' => 'contact', 'label' => 'Contact us', 'href' => $assetPrefix . 'contact.php'],
		];
		if (in_array($role, ['member', 'pharmacist'], true)) {
			$items[] = ['slug' => 'ai', 'label' => 'Dr. Aklilu AI', 'href' => $assetPrefix . 'ai/index.php'];
		}
	}

	return $items;
}

/**
 * @param list<array{slug: string, label: string, href: string, icon?: string}> $items
 */
function mc_render_site_nav_pills(string $active, array $items, string $linkClass, string $activeClass): void
{
	foreach ($items as $item) {
		$cls = $linkClass . ($active === $item['slug'] ? ' ' . $activeClass : '');
		$icon = isset($item['icon']) ? '<span class="mc-nav-ico" aria-hidden="true">' . htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') . '</span>' : '';
		echo '<a class="' . htmlspecialchars(trim($cls), ENT_QUOTES, 'UTF-8') . '" href="'
			. htmlspecialchars($item['href'], ENT_QUOTES, 'UTF-8') . '">' . $icon
			. htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') . '</a>';
	}
}

/**
 * Plain horizontal nav (public pages, AI page).
 *
 * @param list<array{slug: string, label: string, href: string, icon?: string}> $items
 */
function mc_render_site_nav_bar(string $active, array $items, string $navClass = 'mc-pub-nav'): void
{
	echo '<nav class="' . htmlspecialchars($navClass, ENT_QUOTES, 'UTF-8') . '" aria-label="Site">';
	foreach ($items as $item) {
		$activeAttr = $active === $item['slug'] ? ' class="is-active"' : '';
		echo '<a href="' . htmlspecialchars($item['href'], ENT_QUOTES, 'UTF-8') . '"' . $activeAttr . '>'
			. htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') . '</a>';
	}
	echo '</nav>';
}

/**
 * Footer links: Home · About · Contact (+ optional extras).
 *
 * @param list<array{slug: string, label: string, href: string}> $extra
 */
function mc_render_site_nav_footer(string $assetPrefix = '', array $extra = []): void
{
	$base = mc_site_nav_items('public', $assetPrefix === '' ? '' : $assetPrefix);
	$links = array_slice($base, 0, 3);
	foreach ($extra as $e) {
		$links[] = $e;
	}
	echo '<nav class="mc-foot-nav" aria-label="Footer">';
	foreach ($links as $link) {
		echo '<a href="' . htmlspecialchars($link['href'], ENT_QUOTES, 'UTF-8') . '">'
			. htmlspecialchars($link['label'], ENT_QUOTES, 'UTF-8') . '</a>';
	}
	echo '</nav>';
}
