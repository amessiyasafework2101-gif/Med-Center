<?php

declare(strict_types=1);

require_once __DIR__ . '/dr_aklilu_ui.php';

/**
 * Floating widget (members, pharmacists, admins).
 *
 * @param 'network'|'pharmacy' $portal
 */
function mc_dr_aklilu_render_panel(string $portal, string $assetPrefix = '../'): void
{
	$showCv = $portal === 'pharmacy';
	mc_dr_aklilu_render_ui($portal, $assetPrefix, 'widget', $showCv);
}
