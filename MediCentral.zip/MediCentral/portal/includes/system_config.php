<?php

declare(strict_types=1);

/**
 * Gate password for direct URL access to /portal/system/
 * Set MC_SYSTEM_GATE_PASSWORD in maps_config.local.php sibling or here.
 */
$localSys = __DIR__ . '/system_config.local.php';
if (is_readable($localSys)) {
	require_once $localSys;
}
if (!defined('MC_SYSTEM_GATE_PASSWORD')) {
	define('MC_SYSTEM_GATE_PASSWORD', '');
}

function mc_system_gate_password(): string
{
	if (defined('MC_SYSTEM_GATE_PASSWORD') && MC_SYSTEM_GATE_PASSWORD !== '') {
		return (string) MC_SYSTEM_GATE_PASSWORD;
	}
	$env = getenv('MC_SYSTEM_GATE_PASSWORD');

	return $env !== false ? trim($env) : '';
}
