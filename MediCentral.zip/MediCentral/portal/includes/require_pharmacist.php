<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/session.php';

mc_session_start();

if (($_SESSION['mc_role'] ?? '') !== 'pharmacist') {
	header('Location: pharmacy/signin.php');
	exit;
}
