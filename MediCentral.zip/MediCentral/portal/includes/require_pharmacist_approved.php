<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/pharmacist_pro.php';

mc_session_start();

if (($_SESSION['mc_role'] ?? '') !== 'pharmacist' || (int) ($_SESSION['mc_pharmacist_id'] ?? 0) <= 0) {
	header('Location: ../index.php');
	exit;
}

$pid = (int) $_SESSION['mc_pharmacist_id'];
$pharmacist = mc_pharmacist_load($conn, $pid);
if ($pharmacist === null) {
	header('Location: ../logout.php?to=network');
	exit;
}

if (mc_pharmacist_has_approval_columns($conn) && !mc_pharmacist_is_approved($pharmacist)) {
	header('Location: ../pharmacist/pending.php');
	exit;
}
