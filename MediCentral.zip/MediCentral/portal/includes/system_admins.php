<?php

declare(strict_types=1);

/**
 * @return array<int, array<string, mixed>>
 */
function mc_system_members_eligible_for_admin(mysqli $conn): array
{
	$rows = [];
	if (!mc_table_has_column($conn, 'mc_members', 'member_id')) {
		return $rows;
	}

	$sql = <<<'SQL'
SELECT m.member_id, m.username, m.first_name, m.last_name, m.email, m.phone
FROM mc_members m
WHERE m.is_active = 1
  AND m.member_id NOT IN (
    SELECT member_id FROM mc_admins WHERE member_id IS NOT NULL
  )
ORDER BY m.first_name ASC, m.last_name ASC, m.username ASC
SQL;
	$res = $conn->query($sql);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$rows[] = $r;
		}
	}

	return $rows;
}

/**
 * @return array{ok: bool, error: string, admin_id?: int}
 */
function mc_system_promote_member_to_pharmacy_admin(
	mysqli $conn,
	int $memberId,
	int $pharmacyId,
	string $password
): array {
	if ($memberId <= 0 || $pharmacyId <= 0) {
		return ['ok' => false, 'error' => 'Select a member and a pharmacy.'];
	}
	if (strlen($password) < 10) {
		return ['ok' => false, 'error' => 'Temporary password must be at least 10 characters.'];
	}

	$mStmt = $conn->prepare(
		'SELECT member_id, username, first_name, last_name, email FROM mc_members WHERE member_id = ? AND is_active = 1 LIMIT 1'
	);
	if (!$mStmt) {
		return ['ok' => false, 'error' => 'Could not load member.'];
	}
	$mStmt->bind_param('i', $memberId);
	$mStmt->execute();
	$res = $mStmt->get_result();
	$member = $res ? $res->fetch_assoc() : null;
	$mStmt->close();
	if (!$member) {
		return ['ok' => false, 'error' => 'Member not found or inactive.'];
	}

	$pStmt = $conn->prepare('SELECT 1 FROM mc_pharmacies WHERE pharmacy_id = ? AND is_active = 1 LIMIT 1');
	if (!$pStmt) {
		return ['ok' => false, 'error' => 'Could not verify pharmacy.'];
	}
	$pStmt->bind_param('i', $pharmacyId);
	$pStmt->execute();
	$pStmt->store_result();
	$phOk = $pStmt->num_rows > 0;
	$pStmt->close();
	if (!$phOk) {
		return ['ok' => false, 'error' => 'Pharmacy not found or inactive.'];
	}

	$user = mb_strtolower((string) $member['username'], 'UTF-8');
	$chk = $conn->prepare('SELECT 1 FROM mc_admins WHERE username = ? LIMIT 1');
	if ($chk) {
		$chk->bind_param('s', $user);
		$chk->execute();
		$chk->store_result();
		if ($chk->num_rows > 0) {
			$chk->close();

			return ['ok' => false, 'error' => 'That username is already used by an administrator.'];
		}
		$chk->close();
	}

	$dup = $conn->prepare('SELECT 1 FROM mc_admins WHERE member_id = ? LIMIT 1');
	if ($dup) {
		$dup->bind_param('i', $memberId);
		$dup->execute();
		$dup->store_result();
		if ($dup->num_rows > 0) {
			$dup->close();

			return ['ok' => false, 'error' => 'This member is already a pharmacy administrator.'];
		}
		$dup->close();
	}

	$h = password_hash($password, PASSWORD_DEFAULT);
	$fname = (string) $member['first_name'];
	$lname = (string) ($member['last_name'] ?? '');
	$mail = trim((string) ($member['email'] ?? ''));
	$mailVal = $mail === '' ? null : $mail;

	if (mc_table_has_column($conn, 'mc_admins', 'member_id')) {
		$stmt = $conn->prepare(
			'INSERT INTO mc_admins (username, password_hash, first_name, last_name, email, pharmacy_id, member_id) VALUES (?,?,?,?,?,?,?)'
		);
		if (!$stmt) {
			return ['ok' => false, 'error' => 'Could not create administrator.'];
		}
		$stmt->bind_param('sssssii', $user, $h, $fname, $lname, $mailVal, $pharmacyId, $memberId);
	} else {
		$stmt = $conn->prepare(
			'INSERT INTO mc_admins (username, password_hash, first_name, last_name, email) VALUES (?,?,?,?,?)'
		);
		if (!$stmt) {
			return ['ok' => false, 'error' => 'Could not create administrator.'];
		}
		$stmt->bind_param('sssss', $user, $h, $fname, $lname, $mailVal);
	}

	if (!$stmt->execute()) {
		$err = $stmt->error;
		$stmt->close();

		return ['ok' => false, 'error' => 'Create failed: ' . $err];
	}
	$adminId = (int) $conn->insert_id;
	$stmt->close();

	return ['ok' => true, 'error' => '', 'admin_id' => $adminId];
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_system_list_pharmacy_admins(mysqli $conn): array
{
	$rows = [];
	$hasPh = mc_table_has_column($conn, 'mc_admins', 'pharmacy_id');
	$hasMem = mc_table_has_column($conn, 'mc_admins', 'member_id');

	$sql = 'SELECT a.admin_id, a.username, a.first_name, a.last_name, a.email, a.created_at, a.last_login_at';
	if ($hasPh) {
		$sql .= ', a.pharmacy_id, ph.name AS pharmacy_name';
	}
	if ($hasMem) {
		$sql .= ', a.member_id';
	}
	$sql .= ' FROM mc_admins a';
	if ($hasPh) {
		$sql .= ' LEFT JOIN mc_pharmacies ph ON ph.pharmacy_id = a.pharmacy_id';
	}
	$sql .= ' ORDER BY a.admin_id DESC';

	$res = $conn->query($sql);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$rows[] = $r;
		}
	}

	return $rows;
}
