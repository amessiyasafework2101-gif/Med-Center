<?php

declare(strict_types=1);

require_once __DIR__ . '/member_order_payment.php';

/**
 * @return array{total: int, pending: int, awaiting_payment: int, confirmed: int, cancelled: int, spent: float}
 */
function mc_member_order_stats(mysqli $conn, int $memberId): array
{
	$out = ['total' => 0, 'pending' => 0, 'awaiting_payment' => 0, 'confirmed' => 0, 'cancelled' => 0, 'spent' => 0.0];
	if ($memberId <= 0) {
		return $out;
	}
	$sql = <<<'SQL'
SELECT COUNT(*) AS total,
  SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_cnt,
  SUM(CASE WHEN status = 'awaiting_payment' THEN 1 ELSE 0 END) AS awaiting_cnt,
  SUM(CASE WHEN status IN ('confirmed', 'ready') THEN 1 ELSE 0 END) AS confirmed_cnt,
  SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_cnt,
  COALESCE(SUM(CASE WHEN status NOT IN ('cancelled', 'awaiting_payment') THEN total_amount ELSE 0 END), 0) AS spent
FROM mc_member_orders WHERE member_id = ?
SQL;
	$st = $conn->prepare($sql);
	if (!$st) {
		return $out;
	}
	$st->bind_param('i', $memberId);
	$st->execute();
	$res = $st->get_result();
	if ($res && ($row = $res->fetch_assoc())) {
		$out['total'] = (int) $row['total'];
		$out['pending'] = (int) $row['pending_cnt'];
		$out['awaiting_payment'] = (int) $row['awaiting_cnt'];
		$out['confirmed'] = (int) $row['confirmed_cnt'];
		$out['cancelled'] = (int) $row['cancelled_cnt'];
		$out['spent'] = (float) $row['spent'];
		$res->free();
	}
	$st->close();

	return $out;
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_member_load_orders(mysqli $conn, int $memberId, string $statusFilter = ''): array
{
	if ($memberId <= 0) {
		return [];
	}

	$statusFilter = trim($statusFilter);
	$allowed = ['awaiting_payment', 'pending', 'confirmed', 'ready', 'cancelled'];
	if ($statusFilter !== '' && !in_array($statusFilter, $allowed, true)) {
		$statusFilter = '';
	}

	$sql = <<<'SQL'
SELECT o.order_id, o.pharmacy_id, o.status, o.total_amount, o.order_note, o.created_at,
  o.prescription_path, o.telebirr_transaction_id, ph.name AS pharmacy_name
FROM mc_member_orders o
INNER JOIN mc_pharmacies ph ON ph.pharmacy_id = o.pharmacy_id
WHERE o.member_id = ?
SQL;
	$types = 'i';
	$params = [$memberId];
	if ($statusFilter !== '') {
		$sql .= ' AND o.status = ?';
		$types .= 's';
		$params[] = $statusFilter;
	}
	$sql .= ' ORDER BY o.created_at DESC LIMIT 50';

	$orderRows = [];
	$st = $conn->prepare($sql);
	if (!$st) {
		return [];
	}
	$st->bind_param($types, ...$params);
	$st->execute();
	$res = $st->get_result();
	if ($res) {
		while ($row = $res->fetch_assoc()) {
			$row['lines'] = [];
			$orderRows[(int) $row['order_id']] = $row;
		}
		$res->free();
	}
	$st->close();

	if ($orderRows === []) {
		return [];
	}

	$ids = implode(',', array_map('intval', array_keys($orderRows)));
	$lineSql = 'SELECT l.order_id, l.drug_id, d.name, l.qty, l.line_total
		FROM mc_member_order_lines l
		INNER JOIN mc_drugs d ON d.drug_id = l.drug_id
		WHERE l.order_id IN (' . $ids . ')
		ORDER BY d.name ASC';
	$lr = $conn->query($lineSql);
	if ($lr) {
		while ($line = $lr->fetch_assoc()) {
			$oid = (int) $line['order_id'];
			if (isset($orderRows[$oid])) {
				$orderRows[$oid]['lines'][] = [
					'drug_id' => (int) $line['drug_id'],
					'name' => (string) $line['name'],
					'qty' => (int) $line['qty'],
					'line_total' => (float) $line['line_total'],
				];
			}
		}
	}

	return array_values($orderRows);
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_member_load_recent_orders(mysqli $conn, int $memberId, int $limit = 5): array
{
	if ($memberId <= 0 || $limit < 1) {
		return [];
	}
	$all = mc_member_load_orders($conn, $memberId, '');

	return array_slice($all, 0, $limit);
}

function mc_member_cancel_order(mysqli $conn, int $memberId, int $orderId): array
{
	if ($memberId <= 0 || $orderId <= 0) {
		return ['ok' => false, 'msg' => 'Invalid request.'];
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$conn->begin_transaction();

		$st = $conn->prepare(
			'SELECT pharmacy_id, status FROM mc_member_orders WHERE order_id = ? AND member_id = ? LIMIT 1 FOR UPDATE'
		);
		if (!$st) {
			throw new RuntimeException('prep');
		}
		$st->bind_param('ii', $orderId, $memberId);
		$st->execute();
		$res = $st->get_result();
		$row = $res ? $res->fetch_assoc() : null;
		if ($res) {
			$res->free();
		}
		$st->close();

		if (!$row) {
			throw new RuntimeException('notfound');
		}
		$status = (string) $row['status'];
		if (!in_array($status, ['pending', 'awaiting_payment'], true)) {
			throw new RuntimeException('status');
		}
		$pharmacyId = (int) $row['pharmacy_id'];

		if ($status === 'pending') {
			$lines = [];
			$lst = $conn->prepare(
				'SELECT drug_id, qty FROM mc_member_order_lines WHERE order_id = ?'
			);
			if (!$lst) {
				throw new RuntimeException('lines');
			}
			$lst->bind_param('i', $orderId);
			$lst->execute();
			$lres = $lst->get_result();
			if ($lres) {
				while ($ln = $lres->fetch_assoc()) {
					$lines[] = $ln;
				}
				$lres->free();
			}
			$lst->close();

			$updInv = $conn->prepare(
				'UPDATE mc_pharmacy_inventory SET quantity = quantity + ? WHERE pharmacy_id = ? AND drug_id = ?'
			);
			if (!$updInv) {
				throw new RuntimeException('stock');
			}
			foreach ($lines as $ln) {
				$qty = (int) $ln['qty'];
				$did = (int) $ln['drug_id'];
				if (!$updInv->bind_param('iii', $qty, $pharmacyId, $did) || !$updInv->execute()) {
					throw new RuntimeException('stock');
				}
			}
			$updInv->close();
		}

		$upd = $conn->prepare(
			'UPDATE mc_member_orders SET status = ? WHERE order_id = ? AND member_id = ?'
		);
		if (!$upd) {
			throw new RuntimeException('cancel');
		}
		$cancelled = 'cancelled';
		$upd->bind_param('sii', $cancelled, $orderId, $memberId);
		if (!$upd->execute()) {
			$upd->close();
			throw new RuntimeException('cancel');
		}
		$upd->close();

		$conn->commit();

		$msg = $status === 'pending'
			? 'Order #' . $orderId . ' was cancelled and stock was returned to the pharmacy.'
			: 'Order #' . $orderId . ' was cancelled before payment.';

		return ['ok' => true, 'msg' => $msg];
	} catch (Throwable $e) {
		@$conn->rollback();

		return match ($e->getMessage()) {
			'notfound' => ['ok' => false, 'msg' => 'Order not found.'],
			'status' => ['ok' => false, 'msg' => 'This order cannot be cancelled.'],
			default => ['ok' => false, 'msg' => 'Could not cancel this order. Try again.'],
		};
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

function mc_member_order_status_label(string $status): string
{
	return match ($status) {
		'awaiting_payment' => 'Awaiting Tele Birr payment',
		'pending' => 'Pending pharmacy confirmation',
		'confirmed' => 'Confirmed',
		'ready' => 'Ready for pickup',
		'cancelled' => 'Cancelled',
		default => ucfirst(str_replace('_', ' ', $status)),
	};
}
