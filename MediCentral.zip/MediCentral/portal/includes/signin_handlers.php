<?php

declare(strict_types=1);

require_once __DIR__ . '/auth_helpers.php';
require_once __DIR__ . '/pharmacist_pro.php';

/**
 * @return array{ok: bool, error: string}
 */
function mc_signin_attempt_member(mysqli $conn, string $userNorm, string $pwd): array
{
	$stmt = $conn->prepare(
		'SELECT member_id, password_hash FROM mc_members WHERE LOWER(username) = ? AND is_active = 1 LIMIT 1'
	);
	if ($stmt === false) {
		return ['ok' => false, 'error' => 'Sign-in is temporarily unavailable.'];
	}
	$stmt->bind_param('s', $userNorm);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();
	if ($row === null || !password_verify($pwd, (string) $row['password_hash'])) {
		$hint = mc_signin_wrong_role_hint($conn, $userNorm, 'pharmacist');

		return [
			'ok' => false,
			'error' => 'Invalid member credentials.' . $hint . ' New here? Create an account below.',
		];
	}
	$mid = (int) $row['member_id'];
	mc_start_member_session($mid, $userNorm);
	mc_touch_member_login($conn, $mid);
	mc_portal_redirect('member/index.php');
}

/**
 * @return array{ok: bool, error: string}
 */
function mc_signin_attempt_admin(mysqli $conn, string $userNorm, string $pwd): array
{
	$hasPharmacyCol = mc_table_has_column($conn, 'mc_admins', 'pharmacy_id');
	$sql = $hasPharmacyCol
		? 'SELECT admin_id, password_hash, pharmacy_id FROM mc_admins WHERE LOWER(username) = ? LIMIT 1'
		: 'SELECT admin_id, password_hash FROM mc_admins WHERE LOWER(username) = ? LIMIT 1';
	$stmt = $conn->prepare($sql);
	if ($stmt === false) {
		return ['ok' => false, 'error' => 'Sign-in is temporarily unavailable.'];
	}
	$stmt->bind_param('s', $userNorm);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();
	if ($row === null || !password_verify($pwd, (string) $row['password_hash'])) {
		return ['ok' => false, 'error' => 'Invalid administrator credentials.'];
	}
	$adminId = (int) $row['admin_id'];
	$pharmacyId = $hasPharmacyCol ? (int) ($row['pharmacy_id'] ?? 0) : 0;
	session_regenerate_id(true);
	$_SESSION['mc_role'] = 'admin';
	$_SESSION['mc_admin_id'] = $adminId;
	$_SESSION['mc_username'] = $userNorm;
	mc_set_signin_portal('pharmacy');
	if ($hasPharmacyCol) {
		$_SESSION['mc_admin_pharmacy_id'] = $pharmacyId > 0 ? $pharmacyId : null;
	}
	if ($upd = $conn->prepare('UPDATE mc_admins SET last_login_at = CURRENT_TIMESTAMP WHERE admin_id = ? LIMIT 1')) {
		$upd->bind_param('i', $adminId);
		@$upd->execute();
		$upd->close();
	}
	mc_portal_redirect('admin/dashboard.php');
}

/**
 * @return array{ok: bool, error: string}
 */
function mc_signin_attempt_pharmacist_network(mysqli $conn, string $userNorm, string $pwd): array
{
	$hasApproval = mc_pharmacist_has_approval_columns($conn);
	$sql = $hasApproval
		? 'SELECT pharmacist_id, password_hash, approval_status, is_active FROM mc_pharmacists WHERE LOWER(username) = ? LIMIT 1'
		: 'SELECT pharmacist_id, password_hash, is_active FROM mc_pharmacists WHERE LOWER(username) = ? LIMIT 1';
	$stmt = $conn->prepare($sql);
	if ($stmt === false) {
		return ['ok' => false, 'error' => 'Sign-in is temporarily unavailable.'];
	}
	$stmt->bind_param('s', $userNorm);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();
	if ($row === null || !password_verify($pwd, (string) $row['password_hash'])) {
		$hint = mc_signin_wrong_role_hint($conn, $userNorm, 'member');

		return [
			'ok' => false,
			'error' => 'Invalid pharmacist credentials.' . $hint . ' New here? Register below.',
		];
	}
	$approvalStatus = (string) ($row['approval_status'] ?? 'approved');
	if ($hasApproval && $approvalStatus === 'rejected') {
		return ['ok' => false, 'error' => 'Your application was rejected. Contact the system administrator.'];
	}
	if (!$hasApproval && (int) ($row['is_active'] ?? 0) !== 1) {
		return ['ok' => false, 'error' => 'This pharmacist account is inactive.'];
	}
	$pId = (int) $row['pharmacist_id'];
	mc_start_pharmacist_session($pId, $userNorm);
	if ($upd = $conn->prepare('UPDATE mc_pharmacists SET last_login_at = CURRENT_TIMESTAMP WHERE pharmacist_id = ? LIMIT 1')) {
		$upd->bind_param('i', $pId);
		@$upd->execute();
		$upd->close();
	}
	mc_pharmacist_redirect_after_login($conn);
	exit;
}

/**
 * Pharmacy operations (inventory / POS) sign-in.
 *
 * @return array{ok: bool, error: string}
 */
function mc_signin_attempt_pharmacist_pos(mysqli $conn, string $userNorm, string $pwd): array
{
	$hasApproval = mc_pharmacist_has_approval_columns($conn);
	$hasPharmacyCol = mc_table_has_column($conn, 'mc_pharmacists', 'pharmacy_id');
	$cols = 'pharmacist_id, password_hash, is_active';
	if ($hasApproval) {
		$cols .= ', approval_status';
	}
	if ($hasPharmacyCol) {
		$cols .= ', pharmacy_id';
	}
	$sql = "SELECT {$cols} FROM mc_pharmacists WHERE LOWER(username) = ? LIMIT 1";
	$stmt = $conn->prepare($sql);
	if ($stmt === false) {
		return ['ok' => false, 'error' => 'Sign-in is temporarily unavailable.'];
	}
	$stmt->bind_param('s', $userNorm);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();
	if ($row === null || !password_verify($pwd, (string) $row['password_hash'])) {
		return ['ok' => false, 'error' => 'Invalid staff credentials. Ask your pharmacy administrator for an account.'];
	}
	if ((int) ($row['is_active'] ?? 0) !== 1) {
		return ['ok' => false, 'error' => 'This staff account is inactive.'];
	}
	$approvalStatus = (string) ($row['approval_status'] ?? 'approved');
	$pharmacyId = (int) ($row['pharmacy_id'] ?? 0);
	if ($hasApproval && $approvalStatus === 'rejected') {
		return ['ok' => false, 'error' => 'This account cannot access pharmacy operations.'];
	}
	if ($hasApproval && $approvalStatus === 'pending' && $pharmacyId <= 0) {
		return [
			'ok' => false,
			'error' => 'Your professional application is still pending. Use the main network sign-in to check status.',
		];
	}
	$pId = (int) $row['pharmacist_id'];
	mc_start_pharmacist_session($pId, $userNorm, 'pharmacy');
	if ($upd = $conn->prepare('UPDATE mc_pharmacists SET last_login_at = CURRENT_TIMESTAMP WHERE pharmacist_id = ? LIMIT 1')) {
		$upd->bind_param('i', $pId);
		@$upd->execute();
		$upd->close();
	}
	mc_portal_redirect('pharmacist-home.php');
}

/**
 * If password failed on one role, hint when the username exists on the other portal role.
 */
function mc_signin_wrong_role_hint(mysqli $conn, string $userNorm, string $otherRole): string
{
	if ($otherRole === 'pharmacist') {
		$stmt = $conn->prepare('SELECT 1 FROM mc_pharmacists WHERE LOWER(username) = ? LIMIT 1');
	} else {
		$stmt = $conn->prepare('SELECT 1 FROM mc_members WHERE LOWER(username) = ? LIMIT 1');
	}
	if (!$stmt) {
		return '';
	}
	$stmt->bind_param('s', $userNorm);
	$stmt->execute();
	$stmt->store_result();
	$found = $stmt->num_rows > 0;
	$stmt->close();
	if (!$found) {
		return '';
	}

	return $otherRole === 'pharmacist'
		? ' That username is registered as a pharmacist — select Pharmacist above.'
		: ' That username is a member account — select Member above.';
}
