<?php

declare(strict_types=1);

require_once __DIR__ . '/currency.php';
require_once __DIR__ . '/dr_aklilu.php';

function mc_upgrade_telebirr_verify_schema(mysqli $conn): void
{
	if (!function_exists('mc_upgrade_member_order_payment_schema')) {
		require_once __DIR__ . '/member_order_payment.php';
	}
	mc_upgrade_member_order_payment_schema($conn);
	$cols = [
		'telebirr_verify_status' => "VARCHAR(24) NULL AFTER `telebirr_submitted_at`",
		'telebirr_verify_note' => 'VARCHAR(500) NULL AFTER `telebirr_verify_status`',
	];
	foreach ($cols as $col => $def) {
		if (mc_table_has_column($conn, 'mc_member_orders', 'order_id') && !mc_table_has_column($conn, 'mc_member_orders', $col)) {
			@$conn->query("ALTER TABLE `mc_member_orders` ADD COLUMN `{$col}` {$def}");
		}
	}
}

/**
 * @return array{verdict: string, confidence: float, reason: string}
 */
function mc_telebirr_local_assess(string $transactionId): array
{
	$tx = trim($transactionId);
	$len = strlen($tx);
	if (!preg_match('/^[A-Za-z0-9\-]{6,40}$/', $tx)) {
		return ['verdict' => 'invalid_format', 'confidence' => 1.0, 'reason' => 'Characters or length do not match a typical Tele Birr reference.'];
	}
	$lower = strtolower($tx);
	$obviousFake = ['test', 'fake', 'sample', '123456', '000000', 'aaaaaa', 'xxxxxxxx'];
	foreach ($obviousFake as $bad) {
		if ($lower === $bad || str_contains($lower, $bad)) {
			return ['verdict' => 'likely_fake', 'confidence' => 0.92, 'reason' => 'Looks like a placeholder or test value, not a payment reference.'];
		}
	}
	if (preg_match('/^(.)\1{5,}$/', $tx)) {
		return ['verdict' => 'likely_fake', 'confidence' => 0.9, 'reason' => 'Repeated characters are uncommon on real Tele Birr receipts.'];
	}
	if (preg_match('/^(012345|123456|654321|abcdef)/i', $tx)) {
		return ['verdict' => 'likely_fake', 'confidence' => 0.85, 'reason' => 'Sequential or trivial pattern — unlikely from Tele Birr.'];
	}
	if ($len < 8) {
		return ['verdict' => 'uncertain', 'confidence' => 0.55, 'reason' => 'Very short IDs are unusual; double-check your SMS or app receipt.'];
	}
	if ($len >= 8 && $len <= 32 && preg_match('/[A-Za-z]/', $tx) && preg_match('/\d/', $tx)) {
		return ['verdict' => 'likely_valid', 'confidence' => 0.72, 'reason' => 'Format matches common Tele Birr reference patterns (letters and digits).'];
	}
	if (preg_match('/^\d{10,20}$/', $tx)) {
		return ['verdict' => 'likely_valid', 'confidence' => 0.68, 'reason' => 'Numeric reference within a typical length range.'];
	}

	return ['verdict' => 'uncertain', 'confidence' => 0.5, 'reason' => 'Could not confirm automatically — pharmacy may verify against their Tele Birr account.'];
}

function mc_telebirr_is_duplicate(mysqli $conn, string $transactionId, int $excludeOrderId = 0): bool
{
	mc_upgrade_telebirr_verify_schema($conn);
	$sql = 'SELECT order_id FROM mc_member_orders WHERE telebirr_transaction_id = ?';
	if ($excludeOrderId > 0) {
		$sql .= ' AND order_id <> ?';
	}
	$sql .= ' LIMIT 1';
	$st = $conn->prepare($sql);
	if (!$st) {
		return false;
	}
	if ($excludeOrderId > 0) {
		$st->bind_param('si', $transactionId, $excludeOrderId);
	} else {
		$st->bind_param('s', $transactionId);
	}
	$st->execute();
	$res = $st->get_result();
	$dup = $res && $res->num_rows > 0;
	$st->close();

	return $dup;
}

/**
 * @param array<string, mixed> $orderRow
 * @return array{verdict: string, confidence: float, reason: string, ai_used: bool}
 */
function mc_telebirr_ai_assess(array $orderRow, string $transactionId): array
{
	$local = mc_telebirr_local_assess($transactionId);
	if (in_array($local['verdict'], ['invalid_format', 'likely_fake'], true)) {
		return $local + ['ai_used' => false];
	}

	$apiKey = mc_cursor_api_key();
	if ($apiKey === '') {
		return $local + ['ai_used' => false];
	}

	$amount = mc_format_etb((float) ($orderRow['total_amount'] ?? 0));
	$phone = trim((string) ($orderRow['telebirr_display_phone'] ?? $orderRow['telebirr_phone'] ?? $orderRow['phone'] ?? ''));
	$pharmacy = (string) ($orderRow['pharmacy_name'] ?? '');
	$orderId = (int) ($orderRow['order_id'] ?? 0);

	$system = <<<'CTX'
You help MediCentral verify Tele Birr (Ethiopia mobile money) transaction references submitted by members paying pharmacies.
You cannot access Ethio Telecom or bank APIs — judge only plausibility of the reference format and context.
Reply with ONLY valid JSON, no markdown:
{"verdict":"likely_valid"|"uncertain"|"likely_fake","confidence":0.0-1.0,"reason":"one short sentence for the member"}
Use likely_fake for obvious placeholders, test strings, or impossible patterns.
Use uncertain when format is acceptable but you cannot be confident.
Use likely_valid when the ID looks like a genuine Tele Birr SMS/app reference for the given amount.
CTX;

	$user = "Order #{$orderId}\nPharmacy: {$pharmacy}\nAmount: {$amount}\nTele Birr pay-to number: " . ($phone !== '' ? $phone : '(not set)') . "\nSubmitted transaction ID: {$transactionId}";

	$ai = mc_dr_aklilu_chat('network', $user, $system);
	if (!$ai['ok'] || trim($ai['text']) === '') {
		return $local + ['ai_used' => false];
	}

	$parsed = mc_telebirr_parse_ai_json($ai['text']);
	if ($parsed === null) {
		return $local + ['ai_used' => false];
	}

	$verdict = (string) ($parsed['verdict'] ?? '');
	if (!in_array($verdict, ['likely_valid', 'uncertain', 'likely_fake'], true)) {
		return $local + ['ai_used' => false];
	}

	return [
		'verdict' => $verdict,
		'confidence' => max(0.0, min(1.0, (float) ($parsed['confidence'] ?? 0.5))),
		'reason' => trim((string) ($parsed['reason'] ?? '')) ?: $local['reason'],
		'ai_used' => true,
	];
}

/**
 * @return array{verdict: string, confidence: float, reason: string}|null
 */
function mc_telebirr_parse_ai_json(string $text): ?array
{
	$text = trim($text);
	if (preg_match('/\{[^{}]*"verdict"[^{}]*\}/s', $text, $m)) {
		$text = $m[0];
	}
	$data = json_decode($text, true);
	if (!is_array($data) || !isset($data['verdict'])) {
		return null;
	}

	return $data;
}

/**
 * @return array{ok: bool, verdict: string, msg: string, ai_note: string, confidence: float, ai_used: bool}
 */
function mc_telebirr_verify_transaction(mysqli $conn, int $memberId, int $orderId, string $transactionId): array
{
	mc_upgrade_telebirr_verify_schema($conn);
	$transactionId = trim($transactionId);
	if ($transactionId === '') {
		return [
			'ok' => false,
			'verdict' => 'invalid_format',
			'msg' => 'Enter your Tele Birr transaction ID.',
			'ai_note' => '',
			'confidence' => 0.0,
			'ai_used' => false,
		];
	}

	if (mc_telebirr_is_duplicate($conn, $transactionId, $orderId)) {
		return [
			'ok' => false,
			'verdict' => 'duplicate',
			'msg' => 'This transaction ID was already used on another order. Use the ID from your own payment.',
			'ai_note' => 'Duplicate reference in MediCentral records.',
			'confidence' => 1.0,
			'ai_used' => false,
		];
	}

	if (!function_exists('mc_member_load_order_for_payment')) {
		require_once __DIR__ . '/member_order_payment.php';
	}
	$order = mc_member_load_order_for_payment($conn, $memberId, $orderId);
	if ($order === null) {
		return [
			'ok' => false,
			'verdict' => 'notfound',
			'msg' => 'Order not found.',
			'ai_note' => '',
			'confidence' => 0.0,
			'ai_used' => false,
		];
	}

	$assess = mc_telebirr_ai_assess($order, $transactionId);
	$verdict = (string) $assess['verdict'];
	$reason = (string) $assess['reason'];
	$confidence = (float) $assess['confidence'];
	$aiUsed = (bool) ($assess['ai_used'] ?? false);

	if ($verdict === 'invalid_format') {
		return [
			'ok' => false,
			'verdict' => $verdict,
			'msg' => 'Transaction ID looks invalid. Copy it exactly from your Tele Birr SMS or receipt.',
			'ai_note' => $reason,
			'confidence' => $confidence,
			'ai_used' => $aiUsed,
		];
	}

	if ($verdict === 'likely_fake') {
		return [
			'ok' => false,
			'verdict' => $verdict,
			'msg' => 'This transaction ID does not look genuine. ' . $reason,
			'ai_note' => $reason,
			'confidence' => $confidence,
			'ai_used' => $aiUsed,
		];
	}

	if ($verdict === 'uncertain') {
		return [
			'ok' => true,
			'verdict' => 'uncertain',
			'msg' => 'Submitted for pharmacy review. ' . $reason,
			'ai_note' => $reason,
			'confidence' => $confidence,
			'ai_used' => $aiUsed,
		];
	}

	return [
		'ok' => true,
		'verdict' => 'likely_valid',
		'msg' => $aiUsed ? 'Transaction ID looks plausible. ' . $reason : $reason,
		'ai_note' => $reason,
		'confidence' => $confidence,
		'ai_used' => $aiUsed,
	];
}

function mc_telebirr_verify_status_label(string $status): string
{
	return match ($status) {
		'likely_valid' => 'Likely valid',
		'uncertain' => 'Needs review',
		'likely_fake' => 'Suspicious',
		'duplicate' => 'Duplicate',
		'invalid_format' => 'Invalid format',
		default => $status !== '' ? $status : '—',
	};
}
