<?php

declare(strict_types=1);

/** @var list<string> */
const MC_INVENTORY_UNIT_TYPES = ['tablet', 'capsule', 'bottle', 'vial', 'strip', 'box', 'unit'];

function mc_upgrade_inventory_unit_schema(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_drugs', 'drug_id')) {
		return;
	}
	if (!mc_table_has_column($conn, 'mc_drugs', 'unit_type')) {
		@$conn->query(
			"ALTER TABLE `mc_drugs` ADD COLUMN `unit_type` VARCHAR(32) NOT NULL DEFAULT 'unit' AFTER `category`"
		);
	}
}

function mc_inventory_unit_label(string $unitType): string
{
	return match (strtolower(trim($unitType))) {
		'tablet' => 'tablets',
		'capsule' => 'capsules',
		'bottle' => 'bottles',
		'vial' => 'vials',
		'strip' => 'strips',
		'box' => 'boxes',
		default => 'units',
	};
}

function mc_inventory_normalize_unit_type(string $raw): string
{
	$u = strtolower(trim($raw));
	if (in_array($u, MC_INVENTORY_UNIT_TYPES, true)) {
		return $u;
	}

	return 'unit';
}

/**
 * @return array<string, mixed>|null
 */
function mc_inventory_find_by_code(mysqli $conn, string $code): ?array
{
	$code = trim($code);
	if ($code === '') {
		return null;
	}

	$sql = <<<'SQL'
SELECT drug_id, name, barcode, qr_code, category, unit_type, quantity, unit_price, reorder_level, expiry_date
FROM mc_drugs
WHERE barcode = ? OR qr_code = ?
LIMIT 1
SQL;
	$st = $conn->prepare($sql);
	if (!$st) {
		return null;
	}
	$st->bind_param('ss', $code, $code);
	$st->execute();
	$res = $st->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$st->close();

	return $row ?: null;
}

/**
 * Apply stock change to mc_drugs and mirror to mc_pharmacy_inventory when present.
 */
function mc_inventory_apply_stock_delta(mysqli $conn, int $drugId, int $delta, ?int $pharmacyId = null): bool
{
	if ($drugId <= 0 || $delta === 0) {
		return false;
	}

	$upd = $conn->prepare(
		$delta > 0
			? 'UPDATE mc_drugs SET quantity = quantity + ? WHERE drug_id = ?'
			: 'UPDATE mc_drugs SET quantity = GREATEST(0, quantity + ?) WHERE drug_id = ?'
	);
	if (!$upd || !$upd->bind_param('ii', $delta, $drugId) || !$upd->execute()) {
		if ($upd) {
			$upd->close();
		}

		return false;
	}
	$upd->close();

	if (!mc_table_has_column($conn, 'mc_pharmacy_inventory', 'inventory_id')) {
		return true;
	}

	if ($pharmacyId !== null && $pharmacyId > 0) {
		$chk = $conn->prepare(
			'SELECT inventory_id FROM mc_pharmacy_inventory WHERE pharmacy_id = ? AND drug_id = ? LIMIT 1'
		);
		if (!$chk) {
			return true;
		}
		$chk->bind_param('ii', $pharmacyId, $drugId);
		$chk->execute();
		$chk->store_result();
		$exists = $chk->num_rows > 0;
		$chk->close();

		if ($exists) {
			$phUpd = $conn->prepare(
				$delta > 0
					? 'UPDATE mc_pharmacy_inventory SET quantity = quantity + ? WHERE pharmacy_id = ? AND drug_id = ?'
					: 'UPDATE mc_pharmacy_inventory SET quantity = GREATEST(0, quantity + ?) WHERE pharmacy_id = ? AND drug_id = ?'
			);
			if ($phUpd && $phUpd->bind_param('iii', $delta, $pharmacyId, $drugId) && $phUpd->execute()) {
				$phUpd->close();
			}
		} else {
			$price = 0.0;
			$pst = $conn->prepare('SELECT unit_price FROM mc_drugs WHERE drug_id = ? LIMIT 1');
			if ($pst) {
				$pst->bind_param('i', $drugId);
				$pst->execute();
				$pst->bind_result($price);
				$pst->fetch();
				$pst->close();
			}
			$qty = max(0, $delta);
			$ins = $conn->prepare(
				'INSERT INTO mc_pharmacy_inventory (pharmacy_id, drug_id, quantity, unit_price) VALUES (?,?,?,?)'
			);
			if ($ins && $ins->bind_param('iiid', $pharmacyId, $drugId, $qty, $price) && $ins->execute()) {
				$ins->close();
			}
		}

		return true;
	}

	$phUpdAll = $conn->prepare(
		$delta > 0
			? 'UPDATE mc_pharmacy_inventory SET quantity = quantity + ? WHERE drug_id = ?'
			: 'UPDATE mc_pharmacy_inventory SET quantity = GREATEST(0, quantity + ?) WHERE drug_id = ?'
	);
	if ($phUpdAll && $phUpdAll->bind_param('ii', $delta, $drugId) && $phUpdAll->execute()) {
		$phUpdAll->close();
	}

	return true;
}

/**
 * Receive stock from barcode/QR scan (add qty to existing SKU).
 *
 * @return array{ok: bool, msg: string, drug?: array<string, mixed>}
 */
function mc_inventory_receive_by_scan(mysqli $conn, string $code, int $qtyAdd, ?int $pharmacyId = null): array
{
	mc_upgrade_inventory_unit_schema($conn);

	if ($qtyAdd <= 0) {
		return ['ok' => false, 'msg' => 'Enter a positive quantity to receive.'];
	}

	$drug = mc_inventory_find_by_code($conn, $code);
	if ($drug === null) {
		return ['ok' => false, 'msg' => 'No product matches that barcode or QR. Register it first, then receive stock.'];
	}

	$drugId = (int) $drug['drug_id'];
	if (!mc_inventory_apply_stock_delta($conn, $drugId, $qtyAdd, $pharmacyId)) {
		return ['ok' => false, 'msg' => 'Could not update stock.'];
	}

	$st = $conn->prepare('SELECT quantity FROM mc_drugs WHERE drug_id = ? LIMIT 1');
	$newQty = (int) ($drug['quantity'] ?? 0) + $qtyAdd;
	if ($st) {
		$st->bind_param('i', $drugId);
		$st->execute();
		$st->bind_result($newQty);
		$st->fetch();
		$st->close();
	}
	$drug['quantity'] = $newQty;
	$unitLbl = mc_inventory_unit_label((string) ($drug['unit_type'] ?? 'unit'));

	return [
		'ok' => true,
		'msg' => 'Added ' . $qtyAdd . ' ' . $unitLbl . ' to ' . (string) $drug['name'] . '. Stock now: ' . $newQty . '.',
		'drug' => $drug,
	];
}

/**
 * Reduce stock for a sale (validates availability first).
 *
 * @return array{ok: bool, msg: string}
 */
function mc_inventory_reduce_for_sale(mysqli $conn, int $drugId, int $qty, ?int $pharmacyId = null): array
{
	if ($drugId <= 0 || $qty <= 0) {
		return ['ok' => false, 'msg' => 'Invalid sale quantity.'];
	}

	$st = $conn->prepare('SELECT quantity, name, unit_type FROM mc_drugs WHERE drug_id = ? LIMIT 1 FOR UPDATE');
	if (!$st) {
		return ['ok' => false, 'msg' => 'Stock check failed.'];
	}
	$st->bind_param('i', $drugId);
	$st->execute();
	$st->bind_result($onHand, $dname, $unitType);
	if (!$st->fetch()) {
		$st->close();

		return ['ok' => false, 'msg' => 'Product not found.'];
	}
	$st->close();

	if ($onHand < $qty) {
		$lbl = mc_inventory_unit_label((string) $unitType);

		return [
			'ok' => false,
			'msg' => 'Not enough ' . $lbl . ' for ' . (string) $dname . ' (have ' . $onHand . ', need ' . $qty . ').',
		];
	}

	if (!mc_inventory_apply_stock_delta($conn, $drugId, -$qty, $pharmacyId)) {
		return ['ok' => false, 'msg' => 'Could not deduct stock.'];
	}

	return ['ok' => true, 'msg' => ''];
}

/**
 * Build barcode + QR lookup map for POS JS.
 *
 * @return array{by_barcode: array<string, int>, by_qr: array<string, int>, drugs: array<int, array<string, mixed>>}
 */
function mc_inventory_pos_catalog(mysqli $conn): array
{
	mc_upgrade_inventory_unit_schema($conn);

	$byBarcode = [];
	$byQr = [];
	$drugs = [];

	$res = $conn->query(
		'SELECT drug_id, name, barcode, qr_code, quantity, unit_price, unit_type, category FROM mc_drugs ORDER BY name ASC'
	);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$id = (int) $r['drug_id'];
			$drugs[$id] = $r;
			$bc = trim((string) ($r['barcode'] ?? ''));
			$qr = trim((string) ($r['qr_code'] ?? ''));
			if ($bc !== '') {
				$byBarcode[$bc] = $id;
			}
			if ($qr !== '') {
				$byQr[$qr] = $id;
			}
		}
	}

	return ['by_barcode' => $byBarcode, 'by_qr' => $byQr, 'drugs' => $drugs];
}

/**
 * Mirror a stock change on mc_pharmacy_inventory only (global stock already updated).
 */
function mc_inventory_mirror_pharmacy_delta(mysqli $conn, int $drugId, int $delta, int $pharmacyId): void
{
	if ($pharmacyId <= 0 || $delta === 0 || !mc_table_has_column($conn, 'mc_pharmacy_inventory', 'inventory_id')) {
		return;
	}

	$chk = $conn->prepare(
		'SELECT inventory_id, quantity FROM mc_pharmacy_inventory WHERE pharmacy_id = ? AND drug_id = ? LIMIT 1'
	);
	if (!$chk) {
		return;
	}
	$chk->bind_param('ii', $pharmacyId, $drugId);
	$chk->execute();
	$chk->bind_result($invId, $phQty);
	$has = $chk->fetch();
	$chk->close();

	if ($has) {
		$phUpd = $conn->prepare(
			$delta > 0
				? 'UPDATE mc_pharmacy_inventory SET quantity = quantity + ? WHERE pharmacy_id = ? AND drug_id = ?'
				: 'UPDATE mc_pharmacy_inventory SET quantity = GREATEST(0, quantity + ?) WHERE pharmacy_id = ? AND drug_id = ?'
		);
		if ($phUpd && $phUpd->bind_param('iii', $delta, $pharmacyId, $drugId) && $phUpd->execute()) {
			$phUpd->close();
		}

		return;
	}

	if ($delta <= 0) {
		return;
	}

	$price = 0.0;
	$pst = $conn->prepare('SELECT unit_price FROM mc_drugs WHERE drug_id = ? LIMIT 1');
	if ($pst) {
		$pst->bind_param('i', $drugId);
		$pst->execute();
		$pst->bind_result($price);
		$pst->fetch();
		$pst->close();
	}
	$ins = $conn->prepare(
		'INSERT INTO mc_pharmacy_inventory (pharmacy_id, drug_id, quantity, unit_price) VALUES (?,?,?,?)'
	);
	if ($ins && $ins->bind_param('iiid', $pharmacyId, $drugId, $delta, $price) && $ins->execute()) {
		$ins->close();
	}
}
