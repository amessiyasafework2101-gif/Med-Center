<?php

declare(strict_types=1);

/** Local Cursor API key — do not commit to public repositories. */
define('MC_CURSOR_API_KEY', 'crsr_1606d9fc86ee6b9393e1f13da35945fd35bc8b4e4a5302b999c06bccab946498');
define('MC_CURSOR_MODEL_ID', 'composer-2');
