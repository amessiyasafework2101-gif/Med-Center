<?php

declare(strict_types=1);

function mc_system_slugify(string $name): string
{
	$s = strtolower(trim($name));
	$s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';
	$s = trim((string) $s, '-');

	return $s === '' ? 'pharmacy' : substr($s, 0, 72);
}

function mc_system_unique_slug(mysqli $conn, string $base, int $exceptId = 0): string
{
	$slug = $base;
	$n = 1;
	while (true) {
		if ($exceptId > 0) {
			$stmt = $conn->prepare('SELECT 1 FROM mc_pharmacies WHERE slug = ? AND pharmacy_id <> ? LIMIT 1');
			if (!$stmt) {
				break;
			}
			$stmt->bind_param('si', $slug, $exceptId);
		} else {
			$stmt = $conn->prepare('SELECT 1 FROM mc_pharmacies WHERE slug = ? LIMIT 1');
			if (!$stmt) {
				break;
			}
			$stmt->bind_param('s', $slug);
		}
		$stmt->execute();
		$stmt->store_result();
		$taken = $stmt->num_rows > 0;
		$stmt->close();
		if (!$taken) {
			return $slug;
		}
		$n++;
		$slug = $base . '-' . $n;
		if ($n > 200) {
			return $base . '-' . bin2hex(random_bytes(3));
		}
	}
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_system_pharmacy_list(mysqli $conn, ?string $filter = null): array
{
	$rows = [];
	$where = '1=1';
	if ($filter === 'active') {
		$where = 'p.is_active = 1';
	} elseif ($filter === 'inactive') {
		$where = 'p.is_active = 0';
	} elseif ($filter === 'unverified') {
		$where = 'p.is_active = 1 AND (p.is_verified = 0 OR p.is_verified IS NULL)';
	} elseif ($filter === 'license_expiring') {
		$where = 'p.license_expiry IS NOT NULL AND p.license_expiry >= CURDATE() AND p.license_expiry <= DATE_ADD(CURDATE(), INTERVAL 60 DAY)';
	}

	$sql = <<<SQL
SELECT p.*,
  (SELECT COUNT(*) FROM mc_pharmacists ph WHERE ph.pharmacy_id = p.pharmacy_id AND ph.is_active = 1) AS staff_cnt,
  (SELECT COUNT(*) FROM mc_member_orders o WHERE o.pharmacy_id = p.pharmacy_id) AS order_cnt
FROM mc_pharmacies p
WHERE {$where}
ORDER BY p.name ASC
SQL;
	$res = $conn->query($sql);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$rows[] = $r;
		}
	}

	return $rows;
}

function mc_system_pharmacy_get(mysqli $conn, int $id): ?array
{
	$stmt = $conn->prepare('SELECT * FROM mc_pharmacies WHERE pharmacy_id = ? LIMIT 1');
	if (!$stmt) {
		return null;
	}
	$stmt->bind_param('i', $id);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();

	return $row ?: null;
}

/**
 * @param array<string, mixed> $in
 * @return array{ok: bool, error: string, id?: int}
 */
function mc_system_pharmacy_save(mysqli $conn, array $in, int $editId = 0): array
{
	require_once __DIR__ . '/member_order_payment.php';
	mc_upgrade_member_order_payment_schema($conn);

	$name = trim((string) ($in['name'] ?? ''));
	if ($name === '') {
		return ['ok' => false, 'error' => 'Pharmacy name is required.'];
	}

	$slugIn = trim((string) ($in['slug'] ?? ''));
	$slugBase = $slugIn !== '' ? mc_system_slugify($slugIn) : mc_system_slugify($name);
	$slug = mc_system_unique_slug($conn, $slugBase, $editId);

	$tagline = trim((string) ($in['tagline'] ?? ''));
	$address = trim((string) ($in['address'] ?? ''));
	$city = trim((string) ($in['city'] ?? ''));
	$phone = trim((string) ($in['phone'] ?? ''));
	$telebirr = trim((string) ($in['telebirr_phone'] ?? ''));
	$telebirrDb = $telebirr === '' ? null : $telebirr;
	$email = trim((string) ($in['email'] ?? ''));
	$website = trim((string) ($in['website'] ?? ''));
	$owner = trim((string) ($in['owner_name'] ?? ''));
	$regNo = trim((string) ($in['registration_number'] ?? ''));
	$taxId = trim((string) ($in['tax_id'] ?? ''));
	$licNo = trim((string) ($in['license_number'] ?? ''));
	$licAuth = trim((string) ($in['license_authority'] ?? ''));
	$licNotes = trim((string) ($in['license_notes'] ?? ''));
	$licDoc = trim((string) ($in['license_document_url'] ?? ''));
	$licExpiry = trim((string) ($in['license_expiry'] ?? ''));
	$licExpiryVal = $licExpiry !== '' ? $licExpiry : null;
	$lat = trim((string) ($in['latitude'] ?? ''));
	$lng = trim((string) ($in['longitude'] ?? ''));
	$latVal = $lat !== '' && is_numeric($lat) ? $lat : null;
	$lngVal = $lng !== '' && is_numeric($lng) ? $lng : null;
	$active = isset($in['is_active']) ? 1 : 0;
	$verified = isset($in['is_verified']) ? 1 : 0;

	if ($editId > 0) {
		$sql = <<<'SQL'
UPDATE mc_pharmacies SET
  name=?, slug=?, tagline=?, address=?, city=?, phone=?, telebirr_phone=?, email=?, website=?, owner_name=?,
  registration_number=?, tax_id=?, license_number=?, license_authority=?, license_expiry=?,
  license_notes=?, license_document_url=?, latitude=?, longitude=?, is_active=?, is_verified=?,
  verified_at = CASE WHEN ?=1 THEN COALESCE(verified_at, CURRENT_TIMESTAMP) ELSE NULL END
WHERE pharmacy_id=?
SQL;
		$stmt = $conn->prepare($sql);
		if (!$stmt) {
			return ['ok' => false, 'error' => 'Could not update pharmacy.'];
		}
		$stmt->bind_param(
			'sssssssssssssssssssiiii',
			$name,
			$slug,
			$tagline,
			$address,
			$city,
			$phone,
			$telebirrDb,
			$email,
			$website,
			$owner,
			$regNo,
			$taxId,
			$licNo,
			$licAuth,
			$licExpiryVal,
			$licNotes,
			$licDoc,
			$latVal,
			$lngVal,
			$active,
			$verified,
			$verified,
			$editId
		);
	} else {
		$sql = <<<'SQL'
INSERT INTO mc_pharmacies (
  name, slug, tagline, address, city, phone, telebirr_phone, email, website, owner_name,
  registration_number, tax_id, license_number, license_authority, license_expiry,
  license_notes, license_document_url, latitude, longitude, is_active, is_verified, verified_at
) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, CASE WHEN ?=1 THEN CURRENT_TIMESTAMP ELSE NULL END)
SQL;
		$stmt = $conn->prepare($sql);
		if (!$stmt) {
			return ['ok' => false, 'error' => 'Could not create pharmacy.'];
		}
		$stmt->bind_param(
			'sssssssssssssssssssiii',
			$name,
			$slug,
			$tagline,
			$address,
			$city,
			$phone,
			$telebirrDb,
			$email,
			$website,
			$owner,
			$regNo,
			$taxId,
			$licNo,
			$licAuth,
			$licExpiryVal,
			$licNotes,
			$licDoc,
			$latVal,
			$lngVal,
			$active,
			$verified,
			$verified
		);
	}

	if (!$stmt->execute()) {
		$err = $stmt->error;
		$stmt->close();

		return ['ok' => false, 'error' => 'Save failed: ' . $err];
	}
	$id = $editId > 0 ? $editId : (int) $conn->insert_id;
	$stmt->close();

	return ['ok' => true, 'error' => '', 'id' => $id];
}

/**
 * @return array<string, int|float>
 */
function mc_system_network_stats(mysqli $conn): array
{
	$stats = [
		'pharmacies' => 0,
		'pharmacies_active' => 0,
		'pharmacies_verified' => 0,
		'license_expiring' => 0,
		'members' => 0,
		'members_active' => 0,
		'pharmacists' => 0,
		'admins' => 0,
		'orders' => 0,
		'orders_pending' => 0,
	];

	$q = [
		'pharmacies' => 'SELECT COUNT(*) AS c FROM mc_pharmacies',
		'pharmacies_active' => 'SELECT COUNT(*) AS c FROM mc_pharmacies WHERE is_active = 1',
		'members' => 'SELECT COUNT(*) AS c FROM mc_members',
		'members_active' => 'SELECT COUNT(*) AS c FROM mc_members WHERE is_active = 1',
		'pharmacists' => 'SELECT COUNT(*) AS c FROM mc_pharmacists',
		'admins' => 'SELECT COUNT(*) AS c FROM mc_admins',
	];
	foreach ($q as $k => $sql) {
		$r = $conn->query($sql);
		if ($r && ($row = $r->fetch_assoc())) {
			$stats[$k] = (int) $row['c'];
		}
	}

	if (mc_table_has_column($conn, 'mc_pharmacies', 'is_verified')) {
		$r = $conn->query('SELECT COUNT(*) AS c FROM mc_pharmacies WHERE is_active = 1 AND is_verified = 1');
		if ($r && ($row = $r->fetch_assoc())) {
			$stats['pharmacies_verified'] = (int) $row['c'];
		}
		$r = $conn->query(
			'SELECT COUNT(*) AS c FROM mc_pharmacies WHERE license_expiry IS NOT NULL AND license_expiry >= CURDATE() AND license_expiry <= DATE_ADD(CURDATE(), INTERVAL 60 DAY)'
		);
		if ($r && ($row = $r->fetch_assoc())) {
			$stats['license_expiring'] = (int) $row['c'];
		}
	}

	if (mc_table_has_column($conn, 'mc_member_orders', 'order_id')) {
		$r = $conn->query('SELECT COUNT(*) AS c FROM mc_member_orders');
		if ($r && ($row = $r->fetch_assoc())) {
			$stats['orders'] = (int) $row['c'];
		}
		$r = $conn->query("SELECT COUNT(*) AS c FROM mc_member_orders WHERE status = 'pending'");
		if ($r && ($row = $r->fetch_assoc())) {
			$stats['orders_pending'] = (int) $row['c'];
		}
	}

	return $stats;
}
