<?php

declare(strict_types=1);

require_once __DIR__ . '/auth_helpers.php';
require_once __DIR__ . '/site_footer.php';
require_once __DIR__ . '/site_nav.php';

/**
 * @param 'home'|'chat'|'opportunities'|'pos'|'ai'|'about'|'contact' $active
 */
function mc_ph_network_shell_start(string $pageTitle, string $active, string $displayName): void
{
	mc_set_signin_portal('network');
	$navItems = mc_site_nav_items('pharmacist', '../');
	$name = htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8');
	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
	echo '<title>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . ' · Pharmacist · MediCentral</title>';
	echo '<link rel="stylesheet" href="../css/signin.css"><link rel="stylesheet" href="../css/pharmacist-network.css">';
	echo '<link rel="stylesheet" href="../css/dr-aklilu.css">';
	echo '</head><body class="phn-body"><div class="phn-layout">';
	echo '<aside class="phn-side"><a href="index.php" class="phn-brand"><strong>MediCentral</strong><small>Pharmacist network</small></a><nav class="phn-nav">';
	foreach ($navItems as $item) {
		$cls = $active === $item['slug'] ? ' phn-nav is-active' : ' phn-nav';
		echo '<a class="' . trim($cls) . '" href="' . htmlspecialchars($item['href'], ENT_QUOTES, 'UTF-8') . '">'
			. htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8') . '</a>';
	}
	echo '</nav><div class="phn-foot"><span>' . $name . '</span> ';
	echo '<a class="phn-foot-link" href="../pharmacy/signin.php">POS</a> ';
	echo '<a href="../logout.php?to=network">Sign out</a></div></aside>';
	echo '<main class="phn-main"><header class="phn-top"><h1>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . '</h1></header><div class="phn-content">';
}

function mc_ph_network_shell_end(): void
{
	echo '</div>';
	mc_render_site_footer('../');
	require_once __DIR__ . '/dr_aklilu_panel.php';
	mc_dr_aklilu_render_panel('network', '../');
	echo '<script src="../js/dr-aklilu-format.js" defer></script>';
	echo '<script src="../js/dr-aklilu.js" defer></script>';
	echo '</main></div></body></html>';
}
