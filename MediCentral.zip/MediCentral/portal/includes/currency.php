<?php

declare(strict_types=1);

function mc_format_etb(float $amount): string
{
	return 'ETB ' . number_format($amount, 2, '.', ',');
}
