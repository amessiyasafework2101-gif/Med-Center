<?php

declare(strict_types=1);

require_once __DIR__ . '/pharmacist_pro.php';

function mc_upgrade_pharmacist_ratings_unique(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacist_ratings', 'rating_id')) {
		return;
	}
	if (!mc_table_has_index($conn, 'mc_pharmacist_ratings', 'ux_ph_rating_member')) {
		@$conn->query(
			'ALTER TABLE `mc_pharmacist_ratings` ADD UNIQUE KEY `ux_ph_rating_member` (`pharmacist_id`,`rater_type`,`member_id`)'
		);
	}
	if (!mc_table_has_index($conn, 'mc_pharmacist_ratings', 'ux_ph_rating_admin')) {
		@$conn->query(
			'ALTER TABLE `mc_pharmacist_ratings` ADD UNIQUE KEY `ux_ph_rating_admin` (`pharmacist_id`,`rater_type`,`admin_id`)'
		);
	}
}

/**
 * Save or update one rating per rater (member or admin). Recalculates performance_score.
 *
 * @return array{ok: bool, msg: string}
 */
function mc_pharmacist_save_rating(
	mysqli $conn,
	int $pharmacistId,
	string $raterType,
	int $score,
	?string $comment = null,
	?int $memberId = null,
	?int $adminId = null
): array {
	mc_upgrade_pharmacist_ratings_unique($conn);

	if ($pharmacistId <= 0 || $score < 1 || $score > 5) {
		return ['ok' => false, 'msg' => 'Choose a rating from 1 to 5 stars.'];
	}
	if (!in_array($raterType, ['member', 'admin'], true)) {
		return ['ok' => false, 'msg' => 'Invalid rater type.'];
	}
	if ($raterType === 'member' && ($memberId === null || $memberId <= 0)) {
		return ['ok' => false, 'msg' => 'Member required for rating.'];
	}
	if ($raterType === 'admin' && ($adminId === null || $adminId <= 0)) {
		return ['ok' => false, 'msg' => 'Admin required for rating.'];
	}

	$commentDb = $comment !== null && trim($comment) !== '' ? mb_substr(trim($comment), 0, 500) : null;

	$existingId = 0;
	if ($raterType === 'member') {
		$st = $conn->prepare(
			'SELECT rating_id FROM mc_pharmacist_ratings WHERE pharmacist_id = ? AND rater_type = ? AND member_id = ? LIMIT 1'
		);
		if ($st) {
			$st->bind_param('isi', $pharmacistId, $raterType, $memberId);
			$st->execute();
			$st->bind_result($existingId);
			$st->fetch();
			$st->close();
		}
	} else {
		$st = $conn->prepare(
			'SELECT rating_id FROM mc_pharmacist_ratings WHERE pharmacist_id = ? AND rater_type = ? AND admin_id = ? LIMIT 1'
		);
		if ($st) {
			$st->bind_param('isi', $pharmacistId, $raterType, $adminId);
			$st->execute();
			$st->bind_result($existingId);
			$st->fetch();
			$st->close();
		}
	}

	if ($existingId > 0) {
		$upd = $conn->prepare(
			'UPDATE mc_pharmacist_ratings SET score = ?, comment = ?, created_at = CURRENT_TIMESTAMP WHERE rating_id = ?'
		);
		if (!$upd || !$upd->bind_param('isi', $score, $commentDb, $existingId) || !$upd->execute()) {
			if ($upd) {
				$upd->close();
			}

			return ['ok' => false, 'msg' => 'Could not update your rating.'];
		}
		$upd->close();
	} else {
		if ($raterType === 'member') {
			$ins = $conn->prepare(
				'INSERT INTO mc_pharmacist_ratings (pharmacist_id, rater_type, member_id, score, comment) VALUES (?,?,?,?,?)'
			);
			if (!$ins || !$ins->bind_param('isiis', $pharmacistId, $raterType, $memberId, $score, $commentDb)) {
				return ['ok' => false, 'msg' => 'Could not save rating.'];
			}
		} else {
			$ins = $conn->prepare(
				'INSERT INTO mc_pharmacist_ratings (pharmacist_id, rater_type, admin_id, score, comment) VALUES (?,?,?,?,?)'
			);
			if (!$ins || !$ins->bind_param('isiis', $pharmacistId, $raterType, $adminId, $score, $commentDb)) {
				return ['ok' => false, 'msg' => 'Could not save rating.'];
			}
		}
		if (!$ins->execute()) {
			$ins->close();

			return ['ok' => false, 'msg' => 'Could not save rating.'];
		}
		$ins->close();
	}

	mc_pharmacist_recalc_performance($conn, $pharmacistId);

	return ['ok' => true, 'msg' => 'Rating saved. Performance score updated.'];
}

/**
 * @return array{score: int, comment: string}|null
 */
function mc_pharmacist_get_member_rating(mysqli $conn, int $pharmacistId, int $memberId): ?array
{
	if ($pharmacistId <= 0 || $memberId <= 0) {
		return null;
	}
	$st = $conn->prepare(
		'SELECT score, comment FROM mc_pharmacist_ratings WHERE pharmacist_id = ? AND rater_type = ? AND member_id = ? LIMIT 1'
	);
	if (!$st) {
		return null;
	}
	$type = 'member';
	$st->bind_param('isi', $pharmacistId, $type, $memberId);
	$st->execute();
	$st->bind_result($score, $comment);
	if (!$st->fetch()) {
		$st->close();

		return null;
	}
	$st->close();

	return ['score' => (int) $score, 'comment' => (string) ($comment ?? '')];
}

/**
 * @return array{score: int, comment: string}|null
 */
function mc_pharmacist_get_admin_rating(mysqli $conn, int $pharmacistId, int $adminId): ?array
{
	if ($pharmacistId <= 0 || $adminId <= 0) {
		return null;
	}
	$st = $conn->prepare(
		'SELECT score, comment FROM mc_pharmacist_ratings WHERE pharmacist_id = ? AND rater_type = ? AND admin_id = ? LIMIT 1'
	);
	if (!$st) {
		return null;
	}
	$type = 'admin';
	$st->bind_param('isi', $pharmacistId, $type, $adminId);
	$st->execute();
	$st->bind_result($score, $comment);
	if (!$st->fetch()) {
		$st->close();

		return null;
	}
	$st->close();

	return ['score' => (int) $score, 'comment' => (string) ($comment ?? '')];
}

function mc_pharmacist_render_stars(float $score, bool $showCount = false, int $count = 0): string
{
	$full = (int) floor($score);
	$half = ($score - $full) >= 0.25 && ($score - $full) < 0.75;
	$html = '<span class="mc-stars-display" aria-label="Rating ' . htmlspecialchars(number_format($score, 1), ENT_QUOTES, 'UTF-8') . ' out of 5">';
	for ($i = 1; $i <= 5; $i++) {
		$cls = 'mc-star';
		if ($i <= $full) {
			$cls .= ' is-full';
		} elseif ($half && $i === $full + 1) {
			$cls .= ' is-half';
		}
		$html .= '<span class="' . $cls . '" aria-hidden="true">★</span>';
	}
	$html .= '<span class="mc-stars-num">' . number_format($score, 1) . '</span>';
	if ($showCount && $count > 0) {
		$html .= '<span class="mc-stars-count">(' . $count . ')</span>';
	}
	$html .= '</span>';

	return $html;
}
