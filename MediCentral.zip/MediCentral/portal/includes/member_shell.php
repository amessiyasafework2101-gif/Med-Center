<?php

declare(strict_types=1);

require_once __DIR__ . '/auth_helpers.php';
require_once __DIR__ . '/site_footer.php';
require_once __DIR__ . '/site_nav.php';

/**
 * @param 'home'|'about'|'pharmacies'|'pharmacists'|'nearby'|'scan'|'search'|'orders'|'account'|'ai'|'contact' $active
 */
function mc_member_shell_start(string $pageTitle, string $active, array $profile): void
{
	mc_set_signin_portal('network');
	$navItems = mc_site_nav_items('member', '../');
	$display = htmlspecialchars((string) ($profile['display'] ?? 'Member'), ENT_QUOTES, 'UTF-8');
	$initial = mb_strtoupper(mb_substr((string) ($profile['first_name'] ?? 'M'), 0, 1, 'UTF-8'), 'UTF-8');

	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
	echo '<title>' . htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . ' · MediCentral</title>';
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
	echo '<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet">';
	echo '<link rel="stylesheet" href="../css/signin.css">';
	echo '<link rel="stylesheet" href="../css/member-hub.css">';
	echo '<link rel="stylesheet" href="../css/dr-aklilu.css">';
	echo '</head><body class="mc-hub-body">';
	echo '<div class="mc-hub-backdrop" aria-hidden="true"><div class="mc-backdrop"><div class="mc-grid"></div>';
	echo '<div class="mc-orbits"><span class="mc-orbit"></span><span class="mc-orbit"></span><span class="mc-orbit"></span></div></div></div>';
	echo '<div class="mc-hub-shell">';
	echo '<header class="mc-hub-top"><div class="mc-hub-top-inner">';
	echo '<a href="index.php" class="mc-hub-brand"><span class="mc-hub-mark" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4v16M4 12h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg></span><div><strong>MediCentral</strong><span>Member network</span></div></a>';
	echo '<button type="button" class="mc-hub-menu-btn" id="hubMenuBtn" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>';
	echo '<nav class="mc-hub-nav" id="hubNav"><div class="mc-hub-nav-pills">';
	mc_render_site_nav_pills($active, $navItems, 'mc-hub-nav-link', 'is-active');
	echo '</div></nav>';
	echo '<div class="mc-hub-user-block"><span class="mc-hub-avatar" aria-hidden="true">' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '</span><span class="mc-hub-user">' . $display . '</span>';
	echo '<a class="mc-hub-signout" href="../logout.php?to=network">Sign out</a></div>';
	echo '</div></header>';
	echo '<main class="mc-hub-main">';
}

function mc_member_shell_end(): void
{
	echo '</main>';
	mc_render_site_footer('../');
	echo '</div>';
	require_once __DIR__ . '/dr_aklilu_panel.php';
	mc_dr_aklilu_render_panel('network', '../');
	echo '<script src="../js/member-hub.js" defer></script>';
	echo '<script src="../js/dr-aklilu-format.js" defer></script>';
	echo '<script src="../js/dr-aklilu.js" defer></script>';
	echo '</body></html>';
}

function mc_member_flash(string $msg, string $kind = 'info'): void
{
	$c = $kind === 'success' ? 'mc-hub-flash success' : ($kind === 'error' ? 'mc-hub-flash error' : 'mc-hub-flash');
	echo '<div class="' . htmlspecialchars($c, ENT_QUOTES, 'UTF-8') . '" role="status">' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</div>';
}

function mc_member_page_head(string $title, string $subtitle = ''): void
{
	echo '<header class="mc-page-head">';
	echo '<h1>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h1>';
	if ($subtitle !== '') {
		echo '<p class="mc-hub-lead">' . htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8') . '</p>';
	}
	echo '</header>';
}
