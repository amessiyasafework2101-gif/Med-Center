<?php

declare(strict_types=1);

/**
 * Thread messages for one member ↔ pharmacist conversation (user channel).
 *
 * @return array<int, array<string, mixed>>
 */
function mc_chat_thread_member_pharmacist(mysqli $conn, int $pharmacistId, int $memberId): array
{
	if (!mc_table_has_column($conn, 'mc_pharmacist_messages', 'message_id')) {
		return [];
	}
	$sql = <<<'SQL'
SELECT message_id, sender_type, body, created_at, member_id, admin_id, sender_pharmacist_id
FROM mc_pharmacist_messages
WHERE pharmacist_id = ? AND channel = 'user'
  AND (member_id = ? OR (sender_type = 'pharmacist' AND sender_pharmacist_id = ? AND (member_id = ? OR member_id = 0)))
ORDER BY message_id ASC
LIMIT 200
SQL;
	$st = $conn->prepare($sql);
	if (!$st) {
		return [];
	}
	$st->bind_param('iiii', $pharmacistId, $memberId, $pharmacistId, $memberId);
	$st->execute();
	$res = $st->get_result();
	$rows = [];
	while ($r = $res->fetch_assoc()) {
		$rows[] = $r;
	}
	$st->close();

	return $rows;
}

/**
 * Members who have an open user-channel thread with this pharmacist.
 *
 * @return array<int, array<string, mixed>>
 */
function mc_chat_list_member_threads(mysqli $conn, int $pharmacistId): array
{
	$rows = [];
	$sql = <<<'SQL'
SELECT DISTINCT m.member_id, mb.first_name, mb.last_name, mb.username,
  (SELECT MAX(msg.created_at) FROM mc_pharmacist_messages msg
   WHERE msg.pharmacist_id = ? AND msg.channel = 'user' AND msg.member_id = m.member_id) AS last_at
FROM mc_pharmacist_messages m
INNER JOIN mc_members mb ON mb.member_id = m.member_id
WHERE m.pharmacist_id = ? AND m.channel = 'user' AND m.member_id > 0
ORDER BY last_at DESC
LIMIT 50
SQL;
	$st = $conn->prepare($sql);
	if (!$st) {
		return $rows;
	}
	$st->bind_param('ii', $pharmacistId, $pharmacistId);
	$st->execute();
	$res = $st->get_result();
	while ($r = $res->fetch_assoc()) {
		$rows[] = $r;
	}
	$st->close();

	return $rows;
}

/**
 * @param array<int, array<string, mixed>> $messages
 */
function mc_chat_render_bubbles(array $messages, string $viewerRole): void
{
	if ($messages === []) {
		echo '<p class="mc-chat-empty">No messages yet. Start the conversation below.</p>';

		return;
	}
	echo '<div class="mc-chat-thread" id="mcChatThread">';
	foreach ($messages as $m) {
		$sender = (string) ($m['sender_type'] ?? '');
		$isSelf = ($viewerRole === 'member' && $sender === 'member')
			|| ($viewerRole === 'pharmacist' && $sender === 'pharmacist')
			|| ($viewerRole === 'admin' && $sender === 'admin');
		$side = $isSelf ? 'out' : 'in';
		$label = match ($sender) {
			'member' => 'Member',
			'pharmacist' => 'Pharmacist',
			'admin' => 'Pharmacy admin',
			'system' => 'System',
			default => ucfirst($sender),
		};
		$time = htmlspecialchars((string) ($m['created_at'] ?? ''), ENT_QUOTES, 'UTF-8');
		echo '<div class="mc-chat-bubble mc-chat-' . $side . ' mc-chat-from-' . htmlspecialchars($sender, ENT_QUOTES, 'UTF-8') . '">';
		echo '<span class="mc-chat-bubble-meta">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . ' · ' . $time . '</span>';
		echo '<div class="mc-chat-bubble-body">' . nl2br(htmlspecialchars((string) ($m['body'] ?? ''), ENT_QUOTES, 'UTF-8')) . '</div>';
		echo '</div>';
	}
	echo '</div>';
}

/**
 * @param array<string, string> $hidden
 */
function mc_chat_render_composer(string $placeholder, array $hidden = []): void
{
	echo '<form method="post" class="mc-chat-composer">';
	foreach ($hidden as $name => $val) {
		echo '<input type="hidden" name="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($val, ENT_QUOTES, 'UTF-8') . '">';
	}
	echo '<div class="mc-chat-composer-inner">';
	echo '<textarea name="body" rows="2" required placeholder="' . htmlspecialchars($placeholder, ENT_QUOTES, 'UTF-8') . '" class="mc-chat-input"></textarea>';
	echo '<button type="submit" class="mc-chat-send" aria-label="Send"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg></button>';
	echo '</div></form>';
}

/**
 * Interactive star picker (hidden input name="score").
 */
function mc_rating_render_picker(string $inputName, int $selected = 0, string $label = 'Your rating'): void
{
	echo '<div class="mc-star-picker" data-input="' . htmlspecialchars($inputName, ENT_QUOTES, 'UTF-8') . '">';
	echo '<span class="mc-star-picker-label">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>';
	echo '<input type="hidden" name="' . htmlspecialchars($inputName, ENT_QUOTES, 'UTF-8') . '" value="' . ($selected > 0 ? $selected : '') . '" class="mc-star-picker-value" required>';
	echo '<div class="mc-star-picker-stars" role="radiogroup" aria-label="' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '">';
	for ($i = 1; $i <= 5; $i++) {
		$on = $selected >= $i ? ' is-on' : '';
		echo '<button type="button" class="mc-star-pick' . $on . '" data-value="' . $i . '" aria-label="' . $i . ' stars">★</button>';
	}
	echo '</div>';
	echo '<span class="mc-star-picker-hint">Tap stars to rate — saved to performance score</span>';
	echo '</div>';
}
