<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/system_auth.php';

mc_session_start();

if (!mc_system_gate_unlocked()) {
	header('Location: index.php');
	exit;
}

if (!mc_system_is_logged_in()) {
	header('Location: index.php?step=login');
	exit;
}
