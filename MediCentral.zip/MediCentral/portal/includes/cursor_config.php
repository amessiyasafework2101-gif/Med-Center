<?php

declare(strict_types=1);

$localCursor = __DIR__ . '/cursor_config.local.php';
if (is_readable($localCursor)) {
	require_once $localCursor;
}
if (!defined('MC_CURSOR_API_KEY')) {
	define('MC_CURSOR_API_KEY', '');
}
if (!defined('MC_CURSOR_MODEL_ID')) {
	define('MC_CURSOR_MODEL_ID', 'composer-2');
}

function mc_cursor_api_key(): string
{
	if (defined('MC_CURSOR_API_KEY') && MC_CURSOR_API_KEY !== '' && MC_CURSOR_API_KEY !== 'PASTE_YOUR_CRSR_KEY_HERE') {
		return (string) MC_CURSOR_API_KEY;
	}
	$env = getenv('MC_CURSOR_API_KEY');

	return $env !== false ? trim($env) : '';
}

function mc_cursor_model_id(): string
{
	if (defined('MC_CURSOR_MODEL_ID') && MC_CURSOR_MODEL_ID !== '') {
		return (string) MC_CURSOR_MODEL_ID;
	}

	return 'composer-2';
}

function mc_cursor_api_configured(): bool
{
	return mc_cursor_api_key() !== '';
}
