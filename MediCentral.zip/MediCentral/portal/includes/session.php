<?php

declare(strict_types=1);

function mc_portal_session_path(): string
{
	$script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
	$dir = rtrim(dirname($script), '/');
	if ($dir === '' || $dir === '.') {
		return '/';
	}
	// Keep cookie scoped to portal/ (not parent /MediCentral/) so sign-in on index.php
	// still works on member/, admin/, pharmacist/, etc.
	$portalSubs = ['member', 'admin', 'pharmacist', 'system', 'pharmacy', 'api', 'scripts'];
	$leaf = basename($dir);
	if (in_array($leaf, $portalSubs, true)) {
		$dir = dirname($dir);
	}

	return $dir . '/';
}

/** Seconds until idle session expiry (server-side + cookie Max-Age). Default 30 days. */
function mc_session_lifetime_seconds(): int
{
	$fromEnv = getenv('MC_SESSION_LIFETIME_SECONDS');
	if ($fromEnv !== false && is_numeric($fromEnv)) {
		$s = max(3600, (int) $fromEnv); // at least 1 hour

		return min($s, 31536000); // cap 1 year
	}

	return 86400 * 30;
}

/** For session_set_cookie_params / clearing login cookie consistently. */
function mc_session_cookie_params_base(): array
{
	$lifetime = mc_session_lifetime_seconds();
	$secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

	return [
		'lifetime' => $lifetime,
		'path' => mc_portal_session_path(),
		'domain' => '',
		'secure' => $secure,
		'httponly' => true,
		'samesite' => 'Lax',
	];
}

function mc_session_start(): void
{
	if (session_status() !== PHP_SESSION_NONE) {
		return;
	}

	$lifetime = mc_session_lifetime_seconds();
	// Default PHP gc_maxlifetime (often 1440s) destroys session files while the cookie is still sent.
	ini_set('session.gc_maxlifetime', (string) $lifetime);

	session_set_cookie_params(mc_session_cookie_params_base());

	session_start();

	$_SESSION['_mc_sess_started_at'] ??= time();
}

function mc_clear_session_cookie(): void
{
	$p = mc_session_cookie_params_base();
	setcookie(session_name(), '', [
		'expires' => time() - 3600,
		'path' => $p['path'],
		'domain' => $p['domain'],
		'secure' => $p['secure'],
		'httponly' => $p['httponly'],
		'samesite' => $p['samesite'],
	]);
}
