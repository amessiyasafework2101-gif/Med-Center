<?php

declare(strict_types=1);

function mc_bootstrap_contact_schema(mysqli $conn): void
{
	if (mc_table_has_column($conn, 'mc_contact_messages', 'message_id')) {
		return;
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$sql = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_contact_messages` (
  `message_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int unsigned NOT NULL,
  `sender_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_role` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender_ref_id` bigint unsigned DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `ix_contact_admin_read` (`admin_id`, `is_read`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
		@$conn->query($sql);
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

function mc_main_admin_id(mysqli $conn): int
{
	$stmt = $conn->prepare('SELECT admin_id FROM mc_admins WHERE username = ? LIMIT 1');
	if ($stmt) {
		$user = 'admin';
		$stmt->bind_param('s', $user);
		$stmt->execute();
		$res = $stmt->get_result();
		$row = $res ? $res->fetch_assoc() : null;
		$stmt->close();
		if ($row) {
			return (int) $row['admin_id'];
		}
	}

	$res = $conn->query('SELECT admin_id FROM mc_admins ORDER BY admin_id ASC LIMIT 1');
	if ($res && ($row = $res->fetch_assoc())) {
		return (int) $row['admin_id'];
	}

	return 0;
}

/**
 * @param array{name: string, email: string, phone?: string, subject: string, body: string, role?: string, ref_id?: int} $in
 * @return array{ok: bool, error: string}
 */
function mc_contact_submit(mysqli $conn, array $in): array
{
	mc_bootstrap_contact_schema($conn);

	$name = trim((string) ($in['name'] ?? ''));
	$email = trim((string) ($in['email'] ?? ''));
	$phone = trim((string) ($in['phone'] ?? ''));
	$subject = trim((string) ($in['subject'] ?? ''));
	$body = trim((string) ($in['body'] ?? ''));
	$role = trim((string) ($in['role'] ?? 'guest'));
	$refId = isset($in['ref_id']) ? (int) $in['ref_id'] : null;

	if ($name === '' || $email === '' || $subject === '' || $body === '') {
		return ['ok' => false, 'error' => 'Please fill in name, email, subject, and message.'];
	}
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		return ['ok' => false, 'error' => 'Enter a valid email address.'];
	}
	if (mb_strlen($body) < 10) {
		return ['ok' => false, 'error' => 'Message should be at least 10 characters.'];
	}

	$adminId = mc_main_admin_id($conn);
	if ($adminId <= 0) {
		return ['ok' => false, 'error' => 'No administrator is configured to receive messages.'];
	}

	$phoneVal = $phone === '' ? null : $phone;
	$roleVal = $role === '' ? 'guest' : $role;
	$refVal = $refId !== null && $refId > 0 ? $refId : 0;

	$stmt = $conn->prepare(
		'INSERT INTO mc_contact_messages (admin_id, sender_name, sender_email, sender_phone, subject, body, sender_role, sender_ref_id)
		 VALUES (?,?,?,?,?,?,?,?)'
	);
	if (!$stmt) {
		return ['ok' => false, 'error' => 'Could not save your message.'];
	}
	$stmt->bind_param('issssssi', $adminId, $name, $email, $phoneVal, $subject, $body, $roleVal, $refVal);
	if (!$stmt->execute()) {
		$stmt->close();

		return ['ok' => false, 'error' => 'Could not send your message. Please try again.'];
	}
	$stmt->close();

	return ['ok' => true, 'error' => ''];
}

function mc_contact_unread_count(mysqli $conn, int $adminId): int
{
	if (!mc_table_has_column($conn, 'mc_contact_messages', 'message_id') || $adminId <= 0) {
		return 0;
	}
	$stmt = $conn->prepare(
		'SELECT COUNT(*) AS c FROM mc_contact_messages WHERE admin_id = ? AND is_read = 0'
	);
	if (!$stmt) {
		return 0;
	}
	$stmt->bind_param('i', $adminId);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();

	return (int) ($row['c'] ?? 0);
}

/**
 * @return list<array<string, mixed>>
 */
function mc_contact_list_for_admin(mysqli $conn, int $adminId, int $limit = 80): array
{
	if (!mc_table_has_column($conn, 'mc_contact_messages', 'message_id')) {
		return [];
	}
	$limit = max(1, min(200, $limit));
	$stmt = $conn->prepare(
		"SELECT message_id, sender_name, sender_email, sender_phone, subject, body, sender_role, is_read, created_at
		 FROM mc_contact_messages WHERE admin_id = ? ORDER BY created_at DESC LIMIT {$limit}"
	);
	if (!$stmt) {
		return [];
	}
	$stmt->bind_param('i', $adminId);
	$stmt->execute();
	$res = $stmt->get_result();
	$rows = [];
	while ($row = $res->fetch_assoc()) {
		$rows[] = $row;
	}
	$stmt->close();

	return $rows;
}

function mc_contact_mark_read(mysqli $conn, int $messageId, int $adminId): bool
{
	$stmt = $conn->prepare(
		'UPDATE mc_contact_messages SET is_read = 1 WHERE message_id = ? AND admin_id = ? LIMIT 1'
	);
	if (!$stmt) {
		return false;
	}
	$stmt->bind_param('ii', $messageId, $adminId);
	$ok = $stmt->execute() && $stmt->affected_rows > 0;
	$stmt->close();

	return $ok;
}
