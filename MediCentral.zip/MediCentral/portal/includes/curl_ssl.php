<?php

declare(strict_types=1);

/**
 * CA bundle paths for PHP/cURL on Windows (WAMP often ships without curl.cainfo).
 */
function mc_curl_ca_bundle_path(): ?string
{
	if (defined('MC_CURSOR_CA_BUNDLE')) {
		$custom = (string) MC_CURSOR_CA_BUNDLE;
		if ($custom !== '' && is_readable($custom)) {
			return $custom;
		}
	}

	$candidates = [
		__DIR__ . '/cacert.pem',
		ini_get('curl.cainfo') ?: '',
		ini_get('openssl.cafile') ?: '',
	];

	$wampRoot = dirname(__DIR__, 2);
	if (is_dir($wampRoot . '/bin/php')) {
		foreach (glob($wampRoot . '/bin/php/php*/extras/ssl/cacert.pem') ?: [] as $path) {
			$candidates[] = $path;
		}
	}

	foreach ($candidates as $path) {
		$path = trim((string) $path);
		if ($path !== '' && is_readable($path)) {
			return $path;
		}
	}

	return null;
}

/**
 * @return array<int, mixed>
 */
function mc_curl_ssl_options(): array
{
	if (defined('MC_CURSOR_SSL_VERIFY') && MC_CURSOR_SSL_VERIFY === false) {
		return [
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_SSL_VERIFYHOST => 0,
		];
	}

	$ca = mc_curl_ca_bundle_path();
	if ($ca !== null) {
		return [
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_CAINFO => $ca,
		];
	}

	return [
		CURLOPT_SSL_VERIFYPEER => true,
		CURLOPT_SSL_VERIFYHOST => 2,
	];
}

function mc_curl_ssl_setup_hint(): string
{
	$bundle = __DIR__ . '/cacert.pem';

	return 'SSL certificate error: download https://curl.se/ca/cacert.pem to '
		. $bundle
		. ' or set curl.cainfo in php.ini. For local dev only, add define(\'MC_CURSOR_SSL_VERIFY\', false); to cursor_config.local.php.';
}

function mc_curl_format_error(string $curlErr): string
{
	if ($curlErr === '') {
		return '';
	}
	if (stripos($curlErr, 'SSL') !== false || stripos($curlErr, 'certificate') !== false) {
		return $curlErr . ' — ' . mc_curl_ssl_setup_hint();
	}

	return $curlErr;
}
