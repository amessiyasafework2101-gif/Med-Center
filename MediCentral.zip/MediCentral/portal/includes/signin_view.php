<?php

declare(strict_types=1);

require_once __DIR__ . '/site_footer.php';
require_once __DIR__ . '/site_nav.php';

/**
 * @param array{
 *   portal: 'network'|'pharmacy',
 *   page_title: string,
 *   badge: string,
 *   headline: string,
 *   headline_span: string,
 *   blurb: string,
 *   card_title: string,
 *   card_sub: string,
 *   roles: list<array{id: string, value: string, label: string, checked: bool}>,
 *   error: string,
 *   uname_display: string,
 *   foot_html: string,
 *   mini_link_html: string,
 *   switch_label: string,
 *   switch_href: string,
 *   form_action: string,
 *   asset_prefix?: string
 * } $v
 */
function mc_render_signin_page(array $v): void
{
	$portal = $v['portal'];
	$prefix = $v['asset_prefix'] ?? '';
	$bodyClass = $portal === 'pharmacy' ? 'mc-pharmacy-signin' : 'mc-network-signin';
	$alertClass = ($v['error'] ?? '') !== '' ? 'mc-alert mc-show' : 'mc-alert';
	$roleCount = count($v['roles']);
	$toggleClass = $roleCount === 2 ? 'mc-role-toggle mc-role-toggle-2' : 'mc-role-toggle mc-role-toggle-3';
	?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo htmlspecialchars($v['page_title'], ENT_QUOTES, 'UTF-8'); ?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo htmlspecialchars($prefix . 'css/signin.css', ENT_QUOTES, 'UTF-8'); ?>">
	<link rel="stylesheet" href="<?php echo htmlspecialchars($prefix . 'css/public-pages.css', ENT_QUOTES, 'UTF-8'); ?>">
	<?php if ($portal === 'pharmacy'): ?>
	<link rel="stylesheet" href="<?php echo htmlspecialchars($prefix . 'css/signin-pharmacy.css', ENT_QUOTES, 'UTF-8'); ?>">
	<?php endif; ?>
</head>
<body class="<?php echo htmlspecialchars($bodyClass, ENT_QUOTES, 'UTF-8'); ?> mc-signin-has-nav">
	<?php
	$signinNav = mc_site_nav_items('public', $prefix);
	$signinActive = 'home';
	?>
	<header class="mc-pub-top mc-signin-top">
		<a href="<?php echo htmlspecialchars($signinNav[0]['href'], ENT_QUOTES, 'UTF-8'); ?>" class="mc-pub-brand"><strong>MediCentral</strong></a>
		<?php mc_render_site_nav_bar($signinActive, $signinNav); ?>
	</header>
	<div class="mc-backdrop" aria-hidden="true">
		<div class="mc-grid"></div>
		<div class="mc-orbits">
			<div class="mc-orbit"></div>
			<div class="mc-orbit"></div>
			<div class="mc-orbit"></div>
		</div>
	</div>

	<div class="mc-wrap">
		<section class="mc-panel-brand">
			<div class="mc-badge"><span class="mc-badge-dot" aria-hidden="true"></span> <?php echo htmlspecialchars($v['badge'], ENT_QUOTES, 'UTF-8'); ?></div>
			<h1 class="mc-headline"><?php echo htmlspecialchars($v['headline'], ENT_QUOTES, 'UTF-8'); ?> <span><?php echo htmlspecialchars($v['headline_span'], ENT_QUOTES, 'UTF-8'); ?></span></h1>
			<p class="mc-blurb"><?php echo htmlspecialchars($v['blurb'], ENT_QUOTES, 'UTF-8'); ?></p>
			<div class="mc-stats">
				<?php if ($portal === 'pharmacy'): ?>
				<div class="mc-stat"><strong>Inventory</strong><span>Stock &amp; barcodes</span></div>
				<div class="mc-stat"><strong>POS</strong><span>Sales workspace</span></div>
				<div class="mc-stat"><strong>Admin</strong><span>Pharmacy control</span></div>
				<?php else: ?>
				<div class="mc-stat"><strong>Members</strong><span>Search &amp; order</span></div>
				<div class="mc-stat"><strong>Pharmacists</strong><span>Professional network</span></div>
				<div class="mc-stat"><strong>Secure</strong><span>Verified access</span></div>
				<?php endif; ?>
			</div>
		</section>

		<div class="mc-signin-shell">
			<div class="mc-signin-card">
				<a class="mc-portal-switch" href="<?php echo htmlspecialchars($v['switch_href'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($v['switch_label'], ENT_QUOTES, 'UTF-8'); ?></a>
				<form method="post" action="<?php echo htmlspecialchars($v['form_action'], ENT_QUOTES, 'UTF-8'); ?>" autocomplete="on">
					<div class="mc-logo-row">
						<div style="display:flex;align-items:center;gap:0.95rem;">
							<div class="mc-logo-mark" aria-hidden="true">
								<svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
									<path d="M10 17V9l6-4 6 4v8c0 4-6 10-6 10S10 21 10 17z" stroke="currentColor" stroke-width="1.85" stroke-linejoin="round"/>
									<path d="M16 13v10" stroke="currentColor" stroke-width="1.85" stroke-linecap="round"/>
									<path d="M12 17h8" stroke="currentColor" stroke-width="1.85" stroke-linecap="round"/>
								</svg>
							</div>
							<div class="mc-logo-text">
								<h2>MediCentral</h2>
								<p><?php echo $portal === 'pharmacy' ? 'Pharmacy operations' : 'Member &amp; pharmacist network'; ?></p>
							</div>
						</div>
					</div>

					<div class="<?php echo $toggleClass; ?>" role="group" aria-label="Sign-in role">
						<?php foreach ($v['roles'] as $r): ?>
						<input type="radio" name="role" id="<?php echo htmlspecialchars($r['id'], ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars($r['value'], ENT_QUOTES, 'UTF-8'); ?>"<?php echo $r['checked'] ? ' checked' : ''; ?>>
						<label for="<?php echo htmlspecialchars($r['id'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($r['label'], ENT_QUOTES, 'UTF-8'); ?></label>
						<?php endforeach; ?>
					</div>

					<h3 class="mc-title" style="margin-top:1.5rem;"><?php echo htmlspecialchars($v['card_title'], ENT_QUOTES, 'UTF-8'); ?></h3>
					<p class="mc-sub"><?php echo htmlspecialchars($v['card_sub'], ENT_QUOTES, 'UTF-8'); ?></p>

					<div id="login-alert" class="<?php echo htmlspecialchars($alertClass, ENT_QUOTES, 'UTF-8'); ?>" role="<?php echo ($v['error'] ?? '') !== '' ? 'alert' : 'presentation'; ?>">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h0"/></svg>
						<span><?php echo ($v['error'] ?? '') !== '' ? htmlspecialchars($v['error'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
					</div>

					<div class="mc-field">
						<input type="text" name="uname" id="uname" autocomplete="username" value="<?php echo htmlspecialchars($v['uname_display'], ENT_QUOTES, 'UTF-8'); ?>" autocapitalize="words" spellcheck="false">
						<label class="mc-float-label" for="uname">Username</label>
					</div>

					<div class="mc-field mc-pw">
						<input type="password" name="pwd" id="pwd" autocomplete="current-password">
						<label class="mc-float-label" for="pwd">Password</label>
						<button type="button" class="mc-toggle-eye" data-target="pwd" aria-label="Show password">
							<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="12" rx="10" ry="6"/><circle cx="12" cy="12" r="2.5"/><path d="M2 12h2m16 0h2"/></svg>
						</button>
					</div>

					<button type="submit" name="submit" value="1" class="mc-btn">Sign in</button>
				</form>

				<?php if (($v['mini_link_html'] ?? '') !== ''): ?>
				<p class="mc-mini-link"><?php echo $v['mini_link_html']; ?></p>
				<?php endif; ?>
				<p class="mc-foot"><?php echo $v['foot_html']; ?></p>
			</div>
		</div>
	</div>

	<?php mc_render_site_footer(); ?>

	<script src="<?php echo htmlspecialchars($prefix . 'js/signin.js', ENT_QUOTES, 'UTF-8'); ?>" defer></script>
</body>
</html>
	<?php
}
