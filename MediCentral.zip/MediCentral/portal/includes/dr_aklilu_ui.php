<?php

declare(strict_types=1);

require_once __DIR__ . '/cursor_config.php';

/**
 * @param 'network'|'pharmacy' $portal
 * @param 'widget'|'page' $mode
 */
function mc_dr_aklilu_render_ui(
	string $portal,
	string $assetPrefix,
	string $mode = 'widget',
	bool $showCv = false,
	string $backHref = '',
	string $backLabel = 'Back'
): void {
	$portal = $portal === 'pharmacy' ? 'pharmacy' : 'network';
	$mode = $mode === 'page' ? 'page' : 'widget';
	$configured = mc_cursor_api_configured();
	$subtitle = $portal === 'pharmacy'
		? 'Clinical AI · pharmacy operations'
		: 'Your MediCentral health assistant';
	$welcome = $portal === 'pharmacy'
		? 'Ask about medicines, stock, counselling, or paste optional CV notes for review.'
		: 'Ask about medicines, dosing, safety, and everyday health questions. I give clear, structured answers — not a diagnosis.';
	$fullPageHref = $assetPrefix . 'ai/index.php';
	$rootClass = 'dr-ak' . ($mode === 'page' ? ' dr-ak-page' : '');
	?>
<div class="<?php echo $rootClass; ?>" id="drAklilu"
	data-mode="<?php echo htmlspecialchars($mode, ENT_QUOTES, 'UTF-8'); ?>"
	data-portal="<?php echo htmlspecialchars($portal, ENT_QUOTES, 'UTF-8'); ?>"
	data-api="<?php echo htmlspecialchars($assetPrefix . 'api/dr-aklilu.php', ENT_QUOTES, 'UTF-8'); ?>"
	data-configured="<?php echo $configured ? '1' : '0'; ?>">
	<?php if ($mode === 'widget'): ?>
	<button type="button" class="dr-ak-fab" id="drAkliluFab" aria-expanded="false" aria-controls="drAkliluPanel">
		<span class="dr-ak-fab-ico" aria-hidden="true">✦</span>
		<span class="dr-ak-fab-label">Dr. Aklilu</span>
	</button>
	<?php endif; ?>
	<div class="dr-ak-panel" id="drAkliluPanel"<?php echo $mode === 'page' ? '' : ' hidden'; ?>>
		<header class="dr-ak-head">
			<div class="dr-ak-avatar" aria-hidden="true">DA</div>
			<div class="dr-ak-head-text">
				<strong>Dr. Aklilu</strong>
				<span><?php echo htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8'); ?></span>
			</div>
			<div class="dr-ak-head-actions">
				<?php if ($mode === 'widget'): ?>
				<a class="dr-ak-expand" href="<?php echo htmlspecialchars($fullPageHref, ENT_QUOTES, 'UTF-8'); ?>" title="Open full AI page">Full page</a>
				<button type="button" class="dr-ak-close" id="drAkliluClose" aria-label="Close">×</button>
				<?php elseif ($backHref !== ''): ?>
				<a class="dr-ak-back" href="<?php echo htmlspecialchars($backHref, ENT_QUOTES, 'UTF-8'); ?>">← <?php echo htmlspecialchars($backLabel, ENT_QUOTES, 'UTF-8'); ?></a>
				<?php endif; ?>
			</div>
		</header>
		<?php if ($mode === 'page'): ?>
		<div class="dr-ak-hero">
			<p class="dr-ak-hero-lead">Chat with Dr. Aklilu for plain-language clinical guidance. Scroll through your conversation below — replies are formatted for easy reading.</p>
			<div class="dr-ak-chips" id="drAkliluChips">
				<button type="button" class="dr-ak-chip" data-prompt="What should I check before recommending an OTC pain reliever?">OTC safety</button>
				<button type="button" class="dr-ak-chip" data-prompt="Explain common drug interaction categories in simple terms.">Interactions</button>
				<button type="button" class="dr-ak-chip" data-prompt="How do I counsel a patient starting a new chronic medication?">Counselling tips</button>
				<button type="button" class="dr-ak-chip" data-prompt="What are red-flag symptoms that need urgent care?">Urgent care signs</button>
				<button type="button" class="dr-ak-chip" data-prompt="Summarize good storage and handling practices for common pharmacy medicines.">Storage &amp; handling</button>
			</div>
		</div>
		<?php endif; ?>
		<?php if (!$configured): ?>
		<p class="dr-ak-warn">Add your Cursor API key in <code>includes/cursor_config.local.php</code> to enable Dr. Aklilu.</p>
		<?php endif; ?>
		<div class="dr-ak-log" id="drAkliluLog" role="log" aria-live="polite">
			<div class="dr-ak-msg dr-ak-bot">
				<div class="dr-ak-body">
					<p>Hello, I'm <strong>Dr. Aklilu</strong>. <?php echo htmlspecialchars($welcome, ENT_QUOTES, 'UTF-8'); ?></p>
					<p class="dr-ak-disclaimer">Educational support only — always follow local regulations and consult a licensed professional for personal care.</p>
				</div>
			</div>
		</div>
		<?php if ($showCv): ?>
		<div class="dr-ak-cv">
			<label class="dr-ak-cv-lbl" for="drAkliluCvText">CV / notes (optional)</label>
			<textarea id="drAkliluCvText" rows="2" placeholder="Paste CV text or notes for review…"></textarea>
			<label class="dr-ak-cv-file">Attach .txt / .md
				<input type="file" id="drAkliluCvFile" accept=".txt,.md,text/plain,text/markdown">
			</label>
		</div>
		<?php endif; ?>
		<form class="dr-ak-form" id="drAkliluForm">
			<textarea id="drAkliluInput" rows="<?php echo $mode === 'page' ? '3' : '2'; ?>" required placeholder="Ask Dr. Aklilu…" <?php echo $configured ? '' : ' disabled'; ?>></textarea>
			<div class="dr-ak-actions">
				<button type="button" class="dr-ak-reset" id="drAkliluReset" <?php echo $configured ? '' : ' disabled'; ?>>New chat</button>
				<button type="submit" class="dr-ak-send" <?php echo $configured ? '' : ' disabled'; ?>>
					<span class="dr-ak-send-label">Send</span>
				</button>
			</div>
		</form>
	</div>
</div>
	<?php
}
