<?php

declare(strict_types=1);

/** @var mysqli $conn */

function mc_member_load_profile(mysqli $conn, int $memberId): array
{
	$out = [
		'member_id' => $memberId,
		'username' => (string) ($_SESSION['mc_username'] ?? ''),
		'first_name' => '',
		'last_name' => '',
		'display' => 'Member',
		'email' => '',
		'phone' => '',
	];
	if ($memberId <= 0) {
		return $out;
	}
	$st = $conn->prepare(
		'SELECT username, first_name, last_name, email, phone FROM mc_members WHERE member_id = ? AND is_active = 1 LIMIT 1'
	);
	if (!$st) {
		return $out;
	}
	$st->bind_param('i', $memberId);
	$st->execute();
	$st->bind_result($u, $f, $l, $e, $p);
	if ($st->fetch()) {
		$out['username'] = (string) $u;
		$out['first_name'] = (string) $f;
		$out['last_name'] = (string) ($l ?? '');
		$out['email'] = (string) ($e ?? '');
		$out['phone'] = (string) ($p ?? '');
		$out['display'] = trim($out['first_name'] . ' ' . $out['last_name']) ?: $out['username'];
	}
	$st->close();

	return $out;
}
