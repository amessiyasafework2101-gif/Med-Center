<?php

declare(strict_types=1);

require_once __DIR__ . '/cursor_config.php';
require_once __DIR__ . '/curl_ssl.php';

const MC_DR_AKLILU_API_BASE = 'https://api.cursor.com';

/**
 * @return array{ok: bool, error: string, text: string, agent_id: string}
 */
function mc_dr_aklilu_chat(string $portal, string $userMessage, string $systemContext, ?string $existingAgentId = null): array
{
	$apiKey = mc_cursor_api_key();
	if ($apiKey === '') {
		return [
			'ok' => false,
			'error' => 'Dr. Aklilu is not configured. Add your Cursor API key in portal/includes/cursor_config.local.php',
			'text' => '',
			'agent_id' => '',
		];
	}

	$userMessage = trim($userMessage);
	if ($userMessage === '') {
		return ['ok' => false, 'error' => 'Please enter a message.', 'text' => '', 'agent_id' => ''];
	}

	$promptText = $systemContext . "\n\n---\nUser message:\n" . $userMessage;

	if ($existingAgentId !== null && $existingAgentId !== '') {
		$runRes = mc_cursor_api_json(
			'POST',
			'/v1/agents/' . rawurlencode($existingAgentId) . '/runs',
			['prompt' => ['text' => $promptText]],
			$apiKey
		);
		if (!$runRes['ok']) {
			return ['ok' => false, 'error' => $runRes['error'], 'text' => '', 'agent_id' => $existingAgentId];
		}
		$runId = (string) ($runRes['data']['run']['id'] ?? '');
		if ($runId === '') {
			return ['ok' => false, 'error' => 'Could not start follow-up with Dr. Aklilu.', 'text' => '', 'agent_id' => $existingAgentId];
		}

		return mc_dr_aklilu_wait_stream($existingAgentId, $runId, $apiKey);
	}

	$body = [
		'prompt' => ['text' => $promptText],
		'model' => ['id' => mc_cursor_model_id()],
	];
	$createRes = mc_cursor_api_json('POST', '/v1/agents', $body, $apiKey);
	if (!$createRes['ok']) {
		return ['ok' => false, 'error' => $createRes['error'], 'text' => '', 'agent_id' => ''];
	}
	$agentId = (string) ($createRes['data']['agent']['id'] ?? '');
	$runId = (string) ($createRes['data']['run']['id'] ?? '');
	if ($agentId === '' || $runId === '') {
		return ['ok' => false, 'error' => 'Dr. Aklilu could not start a session.', 'text' => '', 'agent_id' => ''];
	}

	$out = mc_dr_aklilu_wait_stream($agentId, $runId, $apiKey);
	$out['agent_id'] = $agentId;

	return $out;
}

/**
 * @return array{ok: bool, error: string, text: string, agent_id: string}
 */
function mc_dr_aklilu_wait_stream(string $agentId, string $runId, string $apiKey): array
{
	$url = MC_DR_AKLILU_API_BASE . '/v1/agents/' . rawurlencode($agentId) . '/runs/' . rawurlencode($runId) . '/stream';
	$text = '';
	$error = '';
	$finished = false;

	$ch = curl_init($url);
	if ($ch === false) {
		return ['ok' => false, 'error' => 'Network error.', 'text' => '', 'agent_id' => $agentId];
	}
	curl_setopt_array($ch, [
		CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
		CURLOPT_USERPWD => $apiKey . ':',
		CURLOPT_HTTPHEADER => ['Accept: text/event-stream'],
		CURLOPT_RETURNTRANSFER => false,
		CURLOPT_TIMEOUT => 120,
		CURLOPT_WRITEFUNCTION => static function ($curl, string $chunk) use (&$text, &$error, &$finished): int {
			$lines = explode("\n", $chunk);
			foreach ($lines as $line) {
				$line = trim($line);
				if ($line === '' || str_starts_with($line, 'id:')) {
					continue;
				}
				if (str_starts_with($line, 'event:')) {
					$event = trim(substr($line, 6));
					if ($event === 'done') {
						$finished = true;
					}
					continue;
				}
				if (str_starts_with($line, 'data:')) {
					$json = trim(substr($line, 5));
					if ($json === '' || $json === '{}') {
						continue;
					}
					$data = json_decode($json, true);
					if (!is_array($data)) {
						continue;
					}
					if (isset($data['text']) && is_string($data['text'])) {
						$text .= $data['text'];
					} elseif (isset($data['result']) && is_string($data['result'])) {
						$text .= $data['result'];
					} elseif (isset($data['content']) && is_string($data['content'])) {
						$text .= $data['content'];
					} elseif (isset($data['delta']) && is_array($data['delta']) && isset($data['delta']['text'])) {
						$text .= (string) $data['delta']['text'];
					}
					if (isset($data['message']) && is_string($data['message'])) {
						$error = $data['message'];
					}
				}
			}

			return strlen($chunk);
		},
	] + mc_curl_ssl_options());
	$ok = curl_exec($ch);
	$httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$curlErr = mc_curl_format_error(curl_error($ch));
	curl_close($ch);

	if ($ok === false) {
		return ['ok' => false, 'error' => $curlErr !== '' ? $curlErr : 'Stream failed.', 'text' => '', 'agent_id' => $agentId];
	}
	if ($httpCode === 410) {
		return mc_dr_aklilu_poll_fallback($agentId, $runId, $apiKey);
	}
	if ($httpCode >= 400) {
		return ['ok' => false, 'error' => $error !== '' ? $error : 'Dr. Aklilu request failed (HTTP ' . $httpCode . ').', 'text' => '', 'agent_id' => $agentId];
	}

	$text = trim($text);
	if ($text === '') {
		return mc_dr_aklilu_poll_fallback($agentId, $runId, $apiKey);
	}

	return ['ok' => true, 'error' => '', 'text' => $text, 'agent_id' => $agentId];
}

/**
 * @return array{ok: bool, error: string, text: string, agent_id: string}
 */
function mc_dr_aklilu_poll_fallback(string $agentId, string $runId, string $apiKey): array
{
	for ($i = 0; $i < 45; $i++) {
		usleep(2000000);
		$res = mc_cursor_api_json(
			'GET',
			'/v1/agents/' . rawurlencode($agentId) . '/runs/' . rawurlencode($runId),
			null,
			$apiKey
		);
		if (!$res['ok']) {
			continue;
		}
		$status = (string) ($res['data']['status'] ?? '');
		if (in_array($status, ['FINISHED', 'FAILED', 'CANCELLED', 'ERROR'], true)) {
			if ($status === 'FINISHED') {
				$reply = trim((string) ($res['data']['result'] ?? ''));
				if ($reply === '') {
					$reply = 'Dr. Aklilu completed your request. Open the chat again if you need more detail, or rephrase your question.';
				}

				return [
					'ok' => true,
					'error' => '',
					'text' => $reply,
					'agent_id' => $agentId,
				];
			}

			return ['ok' => false, 'error' => 'Dr. Aklilu could not finish (status: ' . $status . ').', 'text' => '', 'agent_id' => $agentId];
		}
	}

	return ['ok' => false, 'error' => 'Dr. Aklilu is taking longer than expected. Please try again.', 'text' => '', 'agent_id' => $agentId];
}

/**
 * @param array<string, mixed>|null $body
 * @return array{ok: bool, error: string, data: array<string, mixed>}
 */
function mc_cursor_api_json(string $method, string $path, ?array $body, string $apiKey): array
{
	$url = MC_DR_AKLILU_API_BASE . $path;
	$ch = curl_init($url);
	if ($ch === false) {
		return ['ok' => false, 'error' => 'Network error.', 'data' => []];
	}
	$headers = ['Content-Type: application/json', 'Accept: application/json'];
	$opts = [
		CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
		CURLOPT_USERPWD => $apiKey . ':',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_TIMEOUT => 90,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => $method,
	] + mc_curl_ssl_options();
	if ($body !== null) {
		$encoded = json_encode($body);
		if ($encoded === false) {
			return ['ok' => false, 'error' => 'Could not encode request.', 'data' => []];
		}
		$opts[CURLOPT_POSTFIELDS] = $encoded;
	}
	curl_setopt_array($ch, $opts);
	$raw = curl_exec($ch);
	$httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$curlErr = mc_curl_format_error(curl_error($ch));
	curl_close($ch);
	if ($raw === false) {
		return ['ok' => false, 'error' => $curlErr !== '' ? $curlErr : 'Request failed.', 'data' => []];
	}
	$data = json_decode($raw, true);
	if (!is_array($data)) {
		$data = [];
	}
	if ($httpCode >= 400) {
		$msg = (string) ($data['message'] ?? $data['error'] ?? 'API error HTTP ' . $httpCode);

		return ['ok' => false, 'error' => $msg, 'data' => $data];
	}

	return ['ok' => true, 'error' => '', 'data' => $data];
}

function mc_dr_aklilu_session_key(string $portal): string
{
	return $portal === 'pharmacy' ? 'mc_dr_aklilu_agent_pharmacy' : 'mc_dr_aklilu_agent_network';
}

function mc_dr_aklilu_build_member_context(mysqli $conn, int $memberId): string
{
	require_once __DIR__ . '/member_context.php';
	$p = mc_member_load_profile($conn, $memberId);
	$ctx = "You are Dr. Aklilu, MediCentral's clinical assistant for members.\n";
	$ctx .= "Provide general health education, medicine information, typical dosing ranges when appropriate, and safety reminders.\n";
	$ctx .= "Always advise consulting a licensed pharmacist or physician for personal medical decisions. Do not diagnose emergencies; tell users to seek urgent care when needed.\n";
	$ctx .= "Do not prescribe controlled substances. Be concise, warm, and professional.\n\n";
	$ctx .= "Member profile:\n";
	$ctx .= '- Name: ' . trim($p['first_name'] . ' ' . ($p['last_name'] ?? '')) . "\n";
	$ctx .= '- Username: ' . $p['username'] . "\n";
	if ($p['email'] !== '') {
		$ctx .= '- Email: ' . $p['email'] . "\n";
	}
	if ($p['phone'] !== '') {
		$ctx .= '- Phone: ' . $p['phone'] . "\n";
	}

	$orders = $conn->prepare(
		'SELECT status, COUNT(*) AS c FROM mc_member_orders WHERE member_id = ? GROUP BY status'
	);
	if ($orders) {
		$orders->bind_param('i', $memberId);
		$orders->execute();
		$res = $orders->get_result();
		$ctx .= "\nOrder activity:\n";
		while ($row = $res->fetch_assoc()) {
			$ctx .= '- ' . $row['status'] . ': ' . $row['c'] . "\n";
		}
		$orders->close();
	}

	return $ctx;
}

function mc_dr_aklilu_build_pharmacy_context(mysqli $conn, int $pharmacistId, string $cvExtra = ''): string
{
	$ctx = "You are Dr. Aklilu, MediCentral's clinical AI advisor for pharmacists and pharmacy operations.\n";
	$ctx .= "License and CV are optional on the platform — assist all signed-in pharmacists with medicines, dosing (general reference), interactions, inventory workflow, patient counselling, and optional CV review when provided.\n";
	$ctx .= "Support recruitment decisions with evidence-based professional judgment. Remind users to follow local regulations and pharmacy policy.\n\n";

	$stmt = $conn->prepare(
		'SELECT p.username, p.first_name, p.last_name, p.email, p.bio, p.cv_summary, p.license_number,
		p.performance_score, p.rating_count, ph.name AS pharmacy_name
		FROM mc_pharmacists p
		LEFT JOIN mc_pharmacies ph ON ph.pharmacy_id = p.pharmacy_id
		WHERE p.pharmacist_id = ? LIMIT 1'
	);
	if ($stmt) {
		$stmt->bind_param('i', $pharmacistId);
		$stmt->execute();
		$res = $stmt->get_result();
		if ($row = $res->fetch_assoc()) {
			$ctx .= "Pharmacist profile:\n";
			$ctx .= '- Name: ' . trim((string) $row['first_name'] . ' ' . (string) ($row['last_name'] ?? '')) . "\n";
			$ctx .= '- Username: ' . (string) $row['username'] . "\n";
			if ($row['pharmacy_name']) {
				$ctx .= '- Pharmacy: ' . (string) $row['pharmacy_name'] . "\n";
			}
			$ctx .= '- Performance: ' . (string) $row['performance_score'] . ' (' . (string) $row['rating_count'] . " ratings)\n";
			if ($row['license_number']) {
				$ctx .= '- License: ' . (string) $row['license_number'] . "\n";
			}
			if ($row['bio']) {
				$ctx .= '- Bio: ' . (string) $row['bio'] . "\n";
			}
			if ($row['cv_summary']) {
				$ctx .= "\nCV on file:\n" . (string) $row['cv_summary'] . "\n";
			}
		}
		$stmt->close();
	}

	if ($cvExtra !== '') {
		$ctx .= "\nUploaded CV / document excerpt:\n" . mb_substr($cvExtra, 0, 12000) . "\n";
	}

	return $ctx;
}
