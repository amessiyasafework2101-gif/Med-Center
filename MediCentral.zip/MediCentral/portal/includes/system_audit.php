<?php

declare(strict_types=1);

function mc_system_client_ip(): string
{
	$ip = $_SERVER['REMOTE_ADDR'] ?? '';

	return is_string($ip) ? substr($ip, 0, 45) : '';
}

/**
 * @param array<string, mixed>|null $details
 */
function mc_system_audit_log(
	mysqli $conn,
	string $action,
	string $entityType,
	?int $entityId = null,
	?string $summary = null,
	?array $details = null
): void {
	if (!mc_table_has_column($conn, 'mc_system_audit_log', 'audit_id')) {
		return;
	}

	$adminId = isset($_SESSION['mc_system_admin_id']) ? (int) $_SESSION['mc_system_admin_id'] : 0;
	$entityIdVal = $entityId ?? 0;
	$json = $details !== null ? json_encode($details, JSON_UNESCAPED_UNICODE) : null;
	$ip = mc_system_client_ip();

	$stmt = $conn->prepare(
		'INSERT INTO mc_system_audit_log (system_admin_id, action, entity_type, entity_id, summary, details_json, ip_address)
		VALUES (?,?,?,?,?,?,?)'
	);
	if (!$stmt) {
		return;
	}
	$stmt->bind_param('ississs', $adminId, $action, $entityType, $entityIdVal, $summary, $json, $ip);
	$stmt->execute();
	$stmt->close();
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_system_audit_recent(mysqli $conn, int $limit = 80): array
{
	$rows = [];
	if (!mc_table_has_column($conn, 'mc_system_audit_log', 'audit_id')) {
		return $rows;
	}
	$limit = max(1, min(200, $limit));
	$sql = <<<SQL
SELECT a.audit_id, a.action, a.entity_type, a.entity_id, a.summary, a.ip_address, a.created_at,
  COALESCE(sa.display_name, sa.username, '—') AS actor_name
FROM mc_system_audit_log a
LEFT JOIN mc_system_admins sa ON sa.system_admin_id = a.system_admin_id
ORDER BY a.audit_id DESC
LIMIT {$limit}
SQL;
	$res = $conn->query($sql);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$rows[] = $r;
		}
	}

	return $rows;
}
