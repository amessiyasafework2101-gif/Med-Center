<?php

declare(strict_types=1);

require_once __DIR__ . '/system_config.php';

function mc_system_gate_unlocked(): bool
{
	return !empty($_SESSION['mc_system_gate_ok']);
}

function mc_system_verify_gate_password(string $attempt): bool
{
	$expected = mc_system_gate_password();
	if ($expected === '') {
		return false;
	}

	return hash_equals($expected, $attempt);
}

function mc_system_unlock_gate(): void
{
	$_SESSION['mc_system_gate_ok'] = true;
	$_SESSION['mc_system_gate_at'] = time();
}

function mc_system_is_logged_in(): bool
{
	return isset($_SESSION['mc_role'], $_SESSION['mc_system_admin_id'])
		&& $_SESSION['mc_role'] === 'system'
		&& (int) $_SESSION['mc_system_admin_id'] > 0
		&& mc_system_gate_unlocked();
}

function mc_system_start_session(int $systemAdminId, string $username, string $displayName): void
{
	session_regenerate_id(true);
	$_SESSION['mc_role'] = 'system';
	$_SESSION['mc_system_admin_id'] = $systemAdminId;
	$_SESSION['mc_username'] = $username;
	$_SESSION['mc_system_display'] = $displayName;
}

function mc_system_touch_login(mysqli $conn, int $systemAdminId): void
{
	if (!mc_table_has_column($conn, 'mc_system_admins', 'last_login_at')) {
		return;
	}
	$stmt = $conn->prepare('UPDATE mc_system_admins SET last_login_at = CURRENT_TIMESTAMP WHERE system_admin_id = ? LIMIT 1');
	if ($stmt) {
		$stmt->bind_param('i', $systemAdminId);
		@$stmt->execute();
		$stmt->close();
	}
}

/**
 * @return array{ok: bool, error: string, admin?: array<string, mixed>}
 */
function mc_system_attempt_login(mysqli $conn, string $username, string $password): array
{
	if (!mc_table_has_column($conn, 'mc_system_admins', 'system_admin_id')) {
		return ['ok' => false, 'error' => 'System administrator module is not installed.'];
	}

	$user = mb_strtolower(trim($username), 'UTF-8');
	if ($user === '' || $password === '') {
		return ['ok' => false, 'error' => 'Enter username and password.'];
	}

	$stmt = $conn->prepare(
		'SELECT system_admin_id, username, password_hash, display_name, is_active
		FROM mc_system_admins WHERE username = ? LIMIT 1'
	);
	if (!$stmt) {
		return ['ok' => false, 'error' => 'Sign-in unavailable.'];
	}
	$stmt->bind_param('s', $user);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();

	if (!$row || !(int) ($row['is_active'] ?? 0)) {
		return ['ok' => false, 'error' => 'Invalid system administrator credentials.'];
	}
	if (!password_verify($password, (string) $row['password_hash'])) {
		return ['ok' => false, 'error' => 'Invalid system administrator credentials.'];
	}

	return ['ok' => true, 'error' => '', 'admin' => $row];
}
