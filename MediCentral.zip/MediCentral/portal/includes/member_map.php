<?php

declare(strict_types=1);

/**
 * @return array<int, array<string, mixed>>
 */
function mc_map_load_member_pharmacies(mysqli $conn): array
{
	$rows = [];
	if (!mc_table_has_column($conn, 'mc_pharmacies', 'latitude')) {
		return $rows;
	}

	$sql = <<<'SQL'
SELECT pharmacy_id, name, tagline, address, city, phone, latitude, longitude,
  (SELECT COUNT(*) FROM mc_pharmacy_inventory i WHERE i.pharmacy_id = ph.pharmacy_id AND i.quantity > 0) AS sku_cnt
FROM mc_pharmacies ph
WHERE ph.is_active = 1 AND ph.latitude IS NOT NULL AND ph.longitude IS NOT NULL
ORDER BY ph.name ASC
SQL;
	$res = $conn->query($sql);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$rows[] = [
				'id' => 'm-' . (int) $r['pharmacy_id'],
				'pharmacy_id' => (int) $r['pharmacy_id'],
				'name' => (string) $r['name'],
				'tagline' => (string) ($r['tagline'] ?? ''),
				'address' => trim((string) ($r['address'] ?? '') . ', ' . ($r['city'] ?? '')),
				'phone' => (string) ($r['phone'] ?? ''),
				'lat' => (float) $r['latitude'],
				'lng' => (float) $r['longitude'],
				'is_member' => true,
				'sku_cnt' => (int) $r['sku_cnt'],
				'profile_url' => 'pharmacies.php?id=' . (int) $r['pharmacy_id'],
				'order_url' => 'search.php?pharmacy_id=' . (int) $r['pharmacy_id'],
			];
		}
	}

	return $rows;
}

/**
 * @return array<int, array<string, mixed>>
 */
function mc_map_load_external_places(mysqli $conn): array
{
	$rows = [];
	if (!mc_table_has_column($conn, 'mc_pharmacy_places', 'place_id')) {
		return $rows;
	}

	$res = $conn->query(
		'SELECT place_id, name, address, city, phone, latitude, longitude, google_place_id
		FROM mc_pharmacy_places WHERE is_active = 1 ORDER BY name ASC'
	);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$rows[] = [
				'id' => 'p-' . (int) $r['place_id'],
				'place_id' => (int) $r['place_id'],
				'name' => (string) $r['name'],
				'tagline' => '',
				'address' => trim((string) ($r['address'] ?? '') . ', ' . ($r['city'] ?? '')),
				'phone' => (string) ($r['phone'] ?? ''),
				'lat' => (float) $r['latitude'],
				'lng' => (float) $r['longitude'],
				'is_member' => false,
				'google_place_id' => (string) ($r['google_place_id'] ?? ''),
				'profile_url' => '',
				'order_url' => '',
			];
		}
	}

	return $rows;
}

function mc_map_haversine_km(float $lat1, float $lng1, float $lat2, float $lng2): float
{
	$earth = 6371.0;
	$dLat = deg2rad($lat2 - $lat1);
	$dLng = deg2rad($lng2 - $lng1);
	$a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

	return $earth * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

/**
 * @param array<int, array<string, mixed>> $markers
 * @return array<int, array<string, mixed>>
 */
function mc_map_sort_by_distance(array $markers, float $userLat, float $userLng): array
{
	foreach ($markers as &$m) {
		$m['distance_km'] = mc_map_haversine_km($userLat, $userLng, (float) $m['lat'], (float) $m['lng']);
	}
	unset($m);
	usort($markers, static fn ($a, $b) => ($a['distance_km'] ?? 0) <=> ($b['distance_km'] ?? 0));

	return $markers;
}

/**
 * @param array<string, mixed> $marker
 * @return array<string, mixed>
 */
function mc_map_marker_to_locator_location(array $marker): array
{
	$addr = trim((string) ($marker['address'] ?? ''));
	$parts = $addr !== '' ? array_map('trim', explode(',', $addr, 2)) : ['', ''];
	$address1 = $parts[0] !== '' ? $parts[0] : ($addr !== '' ? $addr : 'Address not listed');
	$address2 = $parts[1] ?? '';
	$badge = !empty($marker['is_member']) ? 'MediCentral member' : 'Not on network';
	$loc = [
		'title' => (string) ($marker['name'] ?? 'Pharmacy') . ' · ' . $badge,
		'address1' => $address1,
		'address2' => $address2,
		'coords' => [
			'lat' => (float) ($marker['lat'] ?? 0),
			'lng' => (float) ($marker['lng'] ?? 0),
		],
	];
	$placeId = trim((string) ($marker['google_place_id'] ?? ''));
	if ($placeId !== '') {
		$loc['placeId'] = $placeId;
	}

	return $loc;
}

/**
 * @param array<int, array<string, mixed>> $markers
 * @return array{lat: float, lng: float, zoom: int}
 */
function mc_map_default_center(array $markers): array
{
	if ($markers === []) {
		return ['lat' => 9.032, 'lng' => 38.747, 'zoom' => 13];
	}
	$sumLat = 0.0;
	$sumLng = 0.0;
	foreach ($markers as $m) {
		$sumLat += (float) $m['lat'];
		$sumLng += (float) $m['lng'];
	}
	$n = count($markers);

	return [
		'lat' => $sumLat / $n,
		'lng' => $sumLng / $n,
		'zoom' => $n === 1 ? 15 : 13,
	];
}

/**
 * Google Locator Plus (gmpx-store-locator) configuration.
 *
 * @return array<string, mixed>
 */
function mc_map_build_locator_configuration(mysqli $conn, string $apiKey, string $mapId = ''): array
{
	$members = mc_map_load_member_pharmacies($conn);
	$others = mc_map_load_external_places($conn);
	$all = array_merge($members, $others);
	$center = mc_map_default_center($all);
	$catalog = [];
	foreach ($all as $marker) {
		$catalog[] = [
			'is_member' => !empty($marker['is_member']),
			'profile_url' => (string) ($marker['profile_url'] ?? ''),
			'order_url' => (string) ($marker['order_url'] ?? ''),
			'locator' => mc_map_marker_to_locator_location($marker),
		];
	}
	$locations = array_map(static fn (array $row): array => $row['locator'], $catalog);

	return [
		'configuration' => [
			'locations' => $locations,
			'mapOptions' => [
				'center' => ['lat' => $center['lat'], 'lng' => $center['lng']],
				'fullscreenControl' => true,
				'mapTypeControl' => false,
				'streetViewControl' => false,
				'zoom' => $center['zoom'],
				'zoomControl' => true,
				'maxZoom' => 17,
				'mapId' => $mapId,
			],
			'mapsApiKey' => $apiKey,
			'capabilities' => [
				'input' => true,
				'autocomplete' => true,
				'directions' => false,
				'distanceMatrix' => true,
				'details' => false,
				'actions' => false,
			],
		],
		'catalog' => $catalog,
		'member_count' => count($members),
		'other_count' => count($others),
	];
}
