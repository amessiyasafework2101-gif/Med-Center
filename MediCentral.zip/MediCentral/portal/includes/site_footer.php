<?php



declare(strict_types=1);



require_once __DIR__ . '/site_nav.php';



function mc_render_site_footer(string $assetPrefix = ''): void

{

	$prefix = $assetPrefix;

	echo '<footer class="mc-site-foot" role="contentinfo">';

	echo '<div class="mc-site-foot-inner">';

	echo '<span class="mc-foot-glow" aria-hidden="true"></span>';

	mc_render_site_nav_footer($prefix);

	echo '<p class="mc-foot-brand">MediCentral</p>';

	echo '<p class="mc-foot-line">Crafted with precision by <span class="mc-foot-binary">Binary Builders</span></p>';

	echo '<p class="mc-foot-sub">Centralized pharmacy network · members &amp; partners</p>';

	echo '</div></footer>';

}

