<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

$aid = (int) ($_SESSION['mc_admin_id'] ?? 0);
$flash = null;
$flashKind = 'success';

$fn = '';
$ln = '';
$em = '';

$stLoad = $conn->prepare(
	'SELECT first_name, last_name, email, username FROM mc_admins WHERE admin_id = ? LIMIT 1'
);
if ($stLoad) {
	$stLoad->bind_param('i', $aid);
	$stLoad->execute();
	$stLoad->bind_result($vf, $vl, $ve, $vuser);
	if ($stLoad->fetch()) {
		$fn = (string) ($vf ?? '');
		$ln = (string) ($vl ?? '');
		$em = (string) ($ve ?? '');
	}
	$stLoad->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action'])) {
	if ($_POST['mc_action'] === 'save_profile') {
		$f = trim((string) ($_POST['first_name'] ?? ''));
		$l = trim((string) ($_POST['last_name'] ?? ''));
		$mail = trim((string) ($_POST['email'] ?? ''));
		$mailNorm = $mail === '' ? null : $mail;
		if ($mailNorm !== null && !filter_var($mailNorm, FILTER_VALIDATE_EMAIL)) {
			$flashKind = 'error';
			$flash = 'Email format invalid.';
		} else {
			$upd = $conn->prepare('UPDATE mc_admins SET first_name=?, last_name=?, email=? WHERE admin_id=?');
			if ($upd) {
				$upd->bind_param(str_repeat('s', 3) . 'i', $f, $l, $mailNorm, $aid);
				if ($upd->execute()) {
					$flash = 'Profile saved.';
					$fn = $f;
					$ln = $l;
					$em = $mail;
				} else {
					$flashKind = 'error';
					if ($conn->errno === 1062) {
						$flash = 'That email is already tied to another account.';
					} else {
						$flash = 'Could not save profile.';
					}
				}
				$upd->close();
			}
		}
	} elseif ($_POST['mc_action'] === 'change_password') {
		$current = (string) ($_POST['current_password'] ?? '');
		$np = (string) ($_POST['new_password'] ?? '');
		$np2 = (string) ($_POST['new_password2'] ?? '');
		if (strlen($np) < 10) {
			$flashKind = 'error';
			$flash = 'New password must be at least 10 characters.';
		} elseif ($np !== $np2) {
			$flashKind = 'error';
			$flash = 'New password confirmations do not match.';
		} elseif ($current === '') {
			$flashKind = 'error';
			$flash = 'Enter your current password to authorize the change.';
		} else {
			$hSt = $conn->prepare('SELECT password_hash FROM mc_admins WHERE admin_id = ? LIMIT 1');
			$h = '';
			if ($hSt) {
				$hSt->bind_param('i', $aid);
				$hSt->execute();
				$hSt->bind_result($h);
				$exists = $hSt->fetch();
				$hSt->close();
				if (!$exists || !password_verify($current, $h)) {
					$flashKind = 'error';
					$flash = 'Current password is incorrect.';
				} else {
					$newHash = password_hash($np, PASSWORD_DEFAULT);
					$pu = $conn->prepare('UPDATE mc_admins SET password_hash = ? WHERE admin_id = ?');
					if ($pu) {
						$pu->bind_param('si', $newHash, $aid);
						if ($pu->execute()) {
							$flash = 'Password updated.';
						} else {
							$flashKind = 'error';
							$flash = 'Could not change password.';
						}
						$pu->close();
					}
				}
			}
		}
	}
}

mc_admin_shell_start('Account settings', 'settings');
if ($flash) {
	mc_admin_flash((string) $flash, $flashKind);
}
?>
<div class="adm-grid cols-2">
	<div class="adm-card">
		<h2>Administrator profile</h2>
		<form method="post" action="" class="adm-form-grid two">
			<input type="hidden" name="mc_action" value="save_profile">
			<div class="adm-field"><label for="pf_fn">First name</label><input id="pf_fn" name="first_name" maxlength="80" value="<?php echo htmlspecialchars($fn, ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field"><label for="pf_ln">Last name</label><input id="pf_ln" name="last_name" maxlength="80" value="<?php echo htmlspecialchars($ln, ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field" style="grid-column:1/-1;"><label for="pf_em">Email</label><input id="pf_em" name="email" type="email" maxlength="120" value="<?php echo htmlspecialchars($em, ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-actions" style="grid-column:1/-1;"><button type="submit" class="adm-btn">Save profile</button></div>
		</form>
	</div>
	<div class="adm-card">
		<h2>Change password</h2>
		<form method="post" action="" class="adm-form-grid">
			<input type="hidden" name="mc_action" value="change_password">
			<div class="adm-field"><label for="cp_cur">Current password</label><input id="cp_cur" name="current_password" type="password" required autocomplete="current-password"></div>
			<div class="adm-field"><label for="cp_pw">New password</label><input id="cp_pw" name="new_password" type="password" minlength="10" required autocomplete="new-password"></div>
			<div class="adm-field"><label for="cp_pw2">Confirm new password</label><input id="cp_pw2" name="new_password2" type="password" minlength="10" required autocomplete="new-password"></div>
			<div class="adm-actions"><button type="submit" class="adm-btn">Update password</button></div>
		</form>
	</div>
</div>
<?php mc_admin_shell_end(); ?>
