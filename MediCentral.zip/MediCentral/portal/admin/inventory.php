<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';
require_once dirname(__DIR__) . '/includes/inventory_ops.php';

mc_upgrade_inventory_unit_schema($conn);

function mc_inventory_barcode_available(mysqli $conn, ?string $barcode, int $exceptDrugId): bool
{
	if ($barcode === null || $barcode === '') {
		return true;
	}
	if ($exceptDrugId > 0) {
		$stmt = $conn->prepare('SELECT 1 FROM mc_drugs WHERE barcode = ? AND drug_id <> ? LIMIT 1');
		if (!$stmt) {
			return false;
		}
		$stmt->bind_param('si', $barcode, $exceptDrugId);
	} else {
		$stmt = $conn->prepare('SELECT 1 FROM mc_drugs WHERE barcode = ? LIMIT 1');
		if (!$stmt) {
			return false;
		}
		$stmt->bind_param('s', $barcode);
	}
	if (!$stmt->execute()) {
		$stmt->close();

		return false;
	}
	$stmt->store_result();
	$ok = $stmt->num_rows === 0;
	$stmt->close();

	return $ok;
}

function mc_inventory_qr_available(mysqli $conn, ?string $qr, int $exceptDrugId): bool
{
	if ($qr === null || $qr === '') {
		return true;
	}
	if ($exceptDrugId > 0) {
		$stmt = $conn->prepare('SELECT 1 FROM mc_drugs WHERE qr_code = ? AND drug_id <> ? LIMIT 1');
		if (!$stmt) {
			return false;
		}
		$stmt->bind_param('si', $qr, $exceptDrugId);
	} else {
		$stmt = $conn->prepare('SELECT 1 FROM mc_drugs WHERE qr_code = ? LIMIT 1');
		if (!$stmt) {
			return false;
		}
		$stmt->bind_param('s', $qr);
	}
	if (!$stmt->execute()) {
		$stmt->close();

		return false;
	}
	$stmt->store_result();
	$ok = $stmt->num_rows === 0;
	$stmt->close();

	return $ok;
}

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action'])) {
	$action = (string) $_POST['mc_action'];

	if ($action === 'receive_stock') {
		$code = trim((string) ($_POST['scan_code'] ?? ''));
		$qtyAdd = (int) ($_POST['receive_qty'] ?? 0);
		$res = mc_inventory_receive_by_scan($conn, $code, $qtyAdd);
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
	} elseif ($action === 'add_drug') {
		$name = trim((string) ($_POST['name'] ?? ''));
		$category = trim((string) ($_POST['category'] ?? '')) ?: 'Uncategorized';
		$unitType = mc_inventory_normalize_unit_type((string) ($_POST['unit_type'] ?? 'unit'));
		$barcode = trim((string) ($_POST['barcode'] ?? ''));
		$qr = trim((string) ($_POST['qr_code'] ?? ''));
		$qty = (int) ($_POST['quantity'] ?? 0);
		$price = (float) ($_POST['unit_price'] ?? 0);
		$reorder = (int) ($_POST['reorder_level'] ?? 10);
		$expRaw = trim((string) ($_POST['expiry_date'] ?? ''));
		$expiry = preg_match('/^\d{4}-\d{2}-\d{2}$/', $expRaw) ? $expRaw : null;

		$barcode = $barcode === '' ? null : $barcode;
		$qr = $qr === '' ? null : $qr;
		if ($reorder < 0) {
			$reorder = 0;
		}

		if ($name === '' || $qty < 0 || $price < 0) {
			$flashKind = 'error';
			$flash = 'Name, non-negative quantity, and non-negative price are required.';
		} elseif (!mc_inventory_barcode_available($conn, $barcode, 0)) {
			$flashKind = 'error';
			$flash = 'That barcode is already used for another product.';
		} elseif (!mc_inventory_qr_available($conn, $qr, 0)) {
			$flashKind = 'error';
			$flash = 'That QR payload is already used for another product.';
		} else {
			$stmt = $conn->prepare(
				'INSERT INTO mc_drugs (name, barcode, qr_code, category, unit_type, quantity, unit_price, reorder_level, expiry_date) VALUES (?,?,?,?,?,?,?,?,?)'
			);
			if ($stmt) {
				$stmt->bind_param('sssssidis', $name, $barcode, $qr, $category, $unitType, $qty, $price, $reorder, $expiry);
				if ($stmt->execute()) {
					$newId = (int) $conn->insert_id;
					if ($newId > 0 && $qty > 0 && mc_table_has_column($conn, 'mc_pharmacy_inventory', 'inventory_id')) {
						$phRes = $conn->query('SELECT pharmacy_id FROM mc_pharmacies WHERE is_active = 1');
						if ($phRes) {
							while ($ph = $phRes->fetch_assoc()) {
								mc_inventory_mirror_pharmacy_delta($conn, $newId, $qty, (int) $ph['pharmacy_id']);
							}
						}
					}
					$flash = 'Drug added to inventory.';
				} else {
					$flashKind = 'error';
					if ($conn->errno === 1062) {
						$flash = 'That barcode or QR payload is already linked to another product.';
					} else {
						$flash = 'Could not save drug: ' . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8');
					}
				}
				$stmt->close();
			}
		}
	} elseif ($action === 'update_drug') {
		$id = (int) ($_POST['drug_id'] ?? 0);
		$name = trim((string) ($_POST['name'] ?? ''));
		$category = trim((string) ($_POST['category'] ?? '')) ?: 'Uncategorized';
		$unitType = mc_inventory_normalize_unit_type((string) ($_POST['unit_type'] ?? 'unit'));
		$barcode = trim((string) ($_POST['barcode'] ?? ''));
		$qr = trim((string) ($_POST['qr_code'] ?? ''));
		$qty = (int) ($_POST['quantity'] ?? 0);
		$price = (float) ($_POST['unit_price'] ?? 0);
		$reorder = (int) ($_POST['reorder_level'] ?? 10);
		$expRaw = trim((string) ($_POST['expiry_date'] ?? ''));
		$expiry = preg_match('/^\d{4}-\d{2}-\d{2}$/', $expRaw) ? $expRaw : null;

		$barcode = $barcode === '' ? null : $barcode;
		$qr = $qr === '' ? null : $qr;
		if ($reorder < 0) {
			$reorder = 0;
		}

		if ($id <= 0 || $name === '' || $qty < 0 || $price < 0) {
			$flashKind = 'error';
			$flash = 'Invalid product update.';
		} elseif (!mc_inventory_barcode_available($conn, $barcode, $id)) {
			$flashKind = 'error';
			$flash = 'That barcode belongs to another product.';
		} elseif (!mc_inventory_qr_available($conn, $qr, $id)) {
			$flashKind = 'error';
			$flash = 'That QR payload belongs to another product.';
		} else {
			$stmt = $conn->prepare(
				'UPDATE mc_drugs SET name=?, barcode=?, qr_code=?, category=?, unit_type=?, quantity=?, unit_price=?, reorder_level=?, expiry_date=? WHERE drug_id=?'
			);
			if ($stmt) {
				$stmt->bind_param('sssssidisi', $name, $barcode, $qr, $category, $unitType, $qty, $price, $reorder, $expiry, $id);
				if ($stmt->execute()) {
					$flash = 'Inventory record updated.';
				} else {
					$flashKind = 'error';
					if ($conn->errno === 1062) {
						$flash = 'Duplicate barcode or QR code.';
					} else {
						$flash = 'Update failed: ' . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8');
					}
				}
				$stmt->close();
			}
		}
	} elseif ($action === 'delete_drug') {
		$id = (int) ($_POST['drug_id'] ?? 0);
		if ($id <= 0) {
			$flashKind = 'error';
			$flash = 'Invalid product.';
		} else {
			$stmt = $conn->prepare('DELETE FROM mc_drugs WHERE drug_id=?');
			if ($stmt) {
				$stmt->bind_param('i', $id);
				if ($stmt->execute() && $stmt->affected_rows > 0) {
					header('Location: inventory.php');
					exit;
				} else {
					$flashKind = 'error';
					if ($conn->errno === 1451) {
						$flash = 'Cannot delete: this SKU appears on past sales.';
					} else {
						$flash = 'Could not delete product.';
					}
				}
				$stmt->close();
			}
		}
	}
}

$editId = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$editRow = null;
if ($editId > 0) {
	$st = $conn->prepare(
		'SELECT drug_id, name, barcode, qr_code, category, unit_type, quantity, unit_price, reorder_level, expiry_date FROM mc_drugs WHERE drug_id = ? LIMIT 1'
	);
	if ($st) {
		$st->bind_param('i', $editId);
		$st->execute();
		$st->bind_result($did, $dname, $dbc, $dqr, $dcat, $dunit, $dqty, $dprice, $dreorder, $dexp);
		if ($st->fetch()) {
			$editRow = [
				'drug_id' => $did,
				'name' => $dname,
				'barcode' => $dbc,
				'qr_code' => $dqr,
				'category' => $dcat,
				'unit_type' => $dunit,
				'quantity' => $dqty,
				'unit_price' => $dprice,
				'reorder_level' => $dreorder,
				'expiry_date' => $dexp,
			];
		}
		$st->close();
	}
}

$res = $conn->query(
	'SELECT drug_id, name, barcode, qr_code, category, unit_type, quantity, unit_price, reorder_level, expiry_date, created_at FROM mc_drugs ORDER BY name ASC'
);
$drugs = [];
if ($res) {
	while ($r = $res->fetch_assoc()) {
		$drugs[] = $r;
	}
}

mc_admin_shell_start('Drugs & barcodes', 'inventory');
if ($flash) {
	mc_admin_flash((string) $flash, $flashKind);
}
?>
<div class="adm-split">
	<div>
		<div class="adm-card adm-inv-receive" style="margin-bottom:1rem;">
			<h2>Receive stock by scan</h2>
			<p class="adm-muted">Scan a barcode or QR on the package, enter how many <strong>units</strong> (e.g. tablets) you are adding, then receive into inventory. New products must be registered below first.</p>
			<form method="post" action="" id="receiveForm" class="adm-form-grid two">
				<input type="hidden" name="mc_action" value="receive_stock">
				<input type="hidden" name="scan_code" id="receive_code" value="">
				<div class="adm-field" style="grid-column:1/-1;">
					<label>Scanned code</label>
					<input type="text" id="receive_code_display" readonly placeholder="Scan below or type code then lookup">
				</div>
				<div class="adm-field">
					<label for="receive_qty">Quantity to add</label>
					<input type="number" id="receive_qty" name="receive_qty" min="1" value="1" required>
					<span class="adm-muted" id="receive_unit_hint">units</span>
				</div>
				<div class="adm-field adm-actions" style="align-self:end;">
					<button type="button" class="adm-btn secondary" id="btnLookupCode">Lookup product</button>
					<button type="submit" class="adm-btn" id="btnReceiveStock" disabled>Receive into stock</button>
				</div>
			</form>
			<div id="receiveLookupResult" class="adm-inv-lookup-result" hidden></div>
		</div>

		<div class="adm-card" style="margin-bottom:1rem;">
			<h2><?php echo $editRow ? 'Edit product' : 'Add product'; ?></h2>
			<p class="adm-muted">Use the camera to read a <strong>barcode</strong> or <strong>QR code</strong> on the pack, or type the code manually. Choose the <strong>unit type</strong> (tablet, bottle, etc.) so cashiers know how to count stock.</p>
			<div class="adm-scan">
				<div class="adm-actions" style="margin-bottom:0.75rem;">
					<button type="button" class="adm-btn" id="btnScanStart">Start camera</button>
					<button type="button" class="adm-btn secondary" id="btnScanStop">Stop</button>
				</div>
				<div id="inventory-reader"></div>
				<p class="adm-muted" id="scanStatus" style="margin-top:0.5rem;">Camera requires HTTPS on most browsers (localhost is allowed).</p>
			</div>

			<?php if ($editRow): ?>
			<form method="post" action="" id="drugForm" class="adm-form-grid two" style="margin-top:1rem;">
				<input type="hidden" name="mc_action" value="update_drug">
				<input type="hidden" name="drug_id" value="<?php echo (int) $editRow['drug_id']; ?>">
				<div class="adm-field" style="grid-column:1/-1;"><label for="f_name">Product name</label><input id="f_name" name="name" required maxlength="200" value="<?php echo htmlspecialchars((string) $editRow['name'], ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field"><label for="f_cat">Category</label><input id="f_cat" name="category" maxlength="80" value="<?php echo htmlspecialchars((string) ($editRow['category'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field"><label for="f_unit">Unit type</label>
					<select id="f_unit" name="unit_type">
						<?php foreach (MC_INVENTORY_UNIT_TYPES as $ut): ?>
							<option value="<?php echo $ut; ?>"<?php echo ($editRow['unit_type'] ?? 'unit') === $ut ? ' selected' : ''; ?>><?php echo ucfirst($ut); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="adm-field"><label for="f_qty">Quantity in stock (<span class="f-qty-unit-lbl"><?php echo htmlspecialchars(mc_inventory_unit_label((string) ($editRow['unit_type'] ?? 'unit')), ENT_QUOTES, 'UTF-8'); ?></span>)</label><input id="f_qty" name="quantity" type="number" min="0" required value="<?php echo (int) $editRow['quantity']; ?>"></div>
				<div class="adm-field"><label for="f_price">Unit price (per unit)</label><input id="f_price" name="unit_price" type="number" min="0" step="0.01" required value="<?php echo htmlspecialchars((string) $editRow['unit_price'], ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field"><label for="f_reorder">Reorder level · alert below this</label><input id="f_reorder" name="reorder_level" type="number" min="0" value="<?php echo (int) ($editRow['reorder_level'] ?? 10); ?>"></div>
				<div class="adm-field"><label for="f_exp">Expiry date · optional</label><input id="f_exp" name="expiry_date" type="date" value="<?php echo htmlspecialchars((string) ($editRow['expiry_date'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field"><label for="f_bc">Barcode</label><input id="f_bc" name="barcode" maxlength="64" value="<?php echo htmlspecialchars((string) ($editRow['barcode'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" placeholder="Scanned or typed"></div>
				<div class="adm-field"><label for="f_qr">QR payload</label><input id="f_qr" name="qr_code" maxlength="512" value="<?php echo htmlspecialchars((string) ($editRow['qr_code'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-actions" style="grid-column:1/-1;">
					<button type="submit" class="adm-btn">Save changes</button>
					<a class="adm-btn secondary" href="inventory.php">Cancel edit</a>
				</div>
			</form>
			<form method="post" action="" style="margin-top:1rem;" onsubmit="return confirm('Remove this SKU from inventory? Past sales rows are retained when delete is blocked.');">
				<input type="hidden" name="mc_action" value="delete_drug">
				<input type="hidden" name="drug_id" value="<?php echo (int) $editRow['drug_id']; ?>">
				<button type="submit" class="adm-btn danger">Delete product</button>
			</form>
			<?php else: ?>
			<form method="post" action="" id="drugForm" class="adm-form-grid two" style="margin-top:1rem;">
				<input type="hidden" name="mc_action" value="add_drug">
				<div class="adm-field" style="grid-column:1/-1;"><label for="f_name">Product name</label><input id="f_name" name="name" required maxlength="200"></div>
				<div class="adm-field"><label for="f_cat">Category</label><input id="f_cat" name="category" maxlength="80" placeholder="e.g. Pain relief"></div>
				<div class="adm-field"><label for="f_unit">Unit type</label>
					<select id="f_unit" name="unit_type">
						<?php foreach (MC_INVENTORY_UNIT_TYPES as $ut): ?>
							<option value="<?php echo $ut; ?>"><?php echo ucfirst($ut); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="adm-field"><label for="f_qty">Quantity in stock (<span class="f-qty-unit-lbl">units</span>)</label><input id="f_qty" name="quantity" type="number" min="0" value="0" required></div>
				<div class="adm-field"><label for="f_price">Unit price (per unit)</label><input id="f_price" name="unit_price" type="number" min="0" step="0.01" value="0" required></div>
				<div class="adm-field"><label for="f_reorder">Reorder level</label><input id="f_reorder" name="reorder_level" type="number" min="0" value="10"></div>
				<div class="adm-field"><label for="f_exp">Expiry date · optional</label><input id="f_exp" name="expiry_date" type="date"></div>
				<div class="adm-field"><label for="f_bc">Barcode</label><input id="f_bc" name="barcode" maxlength="64" placeholder="Scanned or typed"></div>
				<div class="adm-field"><label for="f_qr">QR payload</label><input id="f_qr" name="qr_code" maxlength="512" placeholder="Decoded QR string / URL"></div>
				<div class="adm-actions" style="grid-column:1/-1;">
					<button type="submit" class="adm-btn">Save to inventory</button>
				</div>
			</form>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="adm-card">
	<h2>Current stock</h2>
	<p class="adm-muted">Rows at or below reorder level are highlighted. Expired items use a danger tint.</p>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead>
				<tr><th>Name</th><th>Category</th><th>Unit</th><th>Barcode</th><th>Qty</th><th>Reorder</th><th>Expiry</th><th>Price</th><th></th></tr>
			</thead>
			<tbody>
			<?php if (!$drugs): ?>
				<tr><td colspan="9" class="adm-muted">No drugs yet.</td></tr>
			<?php else: ?>
				<?php
				$today = new DateTimeImmutable('today');
				foreach ($drugs as $d):
					$qty = (int) $d['quantity'];
					$re = (int) ($d['reorder_level'] ?? 10);
					$exp = $d['expiry_date'] ?? null;
					$rowClass = '';
					if ($exp) {
						try {
							$ed = new DateTimeImmutable((string) $exp);
							if ($ed < $today) {
								$rowClass = ' adm-row-danger';
							} elseif ($ed <= $today->modify('+90 days')) {
								$rowClass = ' adm-row-warn';
							}
						} catch (Throwable $e) {
						}
					}
					if ($qty <= $re) {
						$rowClass .= ' adm-row-low';
					}
					?>
					<tr class="<?php echo trim($rowClass); ?>">
						<td><?php echo htmlspecialchars((string) $d['name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) ($d['category'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars(ucfirst((string) ($d['unit_type'] ?? 'unit')), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) ($d['barcode'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo $qty . ' ' . htmlspecialchars(mc_inventory_unit_label((string) ($d['unit_type'] ?? 'unit')), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo $re; ?></td>
						<td><?php echo $exp ? htmlspecialchars((string) $exp, ENT_QUOTES, 'UTF-8') : '—'; ?></td>
						<td><?php echo number_format((float) $d['unit_price'], 2); ?></td>
						<td><a class="adm-out" href="inventory.php?edit=<?php echo (int) $d['drug_id']; ?>">Edit</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>

<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script src="../js/admin-inventory-scan.js"></script>
<?php mc_admin_shell_end(); ?>
