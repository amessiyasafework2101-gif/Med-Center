<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

function mc_supplier_has_purchases(mysqli $conn, int $supplierId): bool
{
	if ($supplierId <= 0) {
		return true;
	}
	$st = $conn->prepare('SELECT 1 FROM mc_purchases WHERE supplier_id = ? LIMIT 1');
	if (!$st) {
		return true;
	}
	$st->bind_param('i', $supplierId);
	$st->execute();
	$st->store_result();
	$has = $st->num_rows > 0;
	$st->close();

	return $has;
}

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action'])) {
	$act = (string) $_POST['mc_action'];
	if ($act === 'add_supplier') {
		$name = trim((string) ($_POST['company_name'] ?? ''));
		$addr = trim((string) ($_POST['address'] ?? ''));
		$phone = trim((string) ($_POST['phone'] ?? ''));
		$mail = trim((string) ($_POST['email'] ?? ''));
		$mailN = $mail === '' ? null : $mail;
		if ($name === '') {
			$flashKind = 'error';
			$flash = 'Supplier name is required.';
		} elseif ($mailN !== null && !filter_var($mailN, FILTER_VALIDATE_EMAIL)) {
			$flashKind = 'error';
			$flash = 'Invalid email.';
		} else {
			$a = $addr === '' ? null : $addr;
			$p = $phone === '' ? null : $phone;
			$st = $conn->prepare('INSERT INTO mc_suppliers (company_name, address, phone, email) VALUES (?,?,?,?)');
			if ($st && $st->bind_param(str_repeat('s', 4), $name, $a, $p, $mailN) && $st->execute()) {
				$flash = 'Supplier added.';
			} else {
				$flashKind = 'error';
				$flash = $conn->errno === 1062 ? 'Duplicate email.' : 'Could not save supplier.';
			}
			if ($st) {
				$st->close();
			}
		}
	} elseif ($act === 'update_supplier') {
		$id = (int) ($_POST['supplier_id'] ?? 0);
		$name = trim((string) ($_POST['company_name'] ?? ''));
		$addr = trim((string) ($_POST['address'] ?? ''));
		$phone = trim((string) ($_POST['phone'] ?? ''));
		$mail = trim((string) ($_POST['email'] ?? ''));
		$mailN = $mail === '' ? null : $mail;
		if ($id <= 0 || $name === '') {
			$flashKind = 'error';
			$flash = 'Invalid supplier update.';
		} elseif ($mailN !== null && !filter_var($mailN, FILTER_VALIDATE_EMAIL)) {
			$flashKind = 'error';
			$flash = 'Invalid email.';
		} else {
			$a = $addr === '' ? null : $addr;
			$p = $phone === '' ? null : $phone;
			$st = $conn->prepare('UPDATE mc_suppliers SET company_name=?, address=?, phone=?, email=? WHERE supplier_id=?');
			if ($st && $st->bind_param(str_repeat('s', 4) . 'i', $name, $a, $p, $mailN, $id) && $st->execute()) {
				$flash = 'Supplier updated.';
			} else {
				$flashKind = 'error';
				$flash = 'Could not update supplier.';
			}
			if ($st) {
				$st->close();
			}
		}
	} elseif ($act === 'delete_supplier') {
		$id = (int) ($_POST['supplier_id'] ?? 0);
		if ($id <= 0) {
			$flashKind = 'error';
			$flash = 'Invalid supplier.';
		} elseif (mc_supplier_has_purchases($conn, $id)) {
			$flashKind = 'error';
			$flash = 'Supplier has purchases on file — deactivate by editing instead.';
		} else {
			$d = $conn->prepare('DELETE FROM mc_suppliers WHERE supplier_id = ? LIMIT 1');
			if ($d && $d->bind_param('i', $id) && $d->execute() && $d->affected_rows > 0) {
				$flash = 'Supplier removed.';
			} else {
				$flashKind = 'error';
				$flash = 'Could not delete supplier.';
			}
			if ($d) {
				$d->close();
			}
		}
	}
}

$editId = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$editRow = null;
if ($editId > 0) {
	$st = $conn->prepare('SELECT supplier_id, company_name, address, phone, email FROM mc_suppliers WHERE supplier_id = ? LIMIT 1');
	if ($st) {
		$st->bind_param('i', $editId);
		$st->execute();
		$st->bind_result($sid0, $sname, $saddr, $sph, $sem);
		if ($st->fetch()) {
			$editRow = [
				'supplier_id' => $sid0,
				'company_name' => $sname,
				'address' => $saddr,
				'phone' => $sph,
				'email' => $sem,
			];
		}
		$st->close();
	}
}

$listRes = $conn->query(
	'SELECT supplier_id, company_name, phone, email, created_at FROM mc_suppliers ORDER BY company_name ASC'
);
$list = [];
if ($listRes) {
	while ($r = $listRes->fetch_assoc()) {
		$list[] = $r;
	}
}

mc_admin_shell_start('Suppliers', 'suppliers');
if ($flash) {
	mc_admin_flash((string) $flash, $flashKind);
}
?>
<p class="adm-muted" style="margin-top:-0.35rem;margin-bottom:1rem;">Comparable to legacy <strong>PHARMACIA</strong> supplier pages — wholesalers you buy stock from.</p>
<div class="adm-grid cols-2" style="margin-bottom:1rem;">
	<div class="adm-card">
		<h2><?php echo $editRow ? 'Edit supplier' : 'Add supplier'; ?></h2>
		<form method="post" class="adm-form-grid two">
			<input type="hidden" name="mc_action" value="<?php echo $editRow ? 'update_supplier' : 'add_supplier'; ?>">
			<?php if ($editRow): ?>
				<input type="hidden" name="supplier_id" value="<?php echo (int) $editRow['supplier_id']; ?>">
			<?php endif; ?>
			<div class="adm-field" style="grid-column:1/-1;"><label for="co">Company name</label><input id="co" name="company_name" required maxlength="160" value="<?php echo htmlspecialchars((string) ($editRow['company_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field"><label for="ph">Phone</label><input id="ph" name="phone" maxlength="40" value="<?php echo htmlspecialchars((string) ($editRow['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field"><label for="em">Email</label><input id="em" name="email" type="email" maxlength="120" value="<?php echo htmlspecialchars((string) ($editRow['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field" style="grid-column:1/-1;"><label for="ad">Address</label><input id="ad" name="address" maxlength="255" value="<?php echo htmlspecialchars((string) ($editRow['address'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-actions" style="grid-column:1/-1;">
				<button type="submit" class="adm-btn"><?php echo $editRow ? 'Save supplier' : 'Create supplier'; ?></button>
				<?php if ($editRow): ?><a class="adm-btn secondary" href="suppliers.php">Cancel</a><?php endif; ?>
			</div>
		</form>
	</div>
	<div class="adm-card">
		<h2>List</h2>
		<div class="adm-table-wrap">
			<table class="adm-table">
				<thead><tr><th>Company</th><th>Phone</th><th>Email</th><th></th></tr></thead>
				<tbody>
				<?php if (!$list): ?>
					<tr><td colspan="4" class="adm-muted">No suppliers yet.</td></tr>
				<?php else: ?>
					<?php foreach ($list as $r): ?>
						<tr>
							<td><?php echo htmlspecialchars((string) $r['company_name'], ENT_QUOTES, 'UTF-8'); ?></td>
							<td><?php echo htmlspecialchars((string) ($r['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
							<td><?php echo htmlspecialchars((string) ($r['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
							<td>
								<a class="adm-out" href="suppliers.php?edit=<?php echo (int) $r['supplier_id']; ?>">Edit</a>
								<?php if (!mc_supplier_has_purchases($conn, (int) $r['supplier_id'])): ?>
									<form method="post" style="display:inline;margin-left:.5rem;" onsubmit="return confirm('Remove this supplier?');">
										<input type="hidden" name="mc_action" value="delete_supplier">
										<input type="hidden" name="supplier_id" value="<?php echo (int) $r['supplier_id']; ?>">
										<button type="submit" class="adm-btn danger" style="padding:.35rem .6rem;font-size:.8rem;">Del</button>
									</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php mc_admin_shell_end(); ?>
