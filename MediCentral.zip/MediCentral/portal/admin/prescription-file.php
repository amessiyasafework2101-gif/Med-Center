<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/member_order_payment.php';

mc_upgrade_member_order_payment_schema($conn);

$orderId = (int) ($_GET['order_id'] ?? 0);
if ($orderId <= 0) {
	http_response_code(400);
	exit('Invalid order.');
}

$st = $conn->prepare('SELECT prescription_path FROM mc_member_orders WHERE order_id = ? LIMIT 1');
if (!$st) {
	http_response_code(500);
	exit('Error.');
}
$st->bind_param('i', $orderId);
$st->execute();
$res = $st->get_result();
$row = $res ? $res->fetch_assoc() : null;
$st->close();

$rel = trim((string) ($row['prescription_path'] ?? ''));
if ($rel === '' || str_contains($rel, '..')) {
	http_response_code(404);
	exit('No prescription on file.');
}

$base = realpath(dirname(__DIR__));
$full = realpath(dirname(__DIR__) . '/' . $rel);
$uploadsRoot = realpath(mc_prescription_upload_dir());
if ($base === false || $full === false || $uploadsRoot === false || !str_starts_with($full, $uploadsRoot)) {
	http_response_code(403);
	exit('Access denied.');
}

if (!is_readable($full)) {
	http_response_code(404);
	exit('File not found.');
}

$ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
$types = [
	'jpg' => 'image/jpeg',
	'jpeg' => 'image/jpeg',
	'png' => 'image/png',
	'webp' => 'image/webp',
	'pdf' => 'application/pdf',
];
$mime = $types[$ext] ?? 'application/octet-stream';

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string) filesize($full));
header('Content-Disposition: inline; filename="prescription-' . $orderId . '.' . $ext . '"');
readfile($full);
exit;
