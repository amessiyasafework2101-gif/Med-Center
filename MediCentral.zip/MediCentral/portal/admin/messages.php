<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';
require_once dirname(__DIR__) . '/includes/admin_chat.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';
require_once dirname(__DIR__) . '/includes/pharmacist_ratings.php';
require_once dirname(__DIR__) . '/includes/chat_ui.php';

$adminId = (int) ($_SESSION['mc_admin_id'] ?? 0);
$flash = '';
$flashKind = 'success';
$selectedPh = isset($_GET['pharmacist_id']) ? (int) $_GET['pharmacist_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['request_chat'])) {
		$target = (int) ($_POST['pharmacist_id'] ?? 0);
		$res = mc_admin_chat_request($conn, $adminId, $target);
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
		$selectedPh = $target;
	} elseif (isset($_POST['send_message'])) {
		$target = (int) ($_POST['pharmacist_id'] ?? 0);
		$body = trim((string) ($_POST['body'] ?? ''));
		if ($target > 0 && $body !== '') {
			if (!mc_admin_chat_can_message($conn, $adminId, $target)) {
				$flash = 'Send a chat request and wait for the pharmacist to approve before messaging.';
				$flashKind = 'error';
			} else {
				mc_pharmacist_post_message($conn, $target, 'admin', 'admin', $body, null, $adminId, null);
				$flash = 'Message sent.';
				$selectedPh = $target;
			}
		}
	} elseif (isset($_POST['rate_pharmacist'])) {
		$target = (int) ($_POST['pharmacist_id'] ?? 0);
		$score = (int) ($_POST['score'] ?? 0);
		$comment = trim((string) ($_POST['comment'] ?? ''));
		$res = mc_pharmacist_save_rating($conn, $target, 'admin', $score, $comment, null, $adminId);
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
		$selectedPh = $target;
	}
}

$pharmacists = mc_admin_chat_list_pharmacists($conn, $adminId);
$messages = [];
$selectedRow = null;
$myRating = null;
if ($selectedPh > 0) {
	foreach ($pharmacists as $p) {
		if ((int) $p['pharmacist_id'] === $selectedPh) {
			$selectedRow = $p;
			break;
		}
	}
	$myRating = mc_pharmacist_get_admin_rating($conn, $selectedPh, $adminId);
	if ($selectedRow && mc_admin_chat_can_message($conn, $adminId, $selectedPh)) {
		$messages = mc_pharmacist_messages($conn, $selectedPh, 'admin');
	}
}

mc_admin_shell_start('Messages & chat', 'messages');
echo '<link rel="stylesheet" href="../css/mc-chat.css">';
if ($flash) {
	mc_admin_flash($flash, $flashKind);
}
?>
<p class="adm-muted">Pharmacists are sorted by <strong>performance score</strong> (from member and admin ratings). Request chat, then message after they approve.</p>

<div class="adm-msg-layout">
	<section class="adm-card adm-msg-list">
		<h2>Pharmacists on MediCentral</h2>
		<?php if (!$pharmacists): ?>
			<p class="adm-muted">No approved pharmacists listed yet.</p>
		<?php else: ?>
			<ul class="adm-ph-list">
				<?php foreach ($pharmacists as $p):
					$pid = (int) $p['pharmacist_id'];
					$st = (string) ($p['chat_status'] ?? '');
					$isSel = $pid === $selectedPh;
					?>
					<li class="adm-ph-item<?php echo $isSel ? ' is-selected' : ''; ?>">
						<a href="messages.php?pharmacist_id=<?php echo $pid; ?>" class="adm-ph-link">
							<strong><?php echo htmlspecialchars(trim($p['first_name'] . ' ' . ($p['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></strong>
							<span class="adm-ph-meta">@<?php echo htmlspecialchars((string) $p['username'], ENT_QUOTES, 'UTF-8'); ?></span>
							<?php echo mc_pharmacist_render_stars((float) $p['performance_score'], true, (int) $p['rating_count']); ?>
							<?php if ($st === 'pending'): ?>
								<span class="adm-tag">Request pending</span>
							<?php elseif ($st === 'approved'): ?>
								<span class="adm-tag ok">Connected</span>
							<?php elseif ($st === 'declined'): ?>
								<span class="adm-tag">Declined</span>
							<?php else: ?>
								<span class="adm-tag">Not connected</span>
							<?php endif; ?>
						</a>
						<?php if ($st !== 'approved'): ?>
							<form method="post" class="adm-inline-form">
								<input type="hidden" name="request_chat" value="1">
								<input type="hidden" name="pharmacist_id" value="<?php echo $pid; ?>">
								<button type="submit" class="adm-btn secondary"><?php echo $st === 'pending' ? 'Resend request' : 'Request chat'; ?></button>
							</form>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>

	<section class="adm-card adm-msg-chat">
		<?php if ($selectedPh <= 0 || !$selectedRow): ?>
			<h2>Chat & rating</h2>
			<p class="adm-muted">Select a pharmacist to rate them, request chat, or send messages.</p>
		<?php else: ?>
			<h2><?php echo htmlspecialchars(trim($selectedRow['first_name'] . ' ' . ($selectedRow['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></h2>
			<?php echo mc_pharmacist_render_stars((float) $selectedRow['performance_score'], true, (int) $selectedRow['rating_count']); ?>

			<form method="post" style="margin:1rem 0;">
				<input type="hidden" name="rate_pharmacist" value="1">
				<input type="hidden" name="pharmacist_id" value="<?php echo $selectedPh; ?>">
				<?php mc_rating_render_picker('score', $myRating ? (int) $myRating['score'] : 0, $myRating ? 'Update performance rating' : 'Rate for invitations'); ?>
				<input type="text" name="comment" class="mc-rate-comment" maxlength="500" placeholder="Optional note for your records" value="<?php echo htmlspecialchars($myRating['comment'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
				<button type="submit" class="adm-btn secondary">Save rating</button>
			</form>

			<?php if (!mc_admin_chat_can_message($conn, $adminId, $selectedPh)): ?>
				<p class="adm-muted">Waiting for this pharmacist to approve your chat request.</p>
				<form method="post">
					<input type="hidden" name="request_chat" value="1">
					<input type="hidden" name="pharmacist_id" value="<?php echo $selectedPh; ?>">
					<button type="submit" class="adm-btn">Send chat request</button>
				</form>
			<?php else: ?>
				<h3 style="margin-top:1rem;font-size:1rem;">Admin chat</h3>
				<?php mc_chat_render_bubbles($messages, 'admin'); ?>
				<?php mc_chat_render_composer('Type your message…', ['send_message' => '1', 'pharmacist_id' => (string) $selectedPh]); ?>
			<?php endif; ?>
		<?php endif; ?>
	</section>
</div>
<script src="../js/mc-star-rating.js" defer></script>
<?php mc_admin_shell_end(); ?>
