<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';
require_once dirname(__DIR__) . '/includes/inventory_ops.php';

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST'
	&& isset($_POST['mc_action'])
	&& (string) $_POST['mc_action'] === 'record_purchase') {
	$supId = (int) ($_POST['supplier_id'] ?? 0);
	$pdate = trim((string) ($_POST['purchased_on'] ?? ''));
	$pnote = trim((string) ($_POST['purchase_note'] ?? ''));
	$noteDb = $pnote === '' ? null : $pnote;

	$dids = $_POST['line_drug_id'] ?? [];
	$qtys = $_POST['line_qty'] ?? [];
	$costs = $_POST['line_cost'] ?? [];
	$exps = $_POST['line_expiry'] ?? [];

	if ($supId <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $pdate)) {
		$flashKind = 'error';
		$flash = 'Supplier and purchase date required.';
	} elseif (!is_array($dids) || !is_array($qtys) || !is_array($costs) || !is_array($exps)
		|| count($dids) !== count($qtys) || count($dids) !== count($costs) || count($dids) !== count($exps)) {
		$flashKind = 'error';
		$flash = 'Malformed line payload.';
	} else {
		$lines = [];
		$n = count($dids);
		for ($i = 0; $i < $n; $i++) {
			$did = (int) $dids[$i];
			$q = (int) $qtys[$i];
			$c = (float) $costs[$i];
			$exRaw = trim((string) ($exps[$i] ?? ''));
			$exDb = preg_match('/^\d{4}-\d{2}-\d{2}$/', $exRaw) ? $exRaw : null;
			if ($did <= 0 || $q <= 0 || $c < 0) {
				continue;
			}
			$lines[] = ['drug_id' => $did, 'qty' => $q, 'unit_cost' => $c, 'batch_expiry' => $exDb];
		}

		if ($lines === []) {
			$flashKind = 'error';
			$flash = 'Enter at least one product line.';
		} else {
			mysqli_report(MYSQLI_REPORT_OFF);
			$fail = '';
			try {
				$conn->begin_transaction();

				$insP = $conn->prepare(
					'INSERT INTO mc_purchases (supplier_id, purchased_on, purchase_note) VALUES (?,?,?)'
				);
				if (!$insP || !$insP->bind_param('iss', $supId, $pdate, $noteDb) || !$insP->execute()) {
					if ($insP) {
						$insP->close();
					}
					throw new RuntimeException('purch_head');
				}
				$purchaseId = (int) $conn->insert_id;
				$insP->close();

				$insL = $conn->prepare(
					'INSERT INTO mc_purchase_lines (purchase_id, drug_id, qty, unit_cost, line_total, batch_expiry) VALUES (?,?,?,?,?,?)'
				);
				$setExp = $conn->prepare('UPDATE mc_drugs SET expiry_date = ? WHERE drug_id = ? LIMIT 1');

				if (!$insL || !$setExp) {
					throw new RuntimeException('purch_prepare');
				}

				foreach ($lines as $ln) {
					$did = $ln['drug_id'];
					$q = $ln['qty'];
					$uc = round((float) $ln['unit_cost'], 2);
					$lt = round($q * $uc, 2);
					$bex = $ln['batch_expiry'];

					if (!$insL->bind_param('iiidds', $purchaseId, $did, $q, $uc, $lt, $bex)) {
						throw new RuntimeException('purch_bind');
					}
					if (!$insL->execute()) {
						throw new RuntimeException('purch_ins');
					}

					if (!mc_inventory_apply_stock_delta($conn, $did, $q)) {
						throw new RuntimeException('purch_qty');
					}

					if ($bex !== null) {
						if (!$setExp->bind_param('si', $bex, $did) || !$setExp->execute()) {
							throw new RuntimeException('purch_exp');
						}
					}
				}

				$insL->close();
				$setExp->close();

				$conn->commit();
				$flash = 'Purchase #' . $purchaseId . ' booked and stock replenished.';
			} catch (Throwable $e) {
				@$conn->rollback();
				$flashKind = 'error';
				$flash = 'Purchase failed — verify supplier, products, and try again.';
			}
			mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
		}
	}
}

$supRes = $conn->query(
	'SELECT supplier_id, company_name FROM mc_suppliers ORDER BY company_name ASC'
);
$suppliers = [];
if ($supRes) {
	while ($r = $supRes->fetch_assoc()) {
		$suppliers[] = $r;
	}
}

$dRes = $conn->query(
	'SELECT drug_id, name, quantity FROM mc_drugs ORDER BY name ASC LIMIT 600'
);
$dlist = [];
if ($dRes) {
	while ($r = $dRes->fetch_assoc()) {
		$dlist[] = $r;
	}
}

$listSql = <<<'SQL'
SELECT p.purchase_id, p.purchased_on, p.purchase_note, sup.company_name,
  (SELECT COUNT(*) FROM mc_purchase_lines l WHERE l.purchase_id = p.purchase_id) AS line_cnt,
  (SELECT COALESCE(SUM(line_total),0) FROM mc_purchase_lines l2 WHERE l2.purchase_id = p.purchase_id) AS spent
FROM mc_purchases p
JOIN mc_suppliers sup ON sup.supplier_id = p.supplier_id
ORDER BY p.purchase_id DESC
LIMIT 100
SQL;
$histRes = $conn->query($listSql);
$purchHist = [];
if ($histRes) {
	while ($r = $histRes->fetch_assoc()) {
		$purchHist[] = $r;
	}
}

mc_admin_shell_start('Stock purchases', 'purchases');
if ($flash) {
	mc_admin_flash((string) $flash, $flashKind);
}
$today = (new DateTimeImmutable('today'))->format('Y-m-d');
?>
<p class="adm-muted" style="margin-top:-0.35rem;margin-bottom:1rem;">Matches legacy <strong>purchase-add</strong> flow: receive stock tied to a supplier and push quantities into MediCentral SKUs.</p>

<div class="adm-card" style="margin-bottom:1rem;">
	<h2>Record purchase receipt</h2>
	<?php if (!$suppliers): ?>
		<p class="adm-muted">Add a <a class="adm-out" href="suppliers.php">supplier</a> first.</p>
	<?php elseif (!$dlist): ?>
		<p class="adm-muted">Add products under <a class="adm-out" href="inventory.php">Drugs</a>.</p>
	<?php else: ?>
	<form method="post">
		<input type="hidden" name="mc_action" value="record_purchase">
		<div class="adm-form-grid two" style="max-width:620px;margin-bottom:1rem;">
			<div class="adm-field">
				<label for="sid">Supplier</label>
				<select id="sid" name="supplier_id" required>
					<option value="">Choose…</option>
					<?php foreach ($suppliers as $s): ?>
						<option value="<?php echo (int) $s['supplier_id']; ?>"><?php echo htmlspecialchars((string) $s['company_name'], ENT_QUOTES, 'UTF-8'); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="adm-field">
				<label for="pd">Purchase date</label>
				<input id="pd" type="date" name="purchased_on" required value="<?php echo htmlspecialchars($today, ENT_QUOTES, 'UTF-8'); ?>">
			</div>
			<div class="adm-field" style="grid-column:1/-1;">
				<label for="pn">Note · optional</label>
				<input id="pn" name="purchase_note" maxlength="255" placeholder="Invoice / PO reference">
			</div>
		</div>

		<table class="adm-table" style="margin-bottom:1rem;">
			<thead><tr><th>Product</th><th>Qty</th><th>Unit cost</th><th>Batch expiry · optional</th></tr></thead>
			<tbody id="pLines">
				<tr>
					<td>
						<select class="adm-field" style="margin:0;padding:0;" name="line_drug_id[]" required>
							<option value="">Select…</option>
							<?php foreach ($dlist as $d): ?>
								<option value="<?php echo (int) $d['drug_id']; ?>"><?php echo htmlspecialchars((string) $d['name'], ENT_QUOTES, 'UTF-8'); ?> (<?php echo (int) $d['quantity']; ?> on hand)</option>
							<?php endforeach; ?>
						</select>
					</td>
					<td style="width:100px;"><input name="line_qty[]" type="number" min="1" value="1" required></td>
					<td style="width:120px;"><input name="line_cost[]" type="number" min="0" step="0.01" value="0" required></td>
					<td style="width:150px;"><input name="line_expiry[]" type="date"></td>
				</tr>
			</tbody>
		</table>
		<button type="button" class="adm-btn secondary" id="btnAddPurLine">Another line</button>
		<button type="submit" class="adm-btn" style="margin-left:.5rem;">Save purchase</button>
	</form>
	<script>
	document.getElementById("btnAddPurLine").addEventListener("click", function () {
	  var tb = document.getElementById("pLines");
	  var row = tb.rows[0].cloneNode(true);
	  row.querySelectorAll("select, input").forEach(function (el) {
	    if (el.tagName === "SELECT") el.selectedIndex = 0;
	    else if (el.name === "line_qty[]") el.value = "1";
	    else if (el.name === "line_cost[]") el.value = "0";
	    else el.value = "";
	  });
	  tb.appendChild(row);
	});
	</script>
	<?php endif; ?>
</div>

<div class="adm-card">
	<h2>Purchase ledger</h2>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead><tr><th>ID</th><th>Date</th><th>Supplier</th><th>Lines</th><th>Spend</th><th>Note</th></tr></thead>
			<tbody>
				<?php if (!$purchHist): ?>
					<tr><td colspan="6" class="adm-muted">No purchases recorded.</td></tr>
				<?php else: ?>
					<?php foreach ($purchHist as $h): ?>
						<tr>
							<td>#<?php echo (int) $h['purchase_id']; ?></td>
							<td><?php echo htmlspecialchars((string) $h['purchased_on'], ENT_QUOTES, 'UTF-8'); ?></td>
							<td><?php echo htmlspecialchars((string) $h['company_name'], ENT_QUOTES, 'UTF-8'); ?></td>
							<td><?php echo (int) $h['line_cnt']; ?></td>
							<td><?php echo '$' . number_format((float) $h['spent'], 2); ?></td>
							<td><?php echo htmlspecialchars((string) ($h['purchase_note'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
<?php mc_admin_shell_end(); ?>
