<?php



declare(strict_types=1);



require_once dirname(__DIR__) . '/includes/require_admin.php';

require_once dirname(__DIR__) . '/includes/admin_shell.php';

require_once dirname(__DIR__) . '/includes/member_order_payment.php';

require_once dirname(__DIR__) . '/includes/telebirr_verify.php';

require_once dirname(__DIR__) . '/includes/currency.php';



mc_upgrade_member_order_payment_schema($conn);

mc_upgrade_telebirr_verify_schema($conn);



$flash = '';

$flashKind = 'info';



if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['new_status'])) {

	$oid = (int) $_POST['order_id'];

	$st = trim((string) $_POST['new_status']);

	$allowed = ['awaiting_payment', 'pending', 'confirmed', 'ready', 'cancelled'];

	if (!in_array($st, $allowed, true)) {

		$flash = 'Invalid status.';

		$flashKind = 'error';

	} else {

		$upd = $conn->prepare('UPDATE mc_member_orders SET status = ? WHERE order_id = ? LIMIT 1');

		if ($upd && $upd->bind_param('si', $st, $oid) && $upd->execute() && $upd->affected_rows === 1) {

			$flash = 'Order #' . $oid . ' marked as ' . $st . '.';

			$flashKind = 'success';

		} else {

			$flash = 'Could not update order.';

			$flashKind = 'error';

		}

		if ($upd) {

			$upd->close();

		}

	}

}



$orders = [];

$res = $conn->query(

	<<<'SQL'

SELECT o.order_id, o.status, o.total_amount, o.created_at, o.order_note,

  o.prescription_path, o.prescription_qr_text, o.telebirr_transaction_id, o.telebirr_submitted_at,
  o.telebirr_verify_status, o.telebirr_verify_note,

  m.first_name, m.last_name, ph.name AS pharmacy_name

FROM mc_member_orders o

INNER JOIN mc_members m ON m.member_id = o.member_id

INNER JOIN mc_pharmacies ph ON ph.pharmacy_id = o.pharmacy_id

ORDER BY o.created_at DESC

LIMIT 100

SQL

);

if ($res) {

	while ($row = $res->fetch_assoc()) {

		$orders[] = $row;

	}

}



mc_admin_shell_start('Member orders', 'morders');

if ($flash) {

	mc_admin_flash($flash, $flashKind);

}

?>

<div class="adm-panel">

	<p class="adm-muted">Member requests from the network portal. Prescription and Tele Birr details are shown for verification.</p>

	<?php if (!$orders): ?>

		<p>No member orders yet.</p>

	<?php else: ?>

		<div class="adm-table-wrap">

			<table class="adm-table">

				<thead>

					<tr>

						<th>ID</th>

						<th>Member</th>

						<th>Pharmacy</th>

						<th>Total</th>

						<th>Prescription</th>

						<th>Tele Birr</th>

						<th>When</th>

						<th>Status</th>

						<th>Update</th>

					</tr>

				</thead>

				<tbody>

				<?php foreach ($orders as $o): ?>

					<tr>

						<td>#<?php echo (int) $o['order_id']; ?></td>

						<td><?php echo htmlspecialchars(trim((string) $o['first_name'] . ' ' . ($o['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></td>

						<td><?php echo htmlspecialchars((string) $o['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?></td>

						<td><?php echo htmlspecialchars(mc_format_etb((float) $o['total_amount']), ENT_QUOTES, 'UTF-8'); ?></td>

						<td>

							<?php if (!empty($o['prescription_path'])): ?>

								<a href="prescription-file.php?order_id=<?php echo (int) $o['order_id']; ?>" target="_blank" rel="noopener">View file</a>

							<?php elseif (!empty($o['prescription_qr_text'])): ?>

								<span title="<?php echo htmlspecialchars(mb_substr((string) $o['prescription_qr_text'], 0, 200), ENT_QUOTES, 'UTF-8'); ?>">QR data</span>

							<?php else: ?>

								—

							<?php endif; ?>

						</td>

						<td>

							<?php if (!empty($o['telebirr_transaction_id'])): ?>

								<strong><?php echo htmlspecialchars((string) $o['telebirr_transaction_id'], ENT_QUOTES, 'UTF-8'); ?></strong>

								<?php if (!empty($o['telebirr_verify_status'])): ?>
									<?php
									$vst = (string) $o['telebirr_verify_status'];
									$vcls = $vst === 'likely_valid' ? 'adm-badge ok' : ($vst === 'uncertain' ? 'adm-badge warn' : 'adm-badge err');
									?>
									<br><span class="<?php echo htmlspecialchars($vcls, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(mc_telebirr_verify_status_label($vst), ENT_QUOTES, 'UTF-8'); ?></span>
									<?php if (!empty($o['telebirr_verify_note'])): ?>
										<br><small class="adm-muted"><?php echo htmlspecialchars((string) $o['telebirr_verify_note'], ENT_QUOTES, 'UTF-8'); ?></small>
									<?php endif; ?>
								<?php endif; ?>

								<?php if (!empty($o['telebirr_submitted_at'])): ?>

									<br><small><?php echo htmlspecialchars((string) $o['telebirr_submitted_at'], ENT_QUOTES, 'UTF-8'); ?></small>

								<?php endif; ?>

							<?php else: ?>

								—

							<?php endif; ?>

						</td>

						<td><?php echo htmlspecialchars((string) $o['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>

						<td><?php echo htmlspecialchars((string) $o['status'], ENT_QUOTES, 'UTF-8'); ?></td>

						<td>

							<form method="post" class="adm-inline-form">

								<input type="hidden" name="order_id" value="<?php echo (int) $o['order_id']; ?>">

								<select name="new_status">

									<?php foreach (['awaiting_payment', 'pending', 'confirmed', 'ready', 'cancelled'] as $s): ?>

										<option value="<?php echo $s; ?>"<?php echo $o['status'] === $s ? ' selected' : ''; ?>><?php echo $s; ?></option>

									<?php endforeach; ?>

								</select>

								<button type="submit" class="adm-btn">Save</button>

							</form>

						</td>

					</tr>

				<?php endforeach; ?>

				</tbody>

			</table>

		</div>

	<?php endif; ?>

</div>

<?php mc_admin_shell_end(); ?>

