<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

$dto = isset($_GET['date_to']) ? trim((string) $_GET['date_to']) : (new DateTimeImmutable('today'))->format('Y-m-d');
$dfrom = isset($_GET['date_from']) ? trim((string) $_GET['date_from']) : (new DateTimeImmutable($dto))->modify('-30 days')->format('Y-m-d');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dfrom) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dto)) {
	$dto = (new DateTimeImmutable('today'))->format('Y-m-d');
	$dfrom = (new DateTimeImmutable($dto))->modify('-30 days')->format('Y-m-d');
}

$rows = [];

$hasCust = mc_table_has_column($conn, 'mc_sales', 'customer_id');

if ($hasCust) {
	$sql = <<<'SQL'
SELECT s.sale_id, s.sale_at, p.username, c.first_name, c.last_name,
  d.name AS drug_name, i.qty, i.unit_price, i.line_total
FROM mc_sale_items i
JOIN mc_sales s ON s.sale_id = i.sale_id
JOIN mc_drugs d ON d.drug_id = i.drug_id
LEFT JOIN mc_pharmacists p ON p.pharmacist_id = s.pharmacist_id
LEFT JOIN mc_customers c ON c.customer_id = s.customer_id
WHERE DATE(s.sale_at) >= ? AND DATE(s.sale_at) <= ?
ORDER BY s.sale_at DESC, i.sale_id DESC, d.name ASC
LIMIT 800
SQL;
} else {
	$sql = <<<'SQL'
SELECT s.sale_id, s.sale_at, p.username, NULL AS first_name, NULL AS last_name,
  d.name AS drug_name, i.qty, i.unit_price, i.line_total
FROM mc_sale_items i
JOIN mc_sales s ON s.sale_id = i.sale_id
JOIN mc_drugs d ON d.drug_id = i.drug_id
LEFT JOIN mc_pharmacists p ON p.pharmacist_id = s.pharmacist_id
WHERE DATE(s.sale_at) >= ? AND DATE(s.sale_at) <= ?
ORDER BY s.sale_at DESC, i.sale_id DESC, d.name ASC
LIMIT 800
SQL;
}

$st = $conn->prepare($sql);
if ($st) {
	$st->bind_param('ss', $dfrom, $dto);
	if ($st->execute()) {
		$st->bind_result($sid0, $sat, $pun, $cfn, $cln, $dnm, $iq, $iup, $ilt);
		while ($st->fetch()) {
			$rows[] = [
				'sale_id' => $sid0,
				'sale_at' => $sat,
				'username' => $pun,
				'cust' => trim((string) ($cfn ?? '') . ' ' . (string) ($cln ?? '')),
				'drug_name' => $dnm,
				'qty' => $iq,
				'unit_price' => $iup,
				'line_total' => $ilt,
			];
		}
	}
	$st->close();
}

mc_admin_shell_start('Sold products · lines', 'sold');
?>
<div class="adm-card" style="margin-bottom:1rem;">
	<h2>Filters</h2>
	<p class="adm-muted">Every sold line (<strong>salesitems-view</strong> analogue) with Pharmacist/customer attribution.</p>
	<form method="get" action="" class="adm-form-grid two" style="max-width:520px;">
		<div class="adm-field"><label for="df">From</label><input id="df" type="date" name="date_from" value="<?php echo htmlspecialchars($dfrom, ENT_QUOTES, 'UTF-8'); ?>"></div>
		<div class="adm-field"><label for="dt">To</label><input id="dt" type="date" name="date_to" value="<?php echo htmlspecialchars($dto, ENT_QUOTES, 'UTF-8'); ?>"></div>
		<div class="adm-actions"><button type="submit" class="adm-btn">Apply</button></div>
	</form>
</div>

<div class="adm-card">
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead>
				<tr>
					<th>Sale ID</th>
					<th>When</th>
					<th>Pharmacist</th>
					<th>Customer</th>
					<th>SKU</th>
					<th>Qty</th>
					<th>Unit</th>
					<th>Line</th>
				</tr>
			</thead>
			<tbody>
			<?php if (!$rows): ?>
				<tr><td colspan="8" class="adm-muted">No line items.</td></tr>
			<?php else: ?>
				<?php foreach ($rows as $r): ?>
					<tr>
						<td><a class="adm-out" href="sale-detail.php?id=<?php echo (int) $r['sale_id']; ?>">#<?php echo (int) $r['sale_id']; ?></a></td>
						<td><?php echo htmlspecialchars((string) $r['sale_at'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) ($r['username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars($r['cust'] !== '' ? $r['cust'] : '—', ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) $r['drug_name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo (int) $r['qty']; ?></td>
						<td><?php echo '$' . number_format((float) $r['unit_price'], 2); ?></td>
						<td><?php echo '$' . number_format((float) $r['line_total'], 2); ?></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
<?php mc_admin_shell_end(); ?>
