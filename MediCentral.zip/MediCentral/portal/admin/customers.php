<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php');

function mc_customer_can_delete(mysqli $conn, int $cid): bool
{
	if ($cid <= 0) {
		return false;
	}
	$st = $conn->prepare('SELECT 1 FROM mc_sales WHERE customer_id = ? LIMIT 1');
	if (!$st) {
		return false;
	}
	$st->bind_param('i', $cid);
	$st->execute();
	$st->store_result();
	$blocked = $st->num_rows > 0;
	$st->close();

	return !$blocked;
}

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action'])) {
	$act = (string) $_POST['mc_action'];
	if ($act === 'add_customer') {
		$fn = trim((string) ($_POST['first_name'] ?? ''));
		$ln = trim((string) ($_POST['last_name'] ?? ''));
		$ageRaw = ($_POST['age'] ?? '');
		$age = $ageRaw === '' ? null : (int) $ageRaw;
		$ph = trim((string) ($_POST['phone'] ?? ''));
		$em = trim((string) ($_POST['email'] ?? ''));
		$addr = trim((string) ($_POST['address'] ?? ''));
		$mailN = $em === '' ? null : $em;
		if ($fn === '') {
			$flashKind = 'error';
			$flash = 'First name is required.';
		} elseif ($mailN !== null && !filter_var($mailN, FILTER_VALIDATE_EMAIL)) {
			$flashKind = 'error';
			$flash = 'Invalid email.';
		} else {
			if ($age !== null && ($age < 0 || $age > 127)) {
				$age = null;
			}
			$lnN = $ln === '' ? null : $ln;
			$phN = $ph === '' ? null : $ph;
			$adN = $addr === '' ? null : $addr;
			$st = $conn->prepare(
				'INSERT INTO mc_customers (first_name, last_name, age, phone, email, address) VALUES (?,?,?,?,?,?)'
			);
			if ($st && $st->bind_param(
				'ssisss',
				$fn,
				$lnN,
				$age,
				$phN,
				$mailN,
				$adN
			) && $st->execute()) {
				$flash = 'Customer added.';
			} else {
				$flashKind = 'error';
				$flash = 'Could not save customer.';
			}
			if ($st) {
				$st->close();
			}
		}
	} elseif ($act === 'update_customer') {
		$id = (int) ($_POST['customer_id'] ?? 0);
		$fn = trim((string) ($_POST['first_name'] ?? ''));
		$ln = trim((string) ($_POST['last_name'] ?? ''));
		$ageRaw = ($_POST['age'] ?? '');
		$age = $ageRaw === '' ? null : (int) $ageRaw;
		$ph = trim((string) ($_POST['phone'] ?? ''));
		$em = trim((string) ($_POST['email'] ?? ''));
		$addr = trim((string) ($_POST['address'] ?? ''));
		$mailN = $em === '' ? null : $em;
		if ($id <= 0 || $fn === '') {
			$flashKind = 'error';
			$flash = 'Invalid update.';
		} elseif ($mailN !== null && !filter_var($mailN, FILTER_VALIDATE_EMAIL)) {
			$flashKind = 'error';
			$flash = 'Invalid email.';
		} else {
			if ($age !== null && ($age < 0 || $age > 127)) {
				$age = null;
			}
			$lnN = $ln === '' ? null : $ln;
			$phN = $ph === '' ? null : $ph;
			$adN = $addr === '' ? null : $addr;
			$st = $conn->prepare(
				'UPDATE mc_customers SET first_name=?, last_name=?, age=?, phone=?, email=?, address=? WHERE customer_id=?'
			);
			if ($st && $st->bind_param(
				'ssisssi',
				$fn,
				$lnN,
				$age,
				$phN,
				$mailN,
				$adN,
				$id
			) && $st->execute()) {
				$flash = 'Customer updated.';
			} else {
				$flashKind = 'error';
				$flash = 'Could not update.';
			}
			if ($st) {
				$st->close();
			}
		}
	} elseif ($act === 'delete_customer') {
		$id = (int) ($_POST['customer_id'] ?? 0);
		if (!mc_customer_can_delete($conn, $id)) {
			$flashKind = 'error';
			$flash = 'Cannot remove a customer referenced by invoices.';
		} else {
			$d = $conn->prepare('DELETE FROM mc_customers WHERE customer_id = ? LIMIT 1');
			if ($d && $d->bind_param('i', $id) && $d->execute() && $d->affected_rows > 0) {
				$flash = 'Customer removed.';
			} else {
				$flashKind = 'error';
				$flash = 'Could not delete.';
			}
			if ($d) {
				$d->close();
			}
		}
	}
}

$editId = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$editRow = null;
if ($editId > 0) {
	$st = $conn->prepare(
		'SELECT customer_id, first_name, last_name, age, phone, email, address FROM mc_customers WHERE customer_id=? LIMIT 1'
	);
	if ($st) {
		$st->bind_param('i', $editId);
		$st->execute();
		$st->bind_result($cid0, $cfn, $cln, $ca, $cph, $cem, $cad);
		if ($st->fetch()) {
			$editRow = [
				'customer_id' => $cid0,
				'first_name' => $cfn,
				'last_name' => $cln,
				'age' => $ca,
				'phone' => $cph,
				'email' => $cem,
				'address' => $cad,
			];
		}
		$st->close();
	}
}

$listRes = $conn->query(
	'SELECT customer_id, first_name, last_name, phone, age, created_at FROM mc_customers ORDER BY last_name, first_name'
);
$list = [];
if ($listRes) {
	while ($r = $listRes->fetch_assoc()) {
		$list[] = $r;
	}
}

mc_admin_shell_start('Customers', 'customers');
if ($flash) {
	mc_admin_flash((string) $flash, $flashKind);
}
?>
<p class="adm-muted" style="margin-top:-0.35rem;margin-bottom:1rem;">Retail / walk‑in patrons for POS invoicing — similar to legacy <strong>customer</strong> screens.</p>
<div class="adm-grid cols-2" style="margin-bottom:1rem;">
	<div class="adm-card">
		<h2><?php echo $editRow ? 'Edit customer' : 'Add customer'; ?></h2>
		<form method="post" class="adm-form-grid two">
			<input type="hidden" name="mc_action" value="<?php echo $editRow ? 'update_customer' : 'add_customer'; ?>">
			<?php if ($editRow): ?>
				<input type="hidden" name="customer_id" value="<?php echo (int) $editRow['customer_id']; ?>">
			<?php endif; ?>
			<div class="adm-field"><label for="fn">First name</label><input id="fn" name="first_name" required maxlength="80" value="<?php echo htmlspecialchars((string) ($editRow['first_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field"><label for="ln">Last name</label><input id="ln" name="last_name" maxlength="80" value="<?php echo htmlspecialchars((string) ($editRow['last_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field"><label for="age">Age · optional</label><input id="age" name="age" type="number" min="0" max="127" value="<?php echo isset($editRow['age']) && $editRow['age'] !== null ? (int) $editRow['age'] : ''; ?>"></div>
			<div class="adm-field"><label for="ph">Phone</label><input id="ph" name="phone" maxlength="40" value="<?php echo htmlspecialchars((string) ($editRow['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field" style="grid-column:1/-1;"><label for="em">Email</label><input id="em" name="email" type="email" maxlength="120" value="<?php echo htmlspecialchars((string) ($editRow['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-field" style="grid-column:1/-1;"><label for="ad">Address</label><input id="ad" name="address" maxlength="255" value="<?php echo htmlspecialchars((string) ($editRow['address'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
			<div class="adm-actions" style="grid-column:1/-1;">
				<button type="submit" class="adm-btn"><?php echo $editRow ? 'Save' : 'Create'; ?></button>
				<?php if ($editRow): ?><a class="adm-btn secondary" href="customers.php">Cancel</a><?php endif; ?>
			</div>
		</form>
	</div>
	<div class="adm-card">
		<h2>Roster</h2>
		<div class="adm-table-wrap">
			<table class="adm-table">
				<thead><tr><th>Name</th><th>Age</th><th>Phone</th><th></th></tr></thead>
				<tbody>
				<?php if (!$list): ?>
					<tr><td colspan="4" class="adm-muted">No customers yet.</td></tr>
				<?php else: ?>
					<?php foreach ($list as $r): ?>
						<tr>
							<td><?php echo htmlspecialchars(trim((string) $r['first_name'] . ' ' . ($r['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></td>
							<td><?php echo $r['age'] !== null ? (string) (int) $r['age'] : '—'; ?></td>
							<td><?php echo htmlspecialchars((string) ($r['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
							<td>
								<a class="adm-out" href="customers.php?edit=<?php echo (int) $r['customer_id']; ?>">Edit</a>
								<?php if (mc_customer_can_delete($conn, (int) $r['customer_id'])): ?>
									<form method="post" style="display:inline;margin-left:.35rem;" onsubmit="return confirm('Delete customer?');">
										<input type="hidden" name="mc_action" value="delete_customer">
										<input type="hidden" name="customer_id" value="<?php echo (int) $r['customer_id']; ?>">
										<button type="submit" class="adm-btn danger" style="padding:.35rem .5rem;font-size:.78rem;">Del</button>
									</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php mc_admin_shell_end(); ?>
