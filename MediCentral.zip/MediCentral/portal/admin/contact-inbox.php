<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';
require_once dirname(__DIR__) . '/includes/site_contact.php';

$adminId = (int) ($_SESSION['mc_admin_id'] ?? 0);
$mainAdminId = mc_main_admin_id($conn);
$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_read'])) {
	$mid = (int) ($_POST['message_id'] ?? 0);
	if ($mid > 0 && mc_contact_mark_read($conn, $mid, $adminId)) {
		$flash = 'Message marked as read.';
	}
}

$messages = [];
if ($adminId === $mainAdminId || $mainAdminId <= 0) {
	$messages = mc_contact_list_for_admin($conn, $adminId > 0 ? $adminId : $mainAdminId);
} elseif ($mainAdminId > 0) {
	$messages = mc_contact_list_for_admin($conn, $mainAdminId);
}

$unread = mc_contact_unread_count($conn, $adminId > 0 ? $adminId : $mainAdminId);

mc_admin_shell_start('Contact inbox', 'contact');
if ($flash !== '') {
	mc_admin_flash($flash, 'success');
}
if ($adminId !== $mainAdminId && $mainAdminId > 0): ?>
<p class="adm-flash">Messages are delivered to the main administrator account (<code>admin</code>).</p>
<?php endif; ?>
<p class="adm-muted"><?php echo $unread; ?> unread · <?php echo count($messages); ?> recent messages</p>

<?php if ($messages === []): ?>
<p class="adm-muted">No contact messages yet. Visitors can write from <a href="../contact.php">Contact us</a> on the public site.</p>
<?php else: ?>
<div class="adm-inbox">
	<?php foreach ($messages as $m): ?>
	<article class="adm-inbox-item<?php echo (int) ($m['is_read'] ?? 0) === 1 ? ' is-read' : ''; ?>">
		<header>
			<strong><?php echo htmlspecialchars((string) $m['subject'], ENT_QUOTES, 'UTF-8'); ?></strong>
			<span><?php echo htmlspecialchars((string) $m['created_at'], ENT_QUOTES, 'UTF-8'); ?></span>
		</header>
		<p class="adm-inbox-meta">
			<?php echo htmlspecialchars((string) $m['sender_name'], ENT_QUOTES, 'UTF-8'); ?>
			· <a href="mailto:<?php echo htmlspecialchars((string) $m['sender_email'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string) $m['sender_email'], ENT_QUOTES, 'UTF-8'); ?></a>
			<?php if (!empty($m['sender_phone'])): ?>
				· <?php echo htmlspecialchars((string) $m['sender_phone'], ENT_QUOTES, 'UTF-8'); ?>
			<?php endif; ?>
			<?php if (!empty($m['sender_role'])): ?>
				· <span class="adm-tag"><?php echo htmlspecialchars((string) $m['sender_role'], ENT_QUOTES, 'UTF-8'); ?></span>
			<?php endif; ?>
		</p>
		<div class="adm-inbox-body"><?php echo nl2br(htmlspecialchars((string) $m['body'], ENT_QUOTES, 'UTF-8')); ?></div>
		<?php if ((int) ($m['is_read'] ?? 0) !== 1): ?>
		<form method="post" class="adm-inbox-actions">
			<input type="hidden" name="message_id" value="<?php echo (int) $m['message_id']; ?>">
			<button type="submit" name="mark_read" value="1" class="adm-btn-sm">Mark read</button>
		</form>
		<?php endif; ?>
	</article>
	<?php endforeach; ?>
</div>
<?php endif;
mc_admin_shell_end();
