<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

$kpi_ph = $conn->query('SELECT COUNT(*) AS c FROM mc_pharmacists WHERE is_active = 1');
$cnt_ph = ($kpi_ph && ($r = $kpi_ph->fetch_assoc())) ? (int) $r['c'] : 0;

$kpi_drugs = $conn->query('SELECT COUNT(*) AS c, COALESCE(SUM(quantity),0) AS qty FROM mc_drugs');
$row_d = $kpi_drugs ? $kpi_drugs->fetch_assoc() : ['c' => 0, 'qty' => 0];
$cnt_drugs = (int) ($row_d['c'] ?? 0);
$sum_qty = (int) ($row_d['qty'] ?? 0);

$kpi_rev = $conn->query('SELECT COALESCE(SUM(total_amount),0) AS t FROM mc_sales');
$cnt_rev = ($kpi_rev && ($x = $kpi_rev->fetch_assoc())) ? (float) $x['t'] : 0.0;

$today = (new DateTimeImmutable('today'))->format('Y-m-d');
$todayStmt = $conn->prepare('SELECT COALESCE(SUM(total_amount),0) FROM mc_sales WHERE DATE(sale_at) = ?');
$todayRev = 0.0;
if ($todayStmt) {
	$todayStmt->bind_param('s', $today);
	if ($todayStmt->execute()) {
		$todayStmt->bind_result($todayRev);
		$todayStmt->fetch();
	}
	$todayStmt->close();
}

$stmt30 = $conn->query('SELECT COALESCE(SUM(total_amount),0) AS t FROM mc_sales WHERE sale_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)');
$rev30 = ($stmt30 && ($x = $stmt30->fetch_assoc())) ? (float) $x['t'] : 0.0;

$lowStockRes = $conn->query('SELECT COUNT(*) AS n FROM mc_drugs WHERE quantity <= reorder_level');
$lowStockCnt = ($lowStockRes && ($x = $lowStockRes->fetch_assoc())) ? (int) $x['n'] : 0;

$expSoonRes = $conn->query(
	"SELECT COUNT(*) AS n FROM mc_drugs WHERE expiry_date IS NOT NULL AND expiry_date >= CURDATE() AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY)"
);
$expSoonCnt = ($expSoonRes && ($x = $expSoonRes->fetch_assoc())) ? (int) $x['n'] : 0;

$pieCats = [];
$pieQ = $conn->query(
	'SELECT category, SUM(quantity * unit_price) AS val FROM mc_drugs GROUP BY category ORDER BY val DESC'
);
if ($pieQ) {
	while ($rw = $pieQ->fetch_assoc()) {
		$pieCats[] = ['label' => (string) $rw['category'], 'val' => round((float) $rw['val'], 2)];
	}
}

$bd = new DateTimeImmutable('today');
$fromBar = $bd->modify('-13 days')->format('Y-m-d');
$toBar = $bd->format('Y-m-d');
$barMap = [];
$bq = $conn->prepare(
	'SELECT DATE(sale_at) AS d, COALESCE(SUM(total_amount),0) AS t FROM mc_sales WHERE DATE(sale_at) >= ? AND DATE(sale_at) <= ? GROUP BY DATE(sale_at)'
);
if ($bq) {
	$bq->bind_param('ss', $fromBar, $toBar);
	if ($bq->execute()) {
		$dsCol = '';
		$amt = 0.0;
		$bq->bind_result($dsCol, $amt);
		while ($bq->fetch()) {
			$barMap[(string) $dsCol] = round((float) $amt, 2);
		}
	}
	$bq->close();
}
$barLabels = [];
$barVals = [];
for ($i = 13; $i >= 0; $i--) {
	$dayObj = $bd->modify("-{$i} days");
	$barLabels[] = $dayObj->format('M j');
	$ds = $dayObj->format('Y-m-d');
	$barVals[] = $barMap[$ds] ?? 0.0;
}

$topPh = [];
$qt = <<<'SQL'
SELECT p.username, COUNT(s.sale_id) AS cnt, COALESCE(SUM(s.total_amount),0) AS rev
FROM mc_pharmacists p
LEFT JOIN mc_sales s ON s.pharmacist_id = p.pharmacist_id AND s.sale_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
WHERE p.is_active = 1
GROUP BY p.pharmacist_id, p.username ORDER BY rev DESC LIMIT 8
SQL;
$tq = $conn->query($qt);
if ($tq) {
	while ($rw = $tq->fetch_assoc()) {
		$topPh[] = $rw;
	}
}

$topSku = [];
$qs = <<<'SQL'
SELECT d.name,
  COALESCE(SUM(i.qty),0) AS units,
  COALESCE(SUM(i.line_total),0) AS revenue
FROM mc_sale_items i
JOIN mc_drugs d ON d.drug_id = i.drug_id
JOIN mc_sales s ON s.sale_id = i.sale_id
WHERE s.sale_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY d.drug_id, d.name
ORDER BY revenue DESC
LIMIT 8
SQL;
$qrSk = $conn->query($qs);
if ($qrSk) {
	while ($rw = $qrSk->fetch_assoc()) {
		$topSku[] = $rw;
	}
}

$recentSales = [];
$rsl = $conn->query(
	'SELECT s.sale_id, s.sale_at, s.total_amount, p.username FROM mc_sales s LEFT JOIN mc_pharmacists p ON p.pharmacist_id = s.pharmacist_id ORDER BY s.sale_at DESC LIMIT 10'
);
if ($rsl) {
	while ($rw = $rsl->fetch_assoc()) {
		$recentSales[] = $rw;
	}
}

$lowList = [];
$ll = $conn->query(
	'SELECT name, quantity, reorder_level FROM mc_drugs WHERE quantity <= reorder_level ORDER BY quantity ASC LIMIT 8'
);
if ($ll) {
	while ($rw = $ll->fetch_assoc()) {
		$lowList[] = $rw;
	}
}

$expList = [];
$el = $conn->query(
	"SELECT name, expiry_date, quantity FROM mc_drugs WHERE expiry_date IS NOT NULL AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY) ORDER BY expiry_date ASC LIMIT 10"
);
if ($el) {
	while ($rw = $el->fetch_assoc()) {
		$expList[] = $rw;
	}
}

$pieFlags = JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT;
$pie_js = json_encode($pieCats, $pieFlags);
$labels_js = json_encode($barLabels, $pieFlags);
$bars_js = json_encode($barVals, $pieFlags);
$skuLbl = [];
$skuValNum = [];
foreach ($topSku as $rsk) {
	$skuLbl[] = (string) $rsk['name'];
	$skuValNum[] = round((float) $rsk['revenue'], 2);
}
$skuLabels_js = json_encode($skuLbl, $pieFlags);
$skuVals_js = json_encode($skuValNum, $pieFlags);

mc_admin_shell_start('Overview', 'dashboard');
?>
<div class="adm-grid cols-4" style="margin-bottom: 1rem;">
	<div class="adm-card adm-kpi"><span>Active pharmacists</span><strong><?php echo $cnt_ph; ?></strong></div>
	<div class="adm-card adm-kpi"><span>Drug SKU count</span><strong><?php echo $cnt_drugs; ?></strong></div>
	<div class="adm-card adm-kpi"><span>Stock units</span><strong><?php echo number_format($sum_qty); ?></strong></div>
	<div class="adm-card adm-kpi"><span>All-time revenue</span><strong><?php echo '$' . number_format($cnt_rev, 2); ?></strong></div>
</div>

<div class="adm-grid cols-4" style="margin-bottom: 1rem;">
	<div class="adm-card adm-kpi"><span>Today’s sales</span><strong><?php echo '$' . number_format((float) $todayRev, 2); ?></strong></div>
	<div class="adm-card adm-kpi"><span>Last 30 days</span><strong><?php echo '$' . number_format($rev30, 2); ?></strong></div>
	<div class="adm-card adm-kpi <?php echo $lowStockCnt > 0 ? 'adm-kpi-warn' : ''; ?>"><span>Low-stock SKU</span><strong><?php echo $lowStockCnt; ?></strong></div>
	<div class="adm-card adm-kpi <?php echo $expSoonCnt > 0 ? 'adm-kpi-warn' : ''; ?>"><span>Expiring · 90d window</span><strong><?php echo $expSoonCnt; ?></strong></div>
</div>

<div class="adm-card adm-quicklinks" style="margin-bottom:1rem;">
	<h2 style="margin:0 0 0.5rem;font-size:1.02rem;">More tools · aligned with legacy PHARMACIA</h2>
	<p class="adm-muted" style="margin-bottom:0.85rem;">Suppliers / purchases / shoppers / SKU lines — ported into MediCentral naming and workflows.</p>
	<div style="display:flex;flex-wrap:wrap;gap:0.65rem;font-size:0.88rem;">
		<a class="adm-btn secondary" href="suppliers.php">Suppliers</a>
		<a class="adm-btn secondary" href="purchases.php">Stock purchases</a>
		<a class="adm-btn secondary" href="customers.php">Customers</a>
		<a class="adm-btn secondary" href="sold-products.php">Sold line items</a>
	</div>
</div>

<div class="adm-grid cols-2">
	<div class="adm-card">
		<h2>Portfolio value by category</h2>
		<p class="adm-muted">Quantity × shelf price grouped by therapeutic or retail category.</p>
		<div class="adm-chart-wrap"><canvas id="chartPie"></canvas></div>
	</div>
	<div class="adm-card">
		<h2>Daily sales · last 14 days</h2>
		<p class="adm-muted">From <code style="font-size:.8rem;">mc_sales</code> totals by calendar day.</p>
		<div class="adm-chart-wrap"><canvas id="chartBar"></canvas></div>
	</div>
</div>

<div class="adm-card" style="margin-top:1rem;">
	<h2>Top movers · attributed revenue · last 30 days</h2>
	<p class="adm-muted">Line-level sales from <code style="font-size:.8rem;">mc_sale_items</code> attributed to pharmacists recording transactions.</p>
	<div class="adm-chart-wrap adm-chart-short"><canvas id="chartSku"></canvas></div>
</div>

<div class="adm-grid cols-2" style="margin-top:1rem;">
	<div class="adm-card adm-alert-stack">
		<div class="adm-card-head"><h2>Low stock</h2><a class="adm-out" href="stock-health.php">Full stock health</a></div>
		<?php if (!$lowList): ?>
			<p class="adm-muted">No SKUs at or below reorder threshold.</p>
		<?php else: ?>
			<ul class="adm-alert-list">
				<?php foreach ($lowList as $Lw): ?>
					<li><span><?php echo htmlspecialchars((string) $Lw['name'], ENT_QUOTES, 'UTF-8'); ?></span><span class="adm-pill"><?php echo (int) $Lw['quantity']; ?> ≤ <?php echo (int) $Lw['reorder_level']; ?></span></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<div class="adm-card adm-alert-stack">
		<div class="adm-card-head"><h2>Expiry radar · next 90 days</h2></div>
		<?php if (!$expList): ?>
			<p class="adm-muted">No expiry dates logged or nothing due in this window.</p>
		<?php else: ?>
			<ul class="adm-alert-list">
				<?php
				foreach ($expList as $Lw):
					$ed = (string) $Lw['expiry_date'];
					$cls = '';
					try {
						$dex = new DateTimeImmutable($ed);
						if ($dex < new DateTimeImmutable('today')) {
							$cls = ' is-expired';
						}
					} catch (Throwable $e) {
					}
					?>
					<li class="<?php echo trim($cls); ?>"><span><?php echo htmlspecialchars((string) $Lw['name'], ENT_QUOTES, 'UTF-8'); ?></span><span class="adm-pill"><?php echo htmlspecialchars($ed, ENT_QUOTES, 'UTF-8'); ?> · qty <?php echo (int) $Lw['quantity']; ?></span></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</div>

<div class="adm-card" style="margin-top:1rem;">
	<h2>Recent transactions</h2>
	<p class="adm-muted">Latest ten postings across all pharmacists. <a class="adm-out" href="sales-report.php">Open sales report</a></p>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead><tr><th>ID</th><th>When</th><th>Pharmacist</th><th>Total</th><th></th></tr></thead>
			<tbody>
			<?php if (!$recentSales): ?>
				<tr><td colspan="5" class="adm-muted">No sales recorded yet. Pharmacists record sales from their workspace.</td></tr>
			<?php else: ?>
				<?php foreach ($recentSales as $rw): ?>
					<tr>
						<td>#<?php echo (int) $rw['sale_id']; ?></td>
						<td><?php echo htmlspecialchars((string) $rw['sale_at'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) ($rw['username'] ?? '(unassigned)'), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo '$' . number_format((float) $rw['total_amount'], 2); ?></td>
						<td><a class="adm-out" href="sale-detail.php?id=<?php echo (int) $rw['sale_id']; ?>">Invoice</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>

<div class="adm-card" style="margin-top: 1rem;">
	<h2>Pharmacist activity (rolling 90 days)</h2>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead><tr><th>Username</th><th>Sales count</th><th>Attributed revenue</th></tr></thead>
			<tbody>
			<?php if (!$topPh): ?>
				<tr><td colspan="3" class="adm-muted">No activity yet.</td></tr>
			<?php else: ?>
				<?php foreach ($topPh as $rw): ?>
					<tr>
						<td><?php echo htmlspecialchars((string) $rw['username'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo (int) $rw['cnt']; ?></td>
						<td><?php echo '$' . number_format((float) $rw['rev'], 2); ?></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function(){
  var pie = <?php echo $pie_js; ?>;
  var labels = <?php echo $labels_js; ?>;
  var bars = <?php echo $bars_js; ?>;
  var skuLbl = <?php echo $skuLabels_js; ?>;
  var skuVal = <?php echo $skuVals_js; ?>;
  var pal = ["#12c2a8","#38bdf8","#a78bfa","#fb7185","#fbbf24","#94a3b8","#34d399","#60a5fa"];
  var pieLbl = pie.map(function(r){return r.label;});
  var pieVal = pie.map(function(r){return r.val;});
  var axisColor = '#8b9bb4';
  if(document.getElementById("chartPie")){
    new Chart(document.getElementById("chartPie"),{
      type:"doughnut",
      data:{
        labels:pieLbl,
        datasets:[{data:pieVal,backgroundColor:pal}]
      },
      options:{maintainAspectRatio:false,plugins:{legend:{labels:{color:"#e8eef6"}}}}
    });
  }
  if(document.getElementById("chartBar")){
    new Chart(document.getElementById("chartBar"),{
      type:"bar",
      data:{
        labels:labels,
        datasets:[{label:"Sales",data:bars,backgroundColor:"rgba(18,194,168,0.45)",borderRadius:8}]
      },
      options:{maintainAspectRatio:false,
        scales:{
          x:{ticks:{color:axisColor}},
          y:{ticks:{color:axisColor},grid:{color:"rgba(255,255,255,.06)"}}
        },
        plugins:{legend:{display:false}}}
    });
  }
  if(document.getElementById("chartSku") && skuLbl.length){
    new Chart(document.getElementById("chartSku"),{
      type:"bar",
      data:{
        labels:skuLbl,
        datasets:[{label:"Line revenue · 30d",data:skuVal,backgroundColor:"rgba(56,189,248,0.42)",borderRadius:6}]
      },
      options:{indexAxis:"y",maintainAspectRatio:false,
        scales:{
          x:{ticks:{color:axisColor},grid:{color:"rgba(255,255,255,.06)"}},
          y:{ticks:{color:axisColor}}
        },
        plugins:{legend:{display:false}}}
    });
  }
})();
</script>
<?php mc_admin_shell_end(); ?>
