<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

$low = [];
$rL = $conn->query(
	'SELECT drug_id, name, category, quantity, reorder_level, unit_price FROM mc_drugs WHERE quantity <= reorder_level ORDER BY quantity ASC'
);
if ($rL) {
	while ($rw = $rL->fetch_assoc()) {
		$low[] = $rw;
	}
}

$exp = [];
$rE = $conn->query(
	"SELECT drug_id, name, category, quantity, expiry_date, DATEDIFF(expiry_date, CURDATE()) AS days_left
	FROM mc_drugs
	WHERE expiry_date IS NOT NULL
	ORDER BY expiry_date ASC LIMIT 250"
);
if ($rE) {
	while ($rw = $rE->fetch_assoc()) {
		$exp[] = $rw;
	}
}

mc_admin_shell_start('Stock health', 'stock');
?>
<div class="adm-card" style="margin-bottom:1rem;">
	<h2>Operational guardrails</h2>
	<p class="adm-muted">Reorder levels and expiry tracking keep dispensing aligned with what you stocked in inventory. Tune thresholds per SKU from <a class="adm-out" href="inventory.php">Drugs &amp; barcodes</a>.</p>
</div>

<div class="adm-card" style="margin-bottom:1rem;">
	<h2>Low stock · at or below reorder level</h2>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead>
				<tr><th>Name</th><th>Category</th><th>Qty</th><th>Reorder</th><th>Unit price</th><th></th></tr>
			</thead>
			<tbody>
			<?php if (!$low): ?>
				<tr><td colspan="6" class="adm-muted">All SKUs are above their reorder thresholds.</td></tr>
			<?php else: ?>
				<?php foreach ($low as $d): ?>
					<tr class="adm-row-low">
						<td><?php echo htmlspecialchars((string) $d['name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) ($d['category'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo (int) $d['quantity']; ?></td>
						<td><?php echo (int) $d['reorder_level']; ?></td>
						<td><?php echo number_format((float) $d['unit_price'], 2); ?></td>
						<td><a class="adm-out" href="inventory.php?edit=<?php echo (int) $d['drug_id']; ?>">Adjust stock</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>

<div class="adm-card">
	<h2>Expiry ledger</h2>
	<p class="adm-muted"><strong class="adm-text-warn">Amber tint</strong> when within 90 days; <strong class="adm-text-danger">red</strong> when past today.</p>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead>
				<tr><th>Name</th><th>Category</th><th>Expiry</th><th>Days</th><th>Qty</th><th></th></tr>
			</thead>
			<tbody>
			<?php if (!$exp): ?>
				<tr><td colspan="6" class="adm-muted">Log expiry dates on products to populate this ledger.</td></tr>
			<?php else: ?>
				<?php
				$today = new DateTimeImmutable('today');
				foreach ($exp as $d):
					$rowClass = '';
					$dleft = isset($d['days_left']) ? (int) $d['days_left'] : null;
					if ($dleft !== null) {
						if ($dleft < 0) {
							$rowClass = ' adm-row-danger';
						} elseif ($dleft <= 90) {
							$rowClass = ' adm-row-warn';
						}
					}
					?>
					<tr class="<?php echo trim($rowClass); ?>">
						<td><?php echo htmlspecialchars((string) $d['name'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) ($d['category'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) $d['expiry_date'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo $dleft !== null ? (string) $dleft : '—'; ?></td>
						<td><?php echo (int) $d['quantity']; ?></td>
						<td><a class="adm-out" href="inventory.php?edit=<?php echo (int) $d['drug_id']; ?>">Edit</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>

<?php mc_admin_shell_end(); ?>
