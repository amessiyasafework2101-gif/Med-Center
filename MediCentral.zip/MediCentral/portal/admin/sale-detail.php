<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$hdr = null;
$lines = [];

if ($id > 0) {
	if (mc_table_has_column($conn, 'mc_sales', 'customer_id')) {
		$hst = $conn->prepare(
			<<<SQL
SELECT s.sale_id, s.sale_at, s.total_amount, s.sale_note, p.username AS ph_user,
  c.customer_id AS cust_id, c.first_name AS cfn, c.last_name AS cln, c.phone AS cph
FROM mc_sales s
LEFT JOIN mc_pharmacists p ON p.pharmacist_id = s.pharmacist_id
LEFT JOIN mc_customers c ON c.customer_id = s.customer_id
WHERE s.sale_id = ? LIMIT 1
SQL
		);
	} else {
		$hst = $conn->prepare(
			<<<SQL
SELECT s.sale_id, s.sale_at, s.total_amount, s.sale_note, p.username AS ph_user
FROM mc_sales s
LEFT JOIN mc_pharmacists p ON p.pharmacist_id = s.pharmacist_id
WHERE s.sale_id = ? LIMIT 1
SQL
		);
	}
	if ($hst) {
		$hst->bind_param('i', $id);
		$hst->execute();
		if (mc_table_has_column($conn, 'mc_sales', 'customer_id')) {
			$hst->bind_result($sid0, $sat, $sta, $sno, $phu, $cid, $cfn, $cln, $cph);
		} else {
			$cid = null;
			$cfn = null;
			$cln = null;
			$cph = null;
			$hst->bind_result($sid0, $sat, $sta, $sno, $phu);
		}
		if ($hst->fetch()) {
			$hdr = [
				'sale_id' => $sid0,
				'sale_at' => $sat,
				'total_amount' => $sta,
				'sale_note' => $sno,
				'pharmacist_username' => $phu,
				'customer_id' => $cid,
				'cfn' => $cfn,
				'cln' => $cln,
				'c_phone' => $cph ?? null,
			];
		}
		$hst->close();
	}
}

if ($id > 0 && $hdr) {
	$lst = $conn->prepare(
		<<<SQL
SELECT d.name, i.qty, i.unit_price, i.line_total
FROM mc_sale_items i
JOIN mc_drugs d ON d.drug_id = i.drug_id
WHERE i.sale_id = ?
ORDER BY d.name ASC
SQL
	);
	if ($lst) {
		$lst->bind_param('i', $id);
		$lst->execute();
		$lst->bind_result($dnm, $iq, $iu, $il);
		while ($lst->fetch()) {
			$lines[] = ['name' => $dnm, 'qty' => $iq, 'unit_price' => $iu, 'line_total' => $il];
		}
		$lst->close();
	}
}

mc_admin_shell_start($hdr ? 'Invoice #' . (int) $hdr['sale_id'] : 'Invoice', 'detail');
?>
<?php if (!$hdr): ?>
	<div class="adm-card adm-flash error">
		<p style="margin:0;">Invoice not found. Return to <a class="adm-out" href="sales-report.php">sales report</a>.</p>
	</div>
<?php else: ?>
	<div class="adm-card" style="margin-bottom:1rem;">
		<p class="adm-muted">Legacy analogue: <strong>sales-view</strong> header + sold lines underneath.</p>
		<dl class="adm-muted" style="display:grid;grid-template-columns:140px 1fr;gap:.35rem 1rem;margin:1rem 0 0;font-size:.9rem;">
			<dt>When</dt><dd style="margin:0;color:var(--adm-text);"><?php echo htmlspecialchars((string) $hdr['sale_at'], ENT_QUOTES, 'UTF-8'); ?></dd>
			<dt>Pharmacist</dt><dd style="margin:0;color:var(--adm-text);"><?php echo htmlspecialchars($hdr['pharmacist_username'] ? (string) $hdr['pharmacist_username'] : '(counter)', ENT_QUOTES, 'UTF-8'); ?></dd>
			<dt>Customer</dt><dd style="margin:0;color:var(--adm-text);"><?php
			if ($hdr['customer_id']) {
				echo htmlspecialchars(
					trim((string) $hdr['cfn'] . ' ' . ($hdr['cln'] ?? '')) . (($hdr['c_phone'] ?? '') !== '' ? ' · ' . (string) $hdr['c_phone'] : ''),
					ENT_QUOTES,
					'UTF-8'
				);
			} else {
				echo '(walk‑in)';
			}
?></dd>
			<dt>Total</dt><dd style="margin:0;color:var(--adm-accent);font-weight:700;"><?php echo '$' . number_format((float) $hdr['total_amount'], 2); ?></dd>
			<dt>Note</dt><dd style="margin:0;color:var(--adm-text);"><?php echo htmlspecialchars((string) ($hdr['sale_note'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></dd>
		</dl>
	</div>
	<div class="adm-card">
		<h2>Line items</h2>
		<div class="adm-table-wrap">
			<table class="adm-table">
				<thead><tr><th>Product</th><th>Qty</th><th>Unit price</th><th>Line</th></tr></thead>
				<tbody>
				<?php if (!$lines): ?>
					<tr><td colspan="4" class="adm-muted">No lines stored.</td></tr>
				<?php else: ?>
					<?php foreach ($lines as $L): ?>
						<tr>
							<td><?php echo htmlspecialchars((string) $L['name'], ENT_QUOTES, 'UTF-8'); ?></td>
							<td><?php echo (int) $L['qty']; ?></td>
							<td><?php echo '$' . number_format((float) $L['unit_price'], 2); ?></td>
							<td><?php echo '$' . number_format((float) $L['line_total'], 2); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
		<p style="margin-top:1rem;"><a class="adm-out" href="sales-report.php">← Sales report</a></p>
	</div>
<?php endif; ?>
<?php mc_admin_shell_end(); ?>
