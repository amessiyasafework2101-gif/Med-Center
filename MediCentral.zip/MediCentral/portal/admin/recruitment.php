<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';
require_once dirname(__DIR__) . '/includes/pharmacist_ratings.php';
require_once dirname(__DIR__) . '/includes/chat_ui.php';

$adminId = (int) ($_SESSION['mc_admin_id'] ?? 0);
$pharmacyId = (int) ($_SESSION['mc_admin_pharmacy_id'] ?? 0);
$flash = null;
$flashKind = 'success';

if ($pharmacyId <= 0) {
	mc_admin_shell_start('Recruitment', 'recruitment');
	mc_admin_flash('Assign your account to a pharmacy (system admin) before sending work offers.', 'error');
	mc_admin_shell_end();
	exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['send_offer'])) {
		$targetPh = (int) ($_POST['pharmacist_id'] ?? 0);
		$title = trim((string) ($_POST['title'] ?? ''));
		$msg = trim((string) ($_POST['message'] ?? ''));
		if ($targetPh > 0 && $title !== '') {
			$stmt = $conn->prepare(
				'INSERT INTO mc_pharmacy_opportunities (pharmacy_id, admin_id, pharmacist_id, title, message, status) VALUES (?,?,?,?,?,\'pending\')'
			);
			if ($stmt) {
				$stmt->bind_param('iiiss', $pharmacyId, $adminId, $targetPh, $title, $msg);
				if ($stmt->execute()) {
					mc_pharmacist_post_message($conn, $targetPh, 'work', 'admin', 'Work offer: ' . $title . "\n" . $msg, null, $adminId, null);
					$flash = 'Offer sent and posted to work chat.';
				}
				$stmt->close();
			}
		}
	} elseif (isset($_POST['rate_pharmacist'])) {
		$targetPh = (int) ($_POST['pharmacist_id'] ?? 0);
		$score = (int) ($_POST['score'] ?? 0);
		$comment = trim((string) ($_POST['comment'] ?? ''));
		if ($targetPh > 0) {
			$res = mc_pharmacist_save_rating($conn, $targetPh, 'admin', $score, $comment, null, $adminId);
			$flash = $res['msg'];
			$flashKind = $res['ok'] ? 'success' : 'error';
		}
	} elseif (isset($_POST['admin_message'])) {
		$targetPh = (int) ($_POST['pharmacist_id'] ?? 0);
		$body = trim((string) ($_POST['body'] ?? ''));
		$ch = (string) ($_POST['channel'] ?? 'admin');
		if (!in_array($ch, ['admin', 'work'], true)) {
			$ch = 'admin';
		}
		if ($targetPh > 0 && $body !== '') {
			mc_pharmacist_post_message($conn, $targetPh, $ch, 'admin', $body, null, $adminId, null);
			$flash = 'Message sent.';
		}
	}
}

$candidates = mc_pharmacist_list_approved($conn, 80);

mc_admin_shell_start('Recruitment', 'recruitment');
echo '<link rel="stylesheet" href="../css/mc-chat.css">';
if ($flash) {
	mc_admin_flash($flash, $flashKind);
}
?>
<p class="adm-muted">Send work opportunities to approved pharmacists (sorted by performance score). <a href="messages.php">Open Messages &amp; chat</a> for full conversations.</p>
<section class="adm-card" style="margin-bottom:1rem;">
	<h2>Send offer</h2>
	<form method="post" class="adm-form-grid">
		<input type="hidden" name="send_offer" value="1">
		<div class="adm-field"><label>Pharmacist</label>
			<select name="pharmacist_id" required>
				<?php foreach ($candidates as $c): ?>
					<option value="<?php echo (int) $c['pharmacist_id']; ?>">
						<?php echo htmlspecialchars(trim($c['first_name'] . ' ' . ($c['last_name'] ?? '')) . ' · ★' . number_format((float) $c['performance_score'], 1) . ' (' . (int) $c['rating_count'] . ')', ENT_QUOTES, 'UTF-8'); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="adm-field"><label>Title</label><input type="text" name="title" required></div>
		<div class="adm-field" style="grid-column:1/-1;"><label>Message</label><textarea name="message" rows="4"></textarea></div>
		<button type="submit" class="adm-btn">Send offer</button>
	</form>
</section>
<section class="adm-card" style="margin-bottom:1rem;">
	<h2>Rate performance</h2>
	<form method="post" class="adm-form-grid">
		<input type="hidden" name="rate_pharmacist" value="1">
		<div class="adm-field"><label>Pharmacist</label>
			<select name="pharmacist_id" required>
				<?php foreach ($candidates as $c): ?>
					<option value="<?php echo (int) $c['pharmacist_id']; ?>"><?php echo htmlspecialchars(trim($c['first_name'] . ' ' . ($c['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="adm-field" style="grid-column:1/-1;">
			<?php mc_rating_render_picker('score', 0, 'Performance rating'); ?>
		</div>
		<div class="adm-field" style="grid-column:1/-1;"><label>Comment</label><input type="text" name="comment" class="mc-rate-comment" maxlength="500"></div>
		<button type="submit" class="adm-btn">Save rating</button>
	</form>
</section>
<section class="adm-card">
	<h2>Chat with pharmacist</h2>
	<form method="post" class="adm-form-grid">
		<input type="hidden" name="admin_message" value="1">
		<div class="adm-field"><label>Pharmacist</label>
			<select name="pharmacist_id" required>
				<?php foreach ($candidates as $c): ?>
					<option value="<?php echo (int) $c['pharmacist_id']; ?>"><?php echo htmlspecialchars(trim($c['first_name'] . ' ' . ($c['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="adm-field"><label>Channel</label>
			<select name="channel">
				<option value="admin">Admin chat</option>
				<option value="work">Work discussion</option>
			</select>
		</div>
		<div class="adm-field" style="grid-column:1/-1;"><label>Message</label><textarea name="body" rows="3" required></textarea></div>
		<button type="submit" class="adm-btn">Send message</button>
	</form>
</section>
<script src="../js/mc-star-rating.js" defer></script>
<?php
mc_admin_shell_end();
