<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

function pharmacist_username_available_except(mysqli $conn, string $username, int $exceptId): bool
{
	if ($exceptId > 0) {
		$stmt = $conn->prepare('SELECT 1 FROM mc_pharmacists WHERE username = ? AND pharmacist_id <> ? LIMIT 1');
		if (!$stmt) {
			return false;
		}
		$stmt->bind_param('si', $username, $exceptId);
	} else {
		$stmt = $conn->prepare('SELECT 1 FROM mc_pharmacists WHERE username = ? LIMIT 1');
		if (!$stmt) {
			return false;
		}
		$stmt->bind_param('s', $username);
	}
	if (!$stmt->execute()) {
		$stmt->close();

		return false;
	}
	$stmt->store_result();
	$taken = $stmt->num_rows > 0;
	$stmt->close();

	return !$taken;
}

$adminPharmacyId = isset($_SESSION['mc_admin_pharmacy_id']) ? (int) $_SESSION['mc_admin_pharmacy_id'] : 0;
$adminPharmacyName = '';
if ($adminPharmacyId > 0) {
	$pn = $conn->prepare('SELECT name FROM mc_pharmacies WHERE pharmacy_id = ? LIMIT 1');
	if ($pn) {
		$pn->bind_param('i', $adminPharmacyId);
		$pn->execute();
		$pn->bind_result($adminPharmacyName);
		$pn->fetch();
		$pn->close();
	}
}

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action'])) {
	$action = (string) $_POST['mc_action'];

	if ($action === 'add_pharmacist') {
		if ($adminPharmacyId <= 0) {
			$flashKind = 'error';
			$flash = 'Your account is not assigned to a pharmacy. Contact the system administrator.';
		} else {
		$user = strtolower(trim((string) ($_POST['username'] ?? '')));
		$fname = trim((string) ($_POST['first_name'] ?? ''));
		$lname = trim((string) ($_POST['last_name'] ?? ''));
		$email = trim((string) ($_POST['email'] ?? ''));
		$pw = (string) ($_POST['password'] ?? '');

		if ($user === '' || $fname === '' || strlen($pw) < 10) {
			$flashKind = 'error';
			$flash = 'Username, first name, and password (min 10 characters) are required.';
		} elseif (!preg_match('/^[a-z0-9_.-]{3,50}$/', $user)) {
			$flashKind = 'error';
			$flash = 'Username must use 3–50 lowercase letters, numbers, or ._- ';
		} elseif (!pharmacist_username_available_except($conn, $user, 0)) {
			$flashKind = 'error';
			$flash = 'That username is already used.';
		} else {
			$mail = $email === '' ? null : $email;
			$h = password_hash($pw, PASSWORD_DEFAULT);
			if (mc_table_has_column($conn, 'mc_pharmacists', 'pharmacy_id')) {
				$stmt = $conn->prepare(
					'INSERT INTO mc_pharmacists (username, password_hash, first_name, last_name, email, pharmacy_id, is_active) VALUES (?,?,?,?,?,?,1)'
				);
				if ($stmt) {
					$stmt->bind_param(str_repeat('s', 5) . 'i', $user, $h, $fname, $lname, $mail, $adminPharmacyId);
				}
			} else {
				$stmt = $conn->prepare(
					'INSERT INTO mc_pharmacists (username, password_hash, first_name, last_name, email, is_active) VALUES (?,?,?,?,?,1)'
				);
				if ($stmt) {
					$stmt->bind_param(str_repeat('s', 5), $user, $h, $fname, $lname, $mail);
				}
			}
			if ($stmt) {
				if ($stmt->execute()) {
					$flash = 'Pharmacy staff account created for your location.';
				} else {
					$flashKind = 'error';
					$flash = 'Could not create staff account.';
				}
				$stmt->close();
			}
		}
		}
	} elseif ($action === 'update_pharmacist') {
		$id = (int) ($_POST['pharmacist_id'] ?? 0);
		$user = strtolower(trim((string) ($_POST['username'] ?? '')));
		$fname = trim((string) ($_POST['first_name'] ?? ''));
		$lname = trim((string) ($_POST['last_name'] ?? ''));
		$email = trim((string) ($_POST['email'] ?? ''));
		$pw = (string) ($_POST['new_password'] ?? '');
		$active = isset($_POST['is_active']) ? 1 : 0;

		if ($id <= 0 || $user === '' || $fname === '') {
			$flashKind = 'error';
			$flash = 'Invalid pharmacist update.';
		} elseif (!preg_match('/^[a-z0-9_.-]{3,50}$/', $user)) {
			$flashKind = 'error';
			$flash = 'Username format invalid.';
		} elseif (!pharmacist_username_available_except($conn, $user, $id)) {
			$flashKind = 'error';
			$flash = 'Another pharmacist already uses that username.';
		} elseif ($pw !== '' && strlen($pw) < 10) {
			$flashKind = 'error';
			$flash = 'New password must be at least 10 characters.';
		} else {
			if ($pw !== '') {
				$h = password_hash($pw, PASSWORD_DEFAULT);
				$mail = $email === '' ? null : $email;
				$stmt = $conn->prepare(
					'UPDATE mc_pharmacists SET username=?, first_name=?, last_name=?, email=?, is_active=?, password_hash=? WHERE pharmacist_id=?'
				);
				if ($stmt) {
					$stmt->bind_param(str_repeat('s', 4) . 'isi', $user, $fname, $lname, $mail, $active, $h, $id);
					if ($stmt->execute()) {
						$flash = 'Pharmacist updated (password changed).';
					} else {
						$flashKind = 'error';
						$flash = 'Update failed.';
					}
					$stmt->close();
				}
			} else {
				$mail = $email === '' ? null : $email;
				$stmt = $conn->prepare(
					'UPDATE mc_pharmacists SET username=?, first_name=?, last_name=?, email=?, is_active=? WHERE pharmacist_id=?'
				);
				if ($stmt) {
					$stmt->bind_param(str_repeat('s', 4) . 'ii', $user, $fname, $lname, $mail, $active, $id);
					if ($stmt->execute()) {
						$flash = 'Pharmacist updated.';
					} else {
						$flashKind = 'error';
						$flash = 'Update failed.';
					}
					$stmt->close();
				}
			}
		}
	}
}

$editId = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$editRow = null;
if ($editId > 0) {
	$st = $conn->prepare('SELECT pharmacist_id, username, first_name, last_name, email, is_active FROM mc_pharmacists WHERE pharmacist_id = ? LIMIT 1');
	if ($st) {
		$st->bind_param('i', $editId);
		$st->execute();
		$st->bind_result($bid, $buser, $bf, $bl, $bmail, $bact);
		if ($st->fetch()) {
			$editRow = [
				'pharmacist_id' => $bid,
				'username' => $buser,
				'first_name' => $bf,
				'last_name' => $bl,
				'email' => $bmail,
				'is_active' => $bact,
			];
		}
		$st->close();
	}
}

if ($adminPharmacyId > 0 && mc_table_has_column($conn, 'mc_pharmacists', 'pharmacy_id')) {
	$sql = <<<SQL
SELECT p.pharmacist_id, p.username, p.first_name, p.last_name, p.email, p.is_active, p.last_login_at,
  COUNT(DISTINCT s.sale_id) AS sale_cnt,
  COALESCE(SUM(s.total_amount),0) AS sale_rev,
  COUNT(DISTINCT CASE WHEN s.sale_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN s.sale_id END) AS sale_cnt_30
FROM mc_pharmacists p
LEFT JOIN mc_sales s ON s.pharmacist_id = p.pharmacist_id
WHERE p.pharmacy_id = ?
GROUP BY p.pharmacist_id, p.username, p.first_name, p.last_name, p.email, p.is_active, p.last_login_at
ORDER BY p.is_active DESC, p.username ASC
SQL;
	$listStmt = $conn->prepare($sql);
	$listRes = null;
	if ($listStmt) {
		$listStmt->bind_param('i', $adminPharmacyId);
		$listStmt->execute();
		$listRes = $listStmt->get_result();
	}
} else {
	$sql = <<<SQL
SELECT p.pharmacist_id, p.username, p.first_name, p.last_name, p.email, p.is_active, p.last_login_at,
  COUNT(DISTINCT s.sale_id) AS sale_cnt,
  COALESCE(SUM(s.total_amount),0) AS sale_rev,
  COUNT(DISTINCT CASE WHEN s.sale_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN s.sale_id END) AS sale_cnt_30
FROM mc_pharmacists p
LEFT JOIN mc_sales s ON s.pharmacist_id = p.pharmacist_id
GROUP BY p.pharmacist_id, p.username, p.first_name, p.last_name, p.email, p.is_active, p.last_login_at
ORDER BY p.is_active DESC, p.username ASC
SQL;
	$listRes = $conn->query($sql);
}
$rows = [];
if ($listRes) {
	while ($r = $listRes->fetch_assoc()) {
		$rows[] = $r;
	}
}

mc_admin_shell_start('Pharmacy staff', 'pharmacists');
if ($flash) {
	mc_admin_flash((string) $flash, $flashKind);
}

?>
<?php if ($adminPharmacyId <= 0): ?>
<div class="adm-card" style="margin-bottom:1rem;">
	<h2>Pharmacy assignment required</h2>
	<p class="adm-muted">Only a <strong>pharmacy administrator</strong> (promoted from a network member by the system admin) can add staff here. Sign in with an account that is linked to your pharmacy, or ask the system administrator to assign you.</p>
</div>
<?php else: ?>
<p class="adm-muted">Managing staff for <strong><?php echo htmlspecialchars($adminPharmacyName, ENT_QUOTES, 'UTF-8'); ?></strong> — pharmacists sign in under “Pharmacy” on the main portal.</p>
<?php endif; ?>

<div class="adm-grid cols-2" style="margin-bottom:1rem;">
	<div class="adm-card">
		<h2>Add pharmacy staff</h2>
		<?php if ($adminPharmacyId <= 0): ?>
			<p class="adm-muted">Unavailable until your administrator account is linked to a pharmacy.</p>
		<?php else: ?>
		<p class="adm-muted">Create POS accounts for pharmacists at your location only.</p>
		<form method="post" action="" class="adm-form-grid two">
			<input type="hidden" name="mc_action" value="add_pharmacist">
			<div class="adm-field"><label for="nw_user">Username</label><input id="nw_user" name="username" required maxlength="50" autocomplete="username" pattern="[a-z0-9_.\-]{3,50}"></div>
			<div class="adm-field"><label for="nw_pw">Temporary password</label><input id="nw_pw" name="password" type="password" required minlength="10" autocomplete="new-password"></div>
			<div class="adm-field"><label for="nw_fn">First name</label><input id="nw_fn" name="first_name" required maxlength="80"></div>
			<div class="adm-field"><label for="nw_ln">Last name</label><input id="nw_ln" name="last_name" maxlength="80"></div>
			<div class="adm-field" style="grid-column:1/-1;"><label for="nw_em">Email</label><input id="nw_em" name="email" type="email" maxlength="120"></div>
			<div class="adm-actions"><button type="submit" class="adm-btn">Create staff account</button></div>
		</form>
		<?php endif; ?>
	</div>
	<div class="adm-card">
		<h2><?php echo $editRow ? 'Edit staff #' . (int) $editRow['pharmacist_id'] : 'Select staff member'; ?></h2>
		<?php if (!$editRow): ?>
			<p class="adm-muted">Click <strong>Edit</strong> in the roster to change username, email, password, or status.</p>
		<?php else: ?>
			<form method="post" action="" class="adm-form-grid two">
				<input type="hidden" name="mc_action" value="update_pharmacist">
				<input type="hidden" name="pharmacist_id" value="<?php echo (int) $editRow['pharmacist_id']; ?>">
				<div class="adm-field"><label for="ed_user">Username</label><input id="ed_user" name="username" required maxlength="50" pattern="[a-z0-9_.\-]{3,50}" value="<?php echo htmlspecialchars((string) $editRow['username'], ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field"><label for="ed_pw">New password · optional</label><input id="ed_pw" name="new_password" type="password" minlength="10" autocomplete="new-password"></div>
				<div class="adm-field"><label for="ed_fn">First name</label><input id="ed_fn" name="first_name" required maxlength="80" value="<?php echo htmlspecialchars((string) $editRow['first_name'], ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field"><label for="ed_ln">Last name</label><input id="ed_ln" name="last_name" maxlength="80" value="<?php echo htmlspecialchars((string) ($editRow['last_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field" style="grid-column:1/-1;"><label for="ed_em">Email</label><input id="ed_em" name="email" type="email" maxlength="120" value="<?php echo htmlspecialchars((string) ($editRow['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
				<div class="adm-field" style="grid-column:1/-1;display:flex;align-items:center;gap:.5rem;">
					<label style="margin:0;text-transform:none;display:flex;align-items:center;gap:.35rem;"><input type="checkbox" name="is_active" value="1" <?php echo (int) $editRow['is_active'] === 1 ? ' checked' : ''; ?>> Active (can sign in)</label>
				</div>
				<div class="adm-actions">
					<button type="submit" class="adm-btn">Save changes</button>
					<a class="adm-btn secondary" href="pharmacists.php">Cancel edit</a>
				</div>
			</form>
		<?php endif; ?>
	</div>
</div>

<div class="adm-card">
	<h2>Roster · performance</h2>
	<p class="adm-muted"><strong>Lifetime revenue</strong> ties to sales rows referencing this pharmacist. <strong>30d sales</strong> counts sales in the last thirty days.</p>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead>
				<tr>
					<th>Username</th>
					<th>Name</th>
					<th>Email</th>
					<th>Status</th>
					<th>30d sales</th>
					<th>Lifetime sales</th>
					<th>Revenue ($)</th>
					<th>Last sign-in</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			<?php if (!$rows): ?>
				<tr><td colspan="9" class="adm-muted">No pharmacists registered yet.</td></tr>
			<?php else: ?>
				<?php foreach ($rows as $r): ?>
					<tr>
						<td><?php echo htmlspecialchars((string) $r['username'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars(trim((string) $r['first_name'] . ' ' . ($r['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars((string) ($r['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo ((int) $r['is_active'] === 1) ? '<span style="color:var(--adm-accent);">Active</span>' : '<span style="opacity:.6;">Inactive</span>'; ?></td>
						<td><?php echo (int) $r['sale_cnt_30']; ?></td>
						<td><?php echo (int) $r['sale_cnt']; ?></td>
						<td><?php echo number_format((float) $r['sale_rev'], 2); ?></td>
						<td class="adm-muted"><?php
						$lla = $r['last_login_at'] ?? null;
						echo $lla ? htmlspecialchars((string) $lla, ENT_QUOTES, 'UTF-8') : 'Never';
						?></td>
						<td><a class="adm-out" href="pharmacists.php?edit=<?php echo (int) $r['pharmacist_id']; ?>">Edit</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
<?php mc_admin_shell_end(); ?>
