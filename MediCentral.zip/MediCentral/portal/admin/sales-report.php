<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_admin.php';
require_once dirname(__DIR__) . '/includes/admin_shell.php';

$dto = isset($_GET['date_to']) ? trim((string) $_GET['date_to']) : (new DateTimeImmutable('today'))->format('Y-m-d');
$dfrom = isset($_GET['date_from']) ? trim((string) $_GET['date_from']) : (new DateTimeImmutable($dto))->modify('-30 days')->format('Y-m-d');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dfrom) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dto)) {
	$dto = (new DateTimeImmutable('today'))->format('Y-m-d');
	$dfrom = (new DateTimeImmutable($dto))->modify('-30 days')->format('Y-m-d');
}

$rows = [];

$joinCust = mc_table_has_column($conn, 'mc_sales', 'customer_id');

if ($joinCust) {
	$sql = <<<'SQL'
SELECT s.sale_id, s.sale_at, s.total_amount, s.sale_note, p.username,
  (SELECT COUNT(*) FROM mc_sale_items i WHERE i.sale_id = s.sale_id) AS line_cnt,
  c.first_name AS c_first, c.last_name AS c_last
FROM mc_sales s
LEFT JOIN mc_pharmacists p ON p.pharmacist_id = s.pharmacist_id
LEFT JOIN mc_customers c ON c.customer_id = s.customer_id
WHERE DATE(s.sale_at) >= ? AND DATE(s.sale_at) <= ?
ORDER BY s.sale_at DESC
LIMIT 500
SQL;
} else {
	$sql = <<<'SQL'
SELECT s.sale_id, s.sale_at, s.total_amount, s.sale_note, p.username,
  (SELECT COUNT(*) FROM mc_sale_items i WHERE i.sale_id = s.sale_id) AS line_cnt,
  NULL AS c_first, NULL AS c_last
FROM mc_sales s
LEFT JOIN mc_pharmacists p ON p.pharmacist_id = s.pharmacist_id
WHERE DATE(s.sale_at) >= ? AND DATE(s.sale_at) <= ?
ORDER BY s.sale_at DESC
LIMIT 500
SQL;
}

$stmt = $conn->prepare($sql);
if ($stmt) {
	$stmt->bind_param('ss', $dfrom, $dto);
	$stmt->execute();
	$stmt->bind_result($sid, $sat, $tot, $note, $un, $lc, $cfn0, $cln0);
	while ($stmt->fetch()) {
		$rows[] = [
			'sale_id' => $sid,
			'sale_at' => $sat,
			'total_amount' => $tot,
			'sale_note' => $note,
			'username' => $un,
			'line_cnt' => $lc,
			'cust_name' => trim((string) ($cfn0 ?? '') . ' ' . (string) ($cln0 ?? '')),
		];
	}
	$stmt->close();
}

$sumStmt = $conn->prepare('SELECT COALESCE(SUM(total_amount),0) FROM mc_sales WHERE DATE(sale_at) >= ? AND DATE(sale_at) <= ?');
$rangeTotal = 0.0;
if ($sumStmt) {
	$sumStmt->bind_param('ss', $dfrom, $dto);
	$sumStmt->execute();
	$sumStmt->bind_result($rangeTotal);
	$sumStmt->fetch();
	$sumStmt->close();
}

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
	header('Content-Type: text/csv; charset=UTF-8');
	header('Cache-Control: no-store');
	header(
		'Content-Disposition: attachment; filename="medcentral-sales-' . $dfrom . '_to_' . $dto . '.csv"'
	);
	echo "\xEF\xBB\xBF";
	$fh = fopen('php://output', 'wb');
	if ($fh) {
		fputcsv($fh, ['sale_id', 'sale_at', 'pharmacist_username', 'customer', 'line_items', 'total_usd', 'note']);
		foreach ($rows as $r) {
			fputcsv($fh, [
				(string) ($r['sale_id'] ?? ''),
				(string) ($r['sale_at'] ?? ''),
				$r['username'] !== null ? (string) $r['username'] : '',
				$r['cust_name'] !== '' ? (string) $r['cust_name'] : '',
				(string) ($r['line_cnt'] ?? ''),
				number_format((float) ($r['total_amount'] ?? 0), 2, '.', ''),
				(string) ($r['sale_note'] ?? ''),
			]);
		}
		fclose($fh);
	}
	exit;
}

mc_admin_shell_start('Sales report', 'sales');
?>
<div class="adm-card" style="margin-bottom:1rem;">
	<h2>Filters</h2>
	<form method="get" action="" class="adm-form-grid two" style="max-width:520px;">
		<div class="adm-field"><label for="df">From</label><input id="df" type="date" name="date_from" value="<?php echo htmlspecialchars($dfrom, ENT_QUOTES, 'UTF-8'); ?>"></div>
		<div class="adm-field"><label for="dt">To</label><input id="dt" type="date" name="date_to" value="<?php echo htmlspecialchars($dto, ENT_QUOTES, 'UTF-8'); ?>"></div>
		<div class="adm-actions"><button type="submit" class="adm-btn">Apply</button></div>
	</form>
	<p class="adm-muted" style="margin-top:0.75rem;">Range total: <strong><?php echo '$' . number_format((float) $rangeTotal, 2); ?></strong> (max 500 rows shown). <a class="adm-out" href="?<?php echo http_build_query(['date_from' => $dfrom, 'date_to' => $dto, 'export' => 'csv']); ?>">Download CSV</a></p>
</div>

<div class="adm-card">
	<h2>Transactions</h2>
	<div class="adm-table-wrap">
		<table class="adm-table">
			<thead>
				<tr>
					<th>ID</th>
					<th>When</th>
					<th>Pharmacist</th>
					<th>Customer</th>
					<th>Lines</th>
					<th>Total</th>
					<th>Note</th>
					<th>Invoice</th>
				</tr>
			</thead>
			<tbody>
			<?php if (!$rows): ?>
				<tr><td colspan="8" class="adm-muted">No sales in this range.</td></tr>
			<?php else: ?>
				<?php foreach ($rows as $r): ?>
					<tr>
						<td>#<?php echo (int) $r['sale_id']; ?></td>
						<td><?php echo htmlspecialchars((string) $r['sale_at'], ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars($r['username'] ? (string) $r['username'] : '(unassigned)', ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo htmlspecialchars($r['cust_name'] !== '' ? (string) $r['cust_name'] : '—', ENT_QUOTES, 'UTF-8'); ?></td>
						<td><?php echo (int) $r['line_cnt']; ?></td>
						<td><?php echo '$' . number_format((float) $r['total_amount'], 2); ?></td>
						<td><?php echo htmlspecialchars((string) ($r['sale_note'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
						<td><a class="adm-out" href="sale-detail.php?id=<?php echo (int) $r['sale_id']; ?>">View</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
<?php mc_admin_shell_end(); ?>
