<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 2) . '/includes/require_admin.php';
require_once dirname(__DIR__, 2) . '/includes/inventory_ops.php';

mc_upgrade_inventory_unit_schema($conn);

$code = trim((string) ($_GET['code'] ?? $_POST['code'] ?? ''));
if ($code === '') {
	echo json_encode(['ok' => false, 'error' => 'No code provided.']);
	exit;
}

$drug = mc_inventory_find_by_code($conn, $code);
if ($drug === null) {
	echo json_encode([
		'ok' => true,
		'found' => false,
		'code' => $code,
		'is_barcode' => (bool) preg_match('/^\d{8,14}$/', $code),
	]);
	exit;
}

$unitType = (string) ($drug['unit_type'] ?? 'unit');
echo json_encode([
	'ok' => true,
	'found' => true,
	'drug' => [
		'drug_id' => (int) $drug['drug_id'],
		'name' => (string) $drug['name'],
		'barcode' => (string) ($drug['barcode'] ?? ''),
		'qr_code' => (string) ($drug['qr_code'] ?? ''),
		'category' => (string) ($drug['category'] ?? ''),
		'unit_type' => $unitType,
		'unit_label' => mc_inventory_unit_label($unitType),
		'quantity' => (int) $drug['quantity'],
		'unit_price' => (float) $drug['unit_price'],
		'reorder_level' => (int) ($drug['reorder_level'] ?? 10),
		'expiry_date' => $drug['expiry_date'] ?? null,
	],
], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
