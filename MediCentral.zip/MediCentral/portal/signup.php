<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/username_format.php';
require_once __DIR__ . '/includes/auth_helpers.php';
require_once __DIR__ . '/includes/site_footer.php';

mc_session_start();
mc_auth_redirect_if_logged_in($conn, 'network');

$error = '';
$uname_display = '';
$fn = '';
$ln = '';
$email = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
	$uname = isset($_POST['uname']) ? trim((string) $_POST['uname']) : '';
	$pwd = (string) ($_POST['pwd'] ?? '');
	$pwd2 = (string) ($_POST['pwd2'] ?? '');
	$fn = trim((string) ($_POST['first_name'] ?? ''));
	$ln = trim((string) ($_POST['last_name'] ?? ''));
	$email = trim((string) ($_POST['email'] ?? ''));
	$phone = trim((string) ($_POST['phone'] ?? ''));

	$uname_display = $uname !== '' ? mc_format_signin_username($uname) : '';
	$userNorm = mb_strtolower($uname_display, 'UTF-8');

	if ($userNorm === '' || $fn === '' || $pwd === '' || $pwd2 === '') {
		$error = 'Username, first name, and both password fields are required.';
	} elseif (!preg_match('/^[a-z0-9_.-]{3,50}$/', $userNorm)) {
		$error = 'Username must be 3–50 characters: lowercase letters, numbers, or ._-';
	} elseif (strlen($pwd) < 8) {
		$error = 'Password must be at least 8 characters.';
	} elseif ($pwd !== $pwd2) {
		$error = 'Passwords do not match.';
	} elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$error = 'Enter a valid email address or leave it blank.';
	} elseif (!mc_member_username_available($conn, $userNorm)) {
		$error = 'That username is already taken.';
	} else {
		$mailDb = $email === '' ? null : mb_strtolower($email, 'UTF-8');
		if (!mc_member_email_available($conn, $mailDb)) {
			$error = 'That email is already registered.';
		} else {
			$hash = password_hash($pwd, PASSWORD_DEFAULT);
			$lnDb = $ln === '' ? null : $ln;
			$phDb = $phone === '' ? null : $phone;
			$stmt = $conn->prepare(
				'INSERT INTO mc_members (username, password_hash, first_name, last_name, email, phone, is_active) VALUES (?,?,?,?,?,?,1)'
			);
			if ($stmt && $stmt->bind_param(
				'ssssss',
				$userNorm,
				$hash,
				$fn,
				$lnDb,
				$mailDb,
				$phDb
			) && $stmt->execute()) {
				$mid = (int) $conn->insert_id;
				$stmt->close();
				mc_start_member_session($mid, $userNorm);
				mc_touch_member_login($conn, $mid);
				header('Location: member/index.php');
				exit;
			}
			$error = 'Registration failed. Try again in a moment.';
			if ($stmt) {
				$stmt->close();
			}
		}
	}
}

$alertClass = $error !== '' ? 'mc-alert mc-show' : 'mc-alert';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Create account · MediCentral</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700;1,9..40,400..700&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/signin.css">
</head>
<body>
	<div class="mc-backdrop" aria-hidden="true">
		<div class="mc-grid"></div>
		<div class="mc-orbits">
			<div class="mc-orbit"></div>
			<div class="mc-orbit"></div>
			<div class="mc-orbit"></div>
		</div>
	</div>

	<div class="mc-wrap">
		<section class="mc-panel-brand">
			<div class="mc-badge"><span class="mc-badge-dot" aria-hidden="true"></span> Centralized pharmacy network</div>
			<h1 class="mc-headline">Join MediCentral — <span>search, order, connect.</span></h1>
			<p class="mc-blurb">One member account links you to partner pharmacies for medicine discovery, availability checks, and coordinated ordering across the network.</p>
			<div class="mc-stats">
				<div class="mc-stat"><strong>Network</strong><span>Multi-pharmacy</span></div>
				<div class="mc-stat"><strong>Search</strong><span>Drug catalogue</span></div>
				<div class="mc-stat"><strong>Orders</strong><span>Coming next</span></div>
			</div>
		</section>

		<div class="mc-signin-shell">
			<div class="mc-signin-card mc-signin-card-wide">
				<form method="post" action="" autocomplete="on">
					<div class="mc-logo-row">
						<div style="display:flex;align-items:center;gap:0.95rem;">
							<div class="mc-logo-mark" aria-hidden="true">
								<svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
									<path d="M10 17V9l6-4 6 4v8c0 4-6 10-6 10S10 21 10 17z" stroke="currentColor" stroke-width="1.85" stroke-linejoin="round"/>
									<path d="M16 13v10" stroke="currentColor" stroke-width="1.85" stroke-linecap="round"/>
									<path d="M12 17h8" stroke="currentColor" stroke-width="1.85" stroke-linecap="round"/>
								</svg>
							</div>
							<div class="mc-logo-text">
								<h2>MediCentral</h2>
								<p>Centralized pharmacy platform</p>
							</div>
						</div>
					</div>

					<h3 class="mc-title" style="margin-top:1.25rem;">Create your member account</h3>
					<p class="mc-sub">Pharmacy staff and administrators are provisioned separately. This registration is for patients, caregivers, and members who use the network.</p>

					<div id="signup-alert" class="<?php echo htmlspecialchars($alertClass, ENT_QUOTES, 'UTF-8'); ?>" role="<?php echo $error !== '' ? 'alert' : 'presentation'; ?>">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v5M12 16h0"/></svg>
						<span><?php echo $error !== '' ? htmlspecialchars($error, ENT_QUOTES, 'UTF-8') : ''; ?></span>
					</div>

					<div class="mc-form-grid two">
						<div class="mc-field"><input type="text" name="first_name" id="first_name" required maxlength="80" value="<?php echo htmlspecialchars($fn, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="given-name"><label class="mc-float-label" for="first_name">First name</label></div>
						<div class="mc-field"><input type="text" name="last_name" id="last_name" maxlength="80" value="<?php echo htmlspecialchars($ln, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="family-name"><label class="mc-float-label" for="last_name">Last name</label></div>
					</div>

					<div class="mc-field">
						<input type="text" name="uname" id="uname" required maxlength="50" value="<?php echo htmlspecialchars($uname_display, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="username" autocapitalize="words" spellcheck="false">
						<label class="mc-float-label" for="uname">Username</label>
					</div>

					<div class="mc-field">
						<input type="email" name="email" id="email" maxlength="120" value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="email">
						<label class="mc-float-label" for="email">Email · optional</label>
					</div>

					<div class="mc-field">
						<input type="tel" name="phone" id="phone" maxlength="40" value="<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="tel">
						<label class="mc-float-label" for="phone">Phone · optional</label>
					</div>

					<div class="mc-field mc-pw">
						<input type="password" name="pwd" id="pwd" required minlength="8" autocomplete="new-password">
						<label class="mc-float-label" for="pwd">Password</label>
						<button type="button" class="mc-toggle-eye" data-target="pwd" aria-label="Show password">
							<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="12" rx="10" ry="6"/><circle cx="12" cy="12" r="2.5"/><path d="M2 12h2m16 0h2"/></svg>
						</button>
					</div>

					<div class="mc-field mc-pw">
						<input type="password" name="pwd2" id="pwd2" required minlength="8" autocomplete="new-password">
						<label class="mc-float-label" for="pwd2">Confirm password</label>
						<button type="button" class="mc-toggle-eye" data-target="pwd2" aria-label="Show password">
							<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="12" rx="10" ry="6"/><circle cx="12" cy="12" r="2.5"/><path d="M2 12h2m16 0h2"/></svg>
						</button>
					</div>

					<button type="submit" name="register" value="1" class="mc-btn">Create account &amp; continue</button>
				</form>

				<p class="mc-mini-link">Already have an account? <a href="index.php">Sign in</a></p>
				<p class="mc-foot">By registering you agree to use MediCentral for lawful pharmacy-related requests only.</p>
			</div>
		</div>
	</div>

	<?php mc_render_site_footer(); ?>

	<script src="js/signin.js" defer></script>
</body>
</html>
