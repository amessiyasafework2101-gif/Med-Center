(function () {
	'use strict';

	var form = document.querySelector('.mc-pay-form');
	if (!form) {
		return;
	}
	var input = form.querySelector('#telebirr_transaction_id');
	var btn = document.getElementById('mc-telebirr-check');
	var box = document.getElementById('mc-telebirr-verify-result');
	if (!input || !btn || !box) {
		return;
	}

	btn.addEventListener('click', function () {
		var tx = (input.value || '').trim();
		if (tx.length < 6) {
			box.hidden = false;
			box.className = 'mc-tx-verify mc-tx-verify--warn';
			box.textContent = 'Enter at least 6 characters from your Tele Birr SMS or receipt.';
			return;
		}
		var orderId = form.querySelector('input[name="order_id"]');
		btn.disabled = true;
		box.hidden = false;
		box.className = 'mc-tx-verify mc-tx-verify--pending';
		box.textContent = 'Dr. Aklilu is checking this transaction ID…';

		var body = new FormData();
		body.append('order_id', orderId ? orderId.value : '');
		body.append('telebirr_transaction_id', tx);

		fetch('../api/verify-telebirr.php', { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (r) {
				return r.json();
			})
			.then(function (data) {
				btn.disabled = false;
				if (!data || data.error) {
					box.className = 'mc-tx-verify mc-tx-verify--warn';
					box.textContent = (data && data.error) ? data.error : 'Could not verify. Try again.';
					return;
				}
				var cls = 'mc-tx-verify';
				if (data.verdict === 'likely_valid') {
					cls += ' mc-tx-verify--ok';
				} else if (data.verdict === 'uncertain') {
					cls += ' mc-tx-verify--warn';
				} else {
					cls += ' mc-tx-verify--bad';
				}
				box.className = cls;
				var line = data.label ? data.label + ': ' : '';
				line += data.msg || data.ai_note || '';
				if (data.ai_used) {
					line += ' (checked by Dr. Aklilu)';
				}
				box.textContent = line;
			})
			.catch(function () {
				btn.disabled = false;
				box.className = 'mc-tx-verify mc-tx-verify--warn';
				box.textContent = 'Network error. You can still submit — the pharmacy will verify payment.';
			});
	});
})();
