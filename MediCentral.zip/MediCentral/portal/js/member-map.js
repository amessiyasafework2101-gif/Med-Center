(function () {
  var cfg = window.MC_MAP_CFG || {};
  var map = null;
  var userMarker = null;
  var markers = [];
  var googleMarkers = [];
  var userPos = null;
  var dbMarkers = [];

  function status(msg) {
    var el = document.getElementById("mapStatus");
    if (el) el.textContent = msg;
  }

  function showMembers() {
    var el = document.getElementById("filterMembers");
    return !el || el.checked;
  }

  function showOthers() {
    var el = document.getElementById("filterOthers");
    return !el || el.checked;
  }

  function radiusM() {
    var sel = document.getElementById("radiusKm");
    return sel ? parseInt(sel.value, 10) : 3000;
  }

  function distKm(a, b) {
    var R = 6371;
    var dLat = ((b.lat - a.lat) * Math.PI) / 180;
    var dLng = ((b.lng - a.lng) * Math.PI) / 180;
    var x =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((a.lat * Math.PI) / 180) *
        Math.cos((b.lat * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  }

  function clearMapMarkers() {
    markers.forEach(function (m) {
      m.setMap(null);
    });
    markers = [];
    googleMarkers.forEach(function (m) {
      m.setMap(null);
    });
    googleMarkers = [];
  }

  function markerIcon(isMember) {
    return {
      path: google.maps.SymbolPath.CIRCLE,
      scale: 10,
      fillColor: isMember ? "#12c2a8" : "#8b9bb4",
      fillOpacity: 1,
      strokeColor: "#ffffff",
      strokeWeight: 2,
    };
  }

  function renderList(list) {
    var box = document.getElementById("mapList");
    if (!box) return;
    if (!list.length) {
      box.innerHTML = '<p class="mc-hub-muted">No pharmacies match your filters.</p>';
      return;
    }
    var html = "";
    list.slice(0, 40).forEach(function (item, idx) {
      var badge = item.is_member
        ? '<span class="mc-map-list-badge member">Member</span>'
        : '<span class="mc-map-list-badge other">Not on network</span>';
      var dist =
        item.distance_km != null
          ? '<span class="mc-map-list-dist">' + item.distance_km.toFixed(2) + " km</span>"
          : "";
      var actions = "";
      if (item.is_member && item.profile_url) {
        actions =
          '<a href="' +
          item.profile_url +
          '">Profile</a> · <a href="' +
          (item.order_url || "search.php") +
          '">Order</a>';
      }
      html +=
        '<button type="button" class="mc-map-list-item" data-idx="' +
        idx +
        '">' +
        badge +
        "<strong>" +
        escapeHtml(item.name) +
        "</strong>" +
        '<span class="mc-map-list-addr">' +
        escapeHtml(item.address || "") +
        "</span>" +
        dist +
        (actions ? '<span class="mc-map-list-actions">' + actions + "</span>" : "") +
        "</button>";
    });
    box.innerHTML = html;
    box.querySelectorAll(".mc-map-list-item").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var i = parseInt(btn.getAttribute("data-idx"), 10);
        var item = list[i];
        if (item && map) {
          map.panTo({ lat: item.lat, lng: item.lng });
          map.setZoom(16);
        }
      });
    });
  }

  function escapeHtml(s) {
    var d = document.createElement("d" + "iv");
    d.textContent = s;
    return d.innerHTML;
  }

  function getVisibleMarkers() {
    var out = [];
    dbMarkers.forEach(function (m) {
      if (m.is_member && !showMembers()) return;
      if (!m.is_member && !showOthers()) return;
      out.push(m);
    });
    return out;
  }

  function paintMarkers() {
    if (!map || !window.google) return;
    clearMapMarkers();
    var list = getVisibleMarkers();
    list.forEach(function (item) {
      var m = new google.maps.Marker({
        position: { lat: item.lat, lng: item.lng },
        map: map,
        title: item.name,
        icon: markerIcon(item.is_member),
      });
      var info = new google.maps.InfoWindow({
        content:
          "<strong>" +
          escapeHtml(item.name) +
          "</strong><br>" +
          (item.is_member ? "<em>MediCentral member</em><br>" : "<em>Not on network</em><br>") +
          escapeHtml(item.address || "") +
          (item.phone ? "<br>" + escapeHtml(item.phone) : "") +
          (item.is_member && item.order_url
            ? '<br><a href="' + item.order_url + '">Order from here</a>'
            : ""),
      });
      m.addListener("click", function () {
        info.open(map, m);
      });
      markers.push(m);
    });
    if (userPos) {
      list.forEach(function (item) {
        item.distance_km = distKm(userPos, { lat: item.lat, lng: item.lng });
      });
      list.sort(function (a, b) {
        return (a.distance_km || 0) - (b.distance_km || 0);
      });
    }
    renderList(list);
    status(list.length + " pharmacies on map");
  }

  function loadDbMarkers() {
    var url = cfg.markersUrl || "map-markers.php";
    if (userPos) {
      url += "?lat=" + userPos.lat + "&lng=" + userPos.lng;
    }
    return fetch(url, { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        dbMarkers = data.markers || [];
        paintMarkers();
        return data;
      });
  }

  function searchGooglePlaces() {
    if (!map || !window.google || !google.maps.places || !userPos) return;
    var service = new google.maps.places.PlacesService(map);
    var req = {
      location: new google.maps.LatLng(userPos.lat, userPos.lng),
      radius: radiusM(),
      type: "pharmacy",
    };
    service.nearbySearch(req, function (results, placesStatus) {
      if (placesStatus !== google.maps.places.PlacesServiceStatus.OK || !results) {
        return;
      }
      results.forEach(function (place) {
        if (!place.geometry || !place.geometry.location) return;
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        var dup = dbMarkers.some(function (d) {
          return distKm({ lat: lat, lng: lng }, { lat: d.lat, lng: d.lng }) < 0.05;
        });
        if (dup) return;
        if (!showOthers()) return;
        var m = new google.maps.Marker({
          position: { lat: lat, lng: lng },
          map: map,
          title: place.name,
          icon: markerIcon(false),
        });
        var info = new google.maps.InfoWindow({
          content:
            "<strong>" +
            escapeHtml(place.name || "Pharmacy") +
            "</strong><br><em>Google · not on MediCentral</em><br>" +
            escapeHtml(place.vicinity || ""),
        });
        m.addListener("click", function () {
          info.open(map, m);
        });
        googleMarkers.push(m);
      });
      status(getVisibleMarkers().length + " network + " + googleMarkers.length + " from Google");
    });
  }

  function setUserLocation(lat, lng) {
    userPos = { lat: lat, lng: lng };
    if (!map) return;
    if (userMarker) userMarker.setMap(null);
    userMarker = new google.maps.Marker({
      position: userPos,
      map: map,
      title: "You are here",
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 7,
        fillColor: "#fbbf24",
        fillOpacity: 1,
        strokeColor: "#fff",
        strokeWeight: 2,
      },
    });
    map.panTo(userPos);
    map.setZoom(14);
    loadDbMarkers().then(function () {
      searchGooglePlaces();
    });
  }

  function bindControls() {
    var btn = document.getElementById("btnMyLocation");
    if (btn) {
      btn.addEventListener("click", function () {
        if (!navigator.geolocation) {
          status("Geolocation not supported in this browser.");
          return;
        }
        status("Getting your location…");
        navigator.geolocation.getCurrentPosition(
          function (pos) {
            setUserLocation(pos.coords.latitude, pos.coords.longitude);
          },
          function () {
            status("Could not get location — allow GPS or pick on map.");
          },
          { enableHighAccuracy: true, timeout: 12000 }
        );
      });
    }
    ["filterMembers", "filterOthers", "radiusKm"].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.addEventListener("change", function () {
          paintMarkers();
          if (showOthers() && userPos) searchGooglePlaces();
          else {
            googleMarkers.forEach(function (m) {
              m.setMap(null);
            });
            googleMarkers = [];
          }
        });
      }
    });
  }

  window.mcMapInit = function () {
    var canvas = document.getElementById("mapCanvas");
    if (!canvas || !window.google) {
      status("Map unavailable.");
      return;
    }
    var center = cfg.defaultCenter || { lat: 9.032, lng: 38.747 };
    map = new google.maps.Map(canvas, {
      center: center,
      zoom: cfg.defaultZoom || 13,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: true,
      styles: [
        { elementType: "geometry", stylers: [{ color: "#0a1628" }] },
        { elementType: "labels.text.fill", stylers: [{ color: "#8b9bb4" }] },
        { featureType: "road", elementType: "geometry", stylers: [{ color: "#1a2a44" }] },
        { featureType: "water", elementType: "geometry", stylers: [{ color: "#040b14" }] },
      ],
    });
    bindControls();
    loadDbMarkers();
    status("Map ready — use my location to find nearest pharmacies.");
  };

  if (window.google && window.google.maps) {
    window.mcMapInit();
  }
})();
