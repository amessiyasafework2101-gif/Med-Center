(function () {
  const root = document.getElementById("drAklilu");
  if (!root) return;

  const mode = root.dataset.mode || "widget";
  const portal = root.dataset.portal || "network";
  const apiUrl = root.dataset.api || "../api/dr-aklilu.php";
  const configured = root.dataset.configured === "1";
  const isPage = mode === "page";

  const fab = document.getElementById("drAkliluFab");
  const panel = document.getElementById("drAkliluPanel");
  const closeBtn = document.getElementById("drAkliluClose");
  const log = document.getElementById("drAkliluLog");
  const form = document.getElementById("drAkliluForm");
  const input = document.getElementById("drAkliluInput");
  const resetBtn = document.getElementById("drAkliluReset");
  const cvText = document.getElementById("drAkliluCvText");
  const cvFile = document.getElementById("drAkliluCvFile");
  const chips = document.getElementById("drAkliluChips");

  function formatText(text, who) {
    if (who === "bot" && typeof formatDrAkliluText === "function") {
      return formatDrAkliluText(text);
    }
    const p = document.createElement("p");
    p.textContent = text;
    return p.outerHTML;
  }

  function appendMsg(text, who) {
    const div = document.createElement("div");
    div.className = "dr-ak-msg dr-ak-" + (who === "user" ? "user" : "bot");
    const body = document.createElement("div");
    body.className = "dr-ak-body";
    body.innerHTML = formatText(text, who);
    div.appendChild(body);
    log.appendChild(div);
    scrollLogToBottom(true);
  }

  function scrollLogToBottom(smooth) {
    if (!log) return;
    if (smooth && log.scrollTo) {
      log.scrollTo({ top: log.scrollHeight, behavior: "smooth" });
    } else {
      log.scrollTop = log.scrollHeight;
    }
  }

  function setOpen(open) {
    if (!panel || isPage) return;
    panel.hidden = !open;
    if (fab) fab.setAttribute("aria-expanded", open ? "true" : "false");
  }

  if (fab) {
    fab.addEventListener("click", function () {
      setOpen(panel.hidden);
    });
  }
  if (closeBtn) {
    closeBtn.addEventListener("click", function () {
      setOpen(false);
    });
  }

  if (isPage) {
    setOpen(true);
    document.body.classList.add("dr-ak-page-active");
  }

  if (chips) {
    chips.addEventListener("click", function (e) {
      const btn = e.target.closest(".dr-ak-chip");
      if (!btn || !input) return;
      const prompt = btn.getAttribute("data-prompt") || "";
      if (prompt) {
        input.value = prompt;
        input.focus();
      }
    });
  }

  async function post(body) {
    const res = await fetch(apiUrl, { method: "POST", body: body, credentials: "same-origin" });
    const text = await res.text();
    let data;
    try {
      data = text ? JSON.parse(text) : {};
    } catch (parseErr) {
      const snippet = text.replace(/\s+/g, " ").trim().slice(0, 160);
      throw new Error(
        res.ok
          ? "Invalid server response."
          : "Server error (" + res.status + ")" + (snippet ? ": " + snippet : "")
      );
    }
    if (!res.ok && !data.error) {
      data.error = "Request failed (HTTP " + res.status + ").";
      data.ok = false;
    }
    return data;
  }

  async function sendMessage(msg) {
    if (!configured || !msg) return;

    appendMsg(msg, "user");
    input.disabled = true;

    const typing = document.createElement("div");
    typing.className = "dr-ak-msg dr-ak-bot dr-ak-typing";
    typing.innerHTML =
      '<div class="dr-ak-body"><p><span class="dr-ak-dots" aria-hidden="true"></span> Dr. Aklilu is thinking…</p></div>';
    log.appendChild(typing);
    scrollLogToBottom(true);

    const fd = new FormData();
    fd.append("action", "chat");
    fd.append("portal", portal);
    fd.append("message", msg);
    if (cvText && cvText.value.trim()) {
      fd.append("cv_text", cvText.value.trim());
    }
    if (cvFile && cvFile.files && cvFile.files[0]) {
      fd.append("cv_file", cvFile.files[0]);
    }

    try {
      const data = await post(fd);
      typing.remove();
      if (data.ok && data.reply) {
        appendMsg(data.reply, "bot");
      } else {
        appendMsg(data.error || "Something went wrong. Please try again.", "bot");
      }
    } catch (err) {
      typing.remove();
      const errMsg =
        err && err.message
          ? err.message
          : "Could not reach Dr. Aklilu. Check your connection and API key.";
      appendMsg(errMsg, "bot");
    }

    input.disabled = false;
    input.focus();
  }

  if (resetBtn) {
    resetBtn.addEventListener("click", async function () {
      if (!configured) return;
      const fd = new FormData();
      fd.append("action", "reset");
      fd.append("portal", portal);
      await post(fd);
      log.innerHTML =
        '<div class="dr-ak-msg dr-ak-bot"><div class="dr-ak-body"><p>Conversation reset. How can I help you today?</p></div></div>';
    });
  }

  if (form) {
    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      if (!configured) return;
      const msg = (input.value || "").trim();
      if (!msg) return;
      input.value = "";
      await sendMessage(msg);
    });
  }
})();
