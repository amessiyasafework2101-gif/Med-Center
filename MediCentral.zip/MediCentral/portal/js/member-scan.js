(function () {
  var readerDiv = document.getElementById("member-scanner");
  var statusEl = document.getElementById("scanStatus");
  var codeInput = document.getElementById("code");
  var btnStart = document.getElementById("btnScanStart");
  var btnStop = document.getElementById("btnScanStop");
  if (!readerDiv || !statusEl || !codeInput || !btnStart || !btnStop) {
    return;
  }

  var scanner = null;
  var running = false;
  var lastCode = "";

  function goLookup(text) {
    var t = (text || "").trim();
    if (!t || t === lastCode) {
      return;
    }
    lastCode = t;
    statusEl.textContent = "Code captured — loading product…";
    window.location.href = "scan.php?code=" + encodeURIComponent(t);
  }

  btnStart.addEventListener("click", function () {
    if (running || !window.Html5Qrcode) {
      statusEl.textContent = "Scanner library unavailable — enter the code manually.";
      return;
    }
    scanner = new Html5Qrcode("member-scanner");
    scanner
      .start(
        { facingMode: "environment" },
        { fps: 8, qrbox: { width: 250, height: 150 } },
        function (decoded) {
          goLookup(decoded);
        },
        function () {}
      )
      .then(function () {
        running = true;
        statusEl.textContent = "Scanning… point at the barcode or QR on the package.";
      })
      .catch(function () {
        statusEl.textContent = "Camera failed — allow camera access or type the code below.";
      });
  });

  btnStop.addEventListener("click", function () {
    if (!scanner || !running) {
      return;
    }
    scanner.stop().then(function () {
      running = false;
      scanner.clear();
      statusEl.textContent = "Scanner stopped.";
    });
  });
})();
