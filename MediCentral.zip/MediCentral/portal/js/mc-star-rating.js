(function () {
  function initPicker(root) {
    var input = root.querySelector(".mc-star-picker-value");
    var stars = root.querySelectorAll(".mc-star-pick");
    if (!input || !stars.length) return;

    function setVal(v, hoverOnly) {
      stars.forEach(function (btn) {
        var n = parseInt(btn.getAttribute("data-value"), 10);
        btn.classList.toggle("is-on", !hoverOnly && n <= v);
        btn.classList.toggle("is-hover", hoverOnly && n <= v);
      });
      if (!hoverOnly) input.value = String(v);
    }

    var current = parseInt(input.value, 10) || 0;
    if (current > 0) setVal(current, false);

    stars.forEach(function (btn) {
      btn.addEventListener("click", function () {
        setVal(parseInt(btn.getAttribute("data-value"), 10), false);
      });
      btn.addEventListener("mouseenter", function () {
        setVal(parseInt(btn.getAttribute("data-value"), 10), true);
      });
    });
    root.addEventListener("mouseleave", function () {
      var c = parseInt(input.value, 10) || 0;
      stars.forEach(function (btn) {
        btn.classList.remove("is-hover");
        var n = parseInt(btn.getAttribute("data-value"), 10);
        btn.classList.toggle("is-on", c > 0 && n <= c);
      });
    });
  }

  document.querySelectorAll(".mc-star-picker").forEach(initPicker);

  var thread = document.getElementById("mcChatThread");
  if (thread) {
    thread.scrollTop = thread.scrollHeight;
  }
})();
