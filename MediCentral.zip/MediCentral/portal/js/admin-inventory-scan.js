(function () {
  var readerDiv = document.getElementById("inventory-reader");
  var statusEl = document.getElementById("scanStatus");
  var bcInput = document.getElementById("f_bc");
  var qrInput = document.getElementById("f_qr");
  var unitSelect = document.getElementById("f_unit");
  var qtyUnitLbl = document.querySelector(".f-qty-unit-lbl");
  var receiveCode = document.getElementById("receive_code");
  var receiveDisplay = document.getElementById("receive_code_display");
  var receiveQty = document.getElementById("receive_qty");
  var receiveHint = document.getElementById("receive_unit_hint");
  var receiveResult = document.getElementById("receiveLookupResult");
  var btnReceive = document.getElementById("btnReceiveStock");
  var btnLookup = document.getElementById("btnLookupCode");
  var scanner = null;
  var running = false;

  var unitLabels = {
    tablet: "tablets",
    capsule: "capsules",
    bottle: "bottles",
    vial: "vials",
    strip: "strips",
    box: "boxes",
    unit: "units",
  };

  function unitLabel(type) {
    return unitLabels[type] || "units";
  }

  function updateQtyLabels() {
    if (!unitSelect) return;
    var lbl = unitLabel(unitSelect.value);
    document.querySelectorAll(".f-qty-unit-lbl").forEach(function (el) {
      el.textContent = lbl;
    });
    if (receiveHint) receiveHint.textContent = lbl;
  }

  if (unitSelect) {
    unitSelect.addEventListener("change", updateQtyLabels);
    updateQtyLabels();
  }

  function applyCode(text) {
    if (!text) return;
    text = text.trim();
    if (receiveCode) receiveCode.value = text;
    if (receiveDisplay) receiveDisplay.value = text;
    if (bcInput && qrInput) {
      if (/^https?:\/\//i.test(text) || text.length > 32) {
        qrInput.value = text;
        if (statusEl) statusEl.textContent = "QR captured.";
      } else if (/^\d{8,14}$/.test(text)) {
        bcInput.value = text;
        if (statusEl) statusEl.textContent = "Barcode captured.";
      } else {
        bcInput.value = text;
        if (statusEl) statusEl.textContent = "Code captured.";
      }
    }
    if (btnLookup) lookupProduct(text);
  }

  function lookupProduct(code) {
    if (!code || !receiveResult) return;
    receiveResult.hidden = false;
    receiveResult.textContent = "Looking up…";
    if (btnReceive) btnReceive.disabled = true;
    fetch("api/inventory-lookup.php?code=" + encodeURIComponent(code), {
      credentials: "same-origin",
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (!data.ok) {
          receiveResult.textContent = data.error || "Lookup failed.";
          return;
        }
        if (!data.found) {
          receiveResult.innerHTML =
            '<strong>Not registered.</strong> Add this product below with barcode/QR filled, then receive stock.';
          return;
        }
        var d = data.drug;
        if (receiveHint) receiveHint.textContent = d.unit_label;
        receiveResult.innerHTML =
          "<strong>" +
          escapeHtml(d.name) +
          "</strong> — " +
          d.quantity +
          " " +
          escapeHtml(d.unit_label) +
          " on hand · ETB " +
          Number(d.unit_price).toFixed(2) +
          " each";
        if (btnReceive) btnReceive.disabled = false;
      })
      .catch(function () {
        receiveResult.textContent = "Network error during lookup.";
      });
  }

  function escapeHtml(s) {
    var d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  if (btnLookup) {
    btnLookup.addEventListener("click", function () {
      var code =
        (receiveDisplay && receiveDisplay.value.trim()) ||
        (receiveCode && receiveCode.value.trim()) ||
        "";
      if (!code) {
        alert("Scan or enter a code first.");
        return;
      }
      applyCode(code);
    });
  }

  if (receiveDisplay) {
    receiveDisplay.addEventListener("keydown", function (ev) {
      if (ev.key === "Enter") {
        ev.preventDefault();
        applyCode(receiveDisplay.value.trim());
      }
    });
  }

  var btnStart = document.getElementById("btnScanStart");
  var btnStop = document.getElementById("btnScanStop");
  if (btnStart) {
    btnStart.addEventListener("click", function () {
      if (running || !readerDiv || !window.Html5Qrcode) {
        if (statusEl)
          statusEl.textContent = "Scanner unavailable — type codes manually.";
        return;
      }
      scanner = new Html5Qrcode("inventory-reader");
      scanner
        .start(
          { facingMode: "environment" },
          { fps: 8, qrbox: { width: 250, height: 150 } },
          function (decoded) {
            applyCode(decoded);
          },
          function () {}
        )
        .then(function () {
          running = true;
          if (statusEl) statusEl.textContent = "Scanning…";
        })
        .catch(function () {
          if (statusEl) statusEl.textContent = "Camera failed.";
        });
    });
  }
  if (btnStop) {
    btnStop.addEventListener("click", function () {
      if (scanner && running) {
        scanner.stop().then(function () {
          running = false;
          scanner.clear();
          if (statusEl) statusEl.textContent = "Scanner stopped.";
        });
      }
    });
  }
})();
