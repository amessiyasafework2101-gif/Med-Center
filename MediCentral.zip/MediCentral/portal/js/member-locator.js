document.addEventListener("DOMContentLoaded", async function () {
  var data = window.MC_LOCATOR_DATA;
  if (!data || !data.configuration) return;

  var locatorEl = document.querySelector("gmpx-store-locator");
  if (!locatorEl) return;

  await customElements.whenDefined("gmpx-store-locator");

  function showMembers() {
    var el = document.getElementById("filterMembers");
    return !el || el.checked;
  }

  function showOthers() {
    var el = document.getElementById("filterOthers");
    return !el || el.checked;
  }

  function filteredLocations() {
    var catalog = data.catalog || [];
    return catalog
      .filter(function (row) {
        if (row.is_member && showMembers()) return true;
        if (!row.is_member && showOthers()) return true;
        return false;
      })
      .map(function (row) {
        return row.locator;
      });
  }

  function applyConfiguration() {
    var cfg = Object.assign({}, data.configuration, {
      locations: filteredLocations(),
    });
    locatorEl.configureFromQuickBuilder(cfg);
    var status = document.getElementById("locatorStatus");
    if (status) {
      status.textContent =
        cfg.locations.length +
        " location" +
        (cfg.locations.length === 1 ? "" : "s") +
        " on map";
    }
  }

  ["filterMembers", "filterOthers"].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener("change", applyConfiguration);
  });

  applyConfiguration();
});
