(function () {
  "use strict";

  function formatSigninUsername(raw) {
    var s = (raw || "").trim();
    if (!s) return "";
    s = s.toLowerCase();

    function capSegment(seg) {
      if (!seg) return "";
      return seg.charAt(0).toUpperCase() + seg.slice(1);
    }

    return s.replace(/(^|[\s._-])([^\s._-]+)/g, function (_m, delim, seg) {
      return delim + capSegment(seg);
    });
  }

  var pwd = document.getElementById("pwd");
  var unameInput = document.getElementById("uname");
  var unameWrap = unameInput ? unameInput.closest(".mc-field") : null;
  var formEl = document.querySelector(".mc-signin-card form");

  if (unameInput) {
    function syncUnameFill() {
      if (unameWrap) {
        unameWrap.classList.toggle("mc-filled", unameInput.value.trim().length > 0);
      }
    }

    unameInput.addEventListener("blur", function () {
      var v = unameInput.value;
      var formatted = formatSigninUsername(v);
      if (formatted !== v) {
        unameInput.value = formatted;
      }
      syncUnameFill();
    });

    unameInput.addEventListener("input", syncUnameFill);

    if (formEl) {
      formEl.addEventListener("submit", function () {
        unameInput.value = formatSigninUsername(unameInput.value);
      });
    }

    syncUnameFill();
  }

  document.querySelectorAll(".mc-field").forEach(function (wrap) {
    var inp = wrap.querySelector("input");
    if (!inp) return;
    if (inp.id === "uname") return;

    function sync() {
      var has =
        inp.type === "password"
          ? inp.value.length > 0
          : inp.value.trim().length > 0;
      wrap.classList.toggle("mc-filled", has);
    }

    inp.addEventListener("input", sync);
    inp.addEventListener("blur", sync);
    sync();
  });

  document.querySelectorAll(".mc-toggle-eye").forEach(function (eyeBtn) {
    var targetId = eyeBtn.getAttribute("data-target");
    var target = targetId ? document.getElementById(targetId) : pwd;
    if (!target) return;

    eyeBtn.addEventListener("click", function () {
      var isPwd = target.getAttribute("type") === "password";
      target.setAttribute("type", isPwd ? "text" : "password");
      eyeBtn.setAttribute("aria-label", isPwd ? "Hide password" : "Show password");
      eyeBtn.innerHTML = isPwd
        ? '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3l18 18"/><path d="M10.584 10.587a2 2 0 004.223 4.219"/><path d="M14.362 14.369C13.814 14.754 13.154 14.98 12.466 14.98 10.764 14.98 9.386 13.598 9.386 11.892c0-.685.229-1.342.613-1.886"/><path d="M9.88 9.88a9.881 9.881 0 0111.942 11.943"/></svg>'
        : '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="12" rx="10" ry="6"/><circle cx="12" cy="12" r="2.5"/><path d="M2 12h2m16 0h2"/></svg>';
    });
  });
})();
