/**
 * Safe, lightweight formatting for Dr. Aklilu replies (no external markdown lib).
 */
(function (global) {
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function inlineFormat(s) {
    let out = escapeHtml(s);
    out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
    out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    out = out.replace(/\*([^*]+)\*/g, "<em>$1</em>");
    return out;
  }

  function isBullet(line) {
    return /^[\s]*[-*•]\s+/.test(line);
  }

  function isNumbered(line) {
    return /^[\s]*\d+[.)]\s+/.test(line);
  }

  function bulletContent(line) {
    return inlineFormat(line.replace(/^[\s]*[-*•]\s+/, ""));
  }

  function numberedContent(line) {
    return inlineFormat(line.replace(/^[\s]*\d+[.)]\s+/, ""));
  }

  function formatDrAkliluText(raw) {
    if (!raw || typeof raw !== "string") return "";
    const blocks = raw.replace(/\r\n/g, "\n").split(/\n\n+/);
    const html = [];

    blocks.forEach(function (block) {
      const lines = block.split("\n").map(function (l) {
        return l.trimEnd();
      });
      const trimmed = lines.map(function (l) {
        return l.trim();
      });
      if (trimmed.every(function (l) {
        return l === "";
      })) {
        return;
      }

      if (trimmed[0].startsWith("### ")) {
        html.push("<h4 class=\"dr-ak-h\">" + inlineFormat(trimmed[0].slice(4)) + "</h4>");
        trimmed.slice(1).forEach(function (l) {
          if (l) html.push("<p>" + inlineFormat(l) + "</p>");
        });
        return;
      }
      if (trimmed[0].startsWith("## ")) {
        html.push("<h3 class=\"dr-ak-h\">" + inlineFormat(trimmed[0].slice(3)) + "</h3>");
        trimmed.slice(1).forEach(function (l) {
          if (l) html.push("<p>" + inlineFormat(l) + "</p>");
        });
        return;
      }
      if (trimmed[0].startsWith("# ")) {
        html.push("<h3 class=\"dr-ak-h\">" + inlineFormat(trimmed[0].slice(2)) + "</h3>");
        trimmed.slice(1).forEach(function (l) {
          if (l) html.push("<p>" + inlineFormat(l) + "</p>");
        });
        return;
      }
      if (trimmed[0].startsWith("> ")) {
        html.push(
          "<blockquote class=\"dr-ak-quote\">" +
            inlineFormat(trimmed.map(function (l) {
              return l.replace(/^>\s?/, "");
            }).join(" ")) +
            "</blockquote>"
        );
        return;
      }
      if (trimmed.every(isBullet)) {
        html.push("<ul class=\"dr-ak-list\">");
        trimmed.forEach(function (l) {
          html.push("<li>" + bulletContent(l) + "</li>");
        });
        html.push("</ul>");
        return;
      }
      if (trimmed.every(isNumbered)) {
        html.push("<ol class=\"dr-ak-list dr-ak-list-num\">");
        trimmed.forEach(function (l) {
          html.push("<li>" + numberedContent(l) + "</li>");
        });
        html.push("</ol>");
        return;
      }

      trimmed.forEach(function (line) {
        if (line === "") return;
        if (isBullet(line)) {
          html.push("<ul class=\"dr-ak-list\"><li>" + bulletContent(line) + "</li></ul>");
        } else if (isNumbered(line)) {
          html.push("<ol class=\"dr-ak-list dr-ak-list-num\"><li>" + numberedContent(line) + "</li></ol>");
        } else {
          html.push("<p>" + inlineFormat(line) + "</p>");
        }
      });
    });

    return html.join("");
  }

  global.formatDrAkliluText = formatDrAkliluText;
})(typeof window !== "undefined" ? window : globalThis);
