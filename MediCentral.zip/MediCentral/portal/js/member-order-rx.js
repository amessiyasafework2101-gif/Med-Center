(function () {
  const qrRegion = document.getElementById("rxQrRegion");
  const qrInput = document.getElementById("prescription_qr");
  const fileInput = document.getElementById("prescription_photo");
  if (!qrRegion || !qrInput) return;

  let scanner = null;
  let active = false;

  function setStatus(msg) {
    const el = document.getElementById("rxQrStatus");
    if (el) el.textContent = msg;
  }

  async function startScan() {
    if (active || typeof Html5Qrcode === "undefined") return;
    active = true;
    setStatus("Point camera at prescription QR code…");
    scanner = new Html5Qrcode("rxQrReader");
    try {
      await scanner.start(
        { facingMode: "environment" },
        { fps: 8, qrbox: { width: 220, height: 220 } },
        function (decoded) {
          qrInput.value = decoded;
          setStatus("QR captured. You can stop the camera.");
          stopScan();
        },
        function () {}
      );
    } catch (e) {
      setStatus("Could not start camera. Upload a photo instead.");
      active = false;
    }
  }

  async function stopScan() {
    if (!scanner || !active) return;
    try {
      await scanner.stop();
      await scanner.clear();
    } catch (e) {
      /* ignore */
    }
    scanner = null;
    active = false;
    setStatus("Camera stopped.");
  }

  const btnStart = document.getElementById("rxQrStart");
  const btnStop = document.getElementById("rxQrStop");
  if (btnStart) btnStart.addEventListener("click", startScan);
  if (btnStop) btnStop.addEventListener("click", stopScan);

  if (fileInput) {
    fileInput.addEventListener("change", function () {
      if (fileInput.files && fileInput.files[0]) {
        setStatus("Photo selected. Submit the order when ready.");
      }
    });
  }
})();
