(function () {
  var catalog = window.MC_POS_CATALOG || { by_barcode: {}, by_qr: {}, drugs: {} };
  var lineBody = document.getElementById("lineBody");
  var bcQuick = document.getElementById("bcQuick");
  var scanStatus = document.getElementById("posScanStatus");
  var scanner = null;
  var running = false;

  function resolveDrugId(code) {
    if (!code) return 0;
    code = code.trim();
    if (catalog.by_barcode[code]) return catalog.by_barcode[code];
    if (catalog.by_qr[code]) return catalog.by_qr[code];
    return 0;
  }

  function newestRow() {
    var rows = lineBody.querySelectorAll("tr");
    return rows.length ? rows[rows.length - 1] : null;
  }

  function firstRow() {
    return lineBody.rows[0] || null;
  }

  function updateRowUnitLabel(row) {
    if (!row) return;
    var sel = row.querySelector(".line-drug-select");
    var lbl = row.querySelector(".line-unit-lbl");
    if (!sel || !lbl) return;
    var opt = sel.options[sel.selectedIndex];
    lbl.textContent = opt && opt.dataset.unitLabel ? opt.dataset.unitLabel : "units";
  }

  function applyDrugToRow(row, drugId, addQty) {
    if (!row) return false;
    var sel = row.querySelector(".line-drug-select");
    var qtyIn = row.querySelector(".line-qty-input");
    if (!sel) return false;
    var opt = sel.querySelector('option[value="' + drugId + '"]');
    if (!opt || opt.disabled) {
      alert("That product is out of stock.");
      return false;
    }
    sel.value = String(drugId);
    updateRowUnitLabel(row);
    if (qtyIn) {
      if (addQty && parseInt(addQty, 10) > 0) {
        qtyIn.value = String(parseInt(addQty, 10));
      }
      qtyIn.focus();
      qtyIn.select();
    }
    var d = catalog.drugs[drugId];
    if (scanStatus && d) {
      scanStatus.textContent =
        d.name + " — " + d.quantity + " " + (opt.dataset.unitLabel || "units") + " in stock.";
    }
    return true;
  }

  function handleScan(code) {
    var id = resolveDrugId(code);
    if (!id) {
      alert("No product matches that barcode or QR code.");
      return;
    }
    var row = newestRow() || firstRow();
    var sel = row && row.querySelector(".line-drug-select");
    if (sel && sel.value && sel.value !== String(id)) {
      document.getElementById("btnAddLine").click();
      row = newestRow();
    }
    applyDrugToRow(row, id);
    if (bcQuick) bcQuick.value = "";
  }

  document.getElementById("btnAddLine").addEventListener("click", function () {
    var tpl = lineBody.rows[0];
    var row = tpl.cloneNode(true);
    row.querySelectorAll("select, input").forEach(function (el) {
      if (el.classList.contains("line-drug-select")) el.selectedIndex = 0;
      if (el.classList.contains("line-qty-input")) el.value = "1";
    });
    updateRowUnitLabel(row);
    lineBody.appendChild(row);
  });

  lineBody.addEventListener("change", function (ev) {
    if (ev.target.classList.contains("line-drug-select")) {
      updateRowUnitLabel(ev.target.closest("tr"));
    }
  });

  lineBody.addEventListener("click", function (ev) {
    if (!ev.target.classList.contains("ph-btn-remove")) return;
    if (lineBody.rows.length <= 1) return;
    ev.target.closest("tr").remove();
  });

  if (bcQuick) {
    bcQuick.addEventListener("keydown", function (ev) {
      if (ev.key !== "Enter") return;
      ev.preventDefault();
      var raw = bcQuick.value.trim();
      if (!raw) return;
      handleScan(raw);
    });
  }

  var btnStart = document.getElementById("posScanStart");
  var btnStop = document.getElementById("posScanStop");
  if (btnStart) {
    btnStart.addEventListener("click", function () {
      if (running || !window.Html5Qrcode) {
        if (scanStatus) scanStatus.textContent = "Scanner unavailable.";
        return;
      }
      scanner = new Html5Qrcode("pos-reader");
      scanner
        .start(
          { facingMode: "environment" },
          { fps: 10, qrbox: { width: 240, height: 240 } },
          function (decoded) {
            handleScan(decoded);
          },
          function () {}
        )
        .then(function () {
          running = true;
          if (scanStatus) scanStatus.textContent = "Scanning — point at barcode or QR.";
        })
        .catch(function () {
          if (scanStatus) scanStatus.textContent = "Camera failed — use manual entry.";
        });
    });
  }
  if (btnStop) {
    btnStop.addEventListener("click", function () {
      if (scanner && running) {
        scanner.stop().then(function () {
          running = false;
          scanner.clear();
          if (scanStatus) scanStatus.textContent = "Camera stopped.";
        });
      }
    });
  }

  updateRowUnitLabel(firstRow());
})();
