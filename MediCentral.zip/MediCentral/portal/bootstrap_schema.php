<?php

declare(strict_types=1);

/**
 * Ensure MediCentral portal auth tables exist in `medicentral`.
 * Seeds a default administrator when the table was empty (`admin` / `password`).
 * Adds Nahom + pharmacist starter accounts once (usernames nahomtessema / nahomtessema1).
 */
function mc_bootstrap_medical_schema(mysqli $conn): void
{
	// PHP 8.1+ mysqli throws on failed queries by default; migrations expect errno checks.
	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$migrations = <<<SQL
CREATE TABLE IF NOT EXISTS `mc_admins` (
  `admin_id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `ux_mc_admins_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_pharmacists` (
  `pharmacist_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pharmacist_id`),
  UNIQUE KEY `ux_mc_pharmacists_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

		if (!$conn->multi_query($migrations)) {
			throw new RuntimeException('Schema migrate failed: ' . $conn->error);
		}
		while ($conn->more_results() && $conn->next_result()) {
			if ($flush = $conn->store_result()) {
				$flush->free();
			}
		}

		mc_upgrade_mc_admins_profile_columns($conn);

		$resCount = $conn->query('SELECT COUNT(*) AS c FROM mc_admins');
		if ($resCount && ($r = $resCount->fetch_assoc()) !== null && (int) $r['c'] === 0) {
			$hash = password_hash('password', PASSWORD_DEFAULT);
			$stmt = $conn->prepare('INSERT INTO mc_admins (username, password_hash) VALUES (?, ?)');
			if (!$stmt) {
				throw new RuntimeException('Prepare failed for default admin seed.');
			}
			$name = 'admin';
			$stmt->bind_param('ss', $name, $hash);
			if (!$stmt->execute()) {
				throw new RuntimeException('Failed to seed default mc_admins.');
			}
			$stmt->close();
		}

		mc_seed_nahom_accounts_if_missing($conn);
		mc_bootstrap_operational_schema($conn);
		mc_upgrade_mc_portal_extensions($conn);
		mc_bootstrap_pharmacia_compat_schema($conn);
		mc_bootstrap_network_schema($conn);
		mc_bootstrap_member_portal_schema($conn);
		mc_bootstrap_map_schema($conn);
		mc_bootstrap_system_admin_schema($conn);
		mc_bootstrap_pharmacist_professional_schema($conn);
		require_once __DIR__ . '/includes/site_contact.php';
		mc_bootstrap_contact_schema($conn);
		require_once __DIR__ . '/includes/member_order_payment.php';
		mc_upgrade_member_order_payment_schema($conn);
		require_once __DIR__ . '/includes/inventory_ops.php';
		mc_upgrade_inventory_unit_schema($conn);
		require_once __DIR__ . '/includes/admin_chat.php';
		mc_bootstrap_admin_chat_schema($conn);
		require_once __DIR__ . '/includes/pharmacist_ratings.php';
		mc_upgrade_pharmacist_ratings_unique($conn);
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

/**
 * Post-create upgrades for MediCentral portal (safe on existing databases).
 */
function mc_upgrade_mc_portal_extensions(mysqli $conn): void
{
	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		if (mc_table_has_column($conn, 'mc_drugs', 'quantity')) {
			if (!mc_table_has_column($conn, 'mc_drugs', 'reorder_level')) {
				@$conn->query('ALTER TABLE `mc_drugs` ADD COLUMN `reorder_level` INT NOT NULL DEFAULT 10 AFTER `unit_price`');
			}
			if (!mc_table_has_column($conn, 'mc_drugs', 'expiry_date')) {
				@$conn->query('ALTER TABLE `mc_drugs` ADD COLUMN `expiry_date` DATE NULL AFTER `reorder_level`');
			}
			if (!mc_table_has_index($conn, 'mc_drugs', 'ix_mc_drugs_expiry')) {
				@$conn->query('ALTER TABLE `mc_drugs` ADD KEY `ix_mc_drugs_expiry` (`expiry_date`)');
			}
		}
		if (mc_table_has_column($conn, 'mc_pharmacists', 'created_at')) {
			if (!mc_table_has_column($conn, 'mc_pharmacists', 'last_login_at')) {
				@$conn->query('ALTER TABLE `mc_pharmacists` ADD COLUMN `last_login_at` TIMESTAMP NULL DEFAULT NULL AFTER `created_at`');
			}
		}
		if (mc_table_has_column($conn, 'mc_admins', 'created_at')) {
			if (!mc_table_has_column($conn, 'mc_admins', 'last_login_at')) {
				@$conn->query('ALTER TABLE `mc_admins` ADD COLUMN `last_login_at` TIMESTAMP NULL DEFAULT NULL AFTER `created_at`');
			}
		}
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

/**
 * Procurement + customers (parity with legacy PHARMACIA pages) on `medicentral` only.
 */
function mc_bootstrap_pharmacia_compat_schema(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_drugs', 'drug_id')) {
		return;
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$batch = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_suppliers` (
  `supplier_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`supplier_id`),
  KEY `ix_mc_suppliers_company` (`company_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_customers` (
  `customer_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` tinyint unsigned DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`),
  KEY `ix_mc_customers_name` (`last_name`,`first_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_purchases` (
  `purchase_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` bigint unsigned NOT NULL,
  `purchased_on` date NOT NULL,
  `purchase_note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`purchase_id`),
  KEY `ix_mc_purch_date` (`purchased_on`),
  CONSTRAINT `fk_mc_purch_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `mc_suppliers` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_purchase_lines` (
  `line_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint unsigned NOT NULL,
  `drug_id` bigint unsigned NOT NULL,
  `qty` int NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `line_total` decimal(12,2) NOT NULL,
  `batch_expiry` date DEFAULT NULL,
  PRIMARY KEY (`line_id`),
  KEY `ix_mpl_purchase` (`purchase_id`),
  KEY `ix_mpl_drug` (`drug_id`),
  CONSTRAINT `fk_mpl_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `mc_purchases` (`purchase_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mpl_drug` FOREIGN KEY (`drug_id`) REFERENCES `mc_drugs` (`drug_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

		if (!$conn->multi_query($batch)) {
			throw new RuntimeException('Pharmacia compat schema: ' . $conn->error);
		}
		while ($conn->more_results() && $conn->next_result()) {
			if ($flush = $conn->store_result()) {
				$flush->free();
			}
		}

		if (mc_table_has_column($conn, 'mc_sales', 'pharmacist_id')
			&& !mc_table_has_column($conn, 'mc_sales', 'customer_id')) {
			@$conn->query(
				'ALTER TABLE `mc_sales` ADD COLUMN `customer_id` bigint unsigned DEFAULT NULL AFTER `pharmacist_id`, ADD KEY `ix_mc_sales_customer` (`customer_id`)'
			);
			@$conn->query(
				'ALTER TABLE `mc_sales` ADD CONSTRAINT `fk_mc_sales_customer` FOREIGN KEY (`customer_id`) REFERENCES `mc_customers` (`customer_id`) ON DELETE SET NULL'
			);
		}
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

/**
 * Centralized MediCentral network: public members + pharmacy directory.
 */
function mc_bootstrap_network_schema(mysqli $conn): void
{
	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$sql = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_pharmacies` (
  `pharmacy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tagline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pharmacy_id`),
  UNIQUE KEY `ux_mc_pharmacies_slug` (`slug`),
  KEY `ix_mc_pharmacies_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_members` (
  `member_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `ux_mc_members_username` (`username`),
  UNIQUE KEY `ux_mc_members_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

		if (!$conn->multi_query($sql)) {
			throw new RuntimeException('Network schema failed: ' . $conn->error);
		}
		while ($conn->more_results() && $conn->next_result()) {
			if ($flush = $conn->store_result()) {
				$flush->free();
			}
		}

		if (mc_table_has_column($conn, 'mc_pharmacists', 'pharmacist_id')
			&& !mc_table_has_column($conn, 'mc_pharmacists', 'pharmacy_id')) {
			@$conn->query(
				'ALTER TABLE `mc_pharmacists` ADD COLUMN `pharmacy_id` bigint unsigned DEFAULT NULL AFTER `is_active`'
			);
			if (mc_table_has_column($conn, 'mc_pharmacies', 'pharmacy_id')) {
				@$conn->query(
					'ALTER TABLE `mc_pharmacists` ADD KEY `ix_mc_pharmacists_pharmacy` (`pharmacy_id`)'
				);
				@$conn->query(
					'ALTER TABLE `mc_pharmacists` ADD CONSTRAINT `fk_mc_pharmacists_pharmacy` FOREIGN KEY (`pharmacy_id`) REFERENCES `mc_pharmacies` (`pharmacy_id`) ON DELETE SET NULL'
				);
			}
		}

		mc_seed_demo_pharmacies_if_empty($conn);
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

function mc_seed_demo_pharmacies_if_empty(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacies', 'pharmacy_id')) {
		return;
	}
	$c = $conn->query('SELECT COUNT(*) AS n FROM mc_pharmacies');
	if (!$c || (int) ($c->fetch_assoc()['n'] ?? 0) > 0) {
		return;
	}

	$rows = [
		['MediCentral Central Pharmacy', 'central-hub', 'Full-service hub · 24/7 dispensing', '12 Health Avenue', 'Addis Ababa', '+251-11-000-1001'],
		['GreenLeaf Community Pharmacy', 'greenleaf', 'Neighborhood care & wellness', '45 Bole Road', 'Addis Ababa', '+251-11-000-2002'],
		['Sunrise Clinical Pharmacy', 'sunrise', 'Hospital-adjacent formulary', '8 Medical Campus Dr', 'Addis Ababa', '+251-11-000-3003'],
	];

	$stmt = $conn->prepare(
		'INSERT INTO mc_pharmacies (name, slug, tagline, address, city, phone, is_active) VALUES (?,?,?,?,?,?,1)'
	);
	if (!$stmt) {
		return;
	}

	foreach ($rows as $r) {
		$n = $r[0];
		$sl = $r[1];
		$tg = $r[2];
		$ad = $r[3];
		$ci = $r[4];
		$ph = $r[5];
		$stmt->bind_param('ssssss', $n, $sl, $tg, $ad, $ci, $ph);
		$stmt->execute();
	}
	$stmt->close();
}

/**
 * Per-pharmacy stock, member orders, extended drug metadata for the public portal.
 */
function mc_bootstrap_member_portal_schema(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacies', 'pharmacy_id')) {
		return;
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		if (mc_table_has_column($conn, 'mc_drugs', 'drug_id')) {
			if (!mc_table_has_column($conn, 'mc_drugs', 'description')) {
				@$conn->query('ALTER TABLE `mc_drugs` ADD COLUMN `description` TEXT NULL AFTER `category`');
			}
			if (!mc_table_has_column($conn, 'mc_drugs', 'manufacturer')) {
				@$conn->query('ALTER TABLE `mc_drugs` ADD COLUMN `manufacturer` VARCHAR(120) NULL AFTER `description`');
			}
		}

		$sql = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_pharmacy_inventory` (
  `inventory_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacy_id` bigint unsigned NOT NULL,
  `drug_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL DEFAULT 0,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`inventory_id`),
  UNIQUE KEY `ux_mc_phinv_ph_drug` (`pharmacy_id`,`drug_id`),
  KEY `ix_mc_phinv_drug` (`drug_id`),
  CONSTRAINT `fk_mc_phinv_pharmacy` FOREIGN KEY (`pharmacy_id`) REFERENCES `mc_pharmacies` (`pharmacy_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mc_phinv_drug` FOREIGN KEY (`drug_id`) REFERENCES `mc_drugs` (`drug_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_member_orders` (
  `order_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `member_id` bigint unsigned NOT NULL,
  `pharmacy_id` bigint unsigned NOT NULL,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `order_note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`),
  KEY `ix_mc_mord_member` (`member_id`),
  KEY `ix_mc_mord_pharmacy` (`pharmacy_id`),
  CONSTRAINT `fk_mc_mord_member` FOREIGN KEY (`member_id`) REFERENCES `mc_members` (`member_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mc_mord_pharmacy` FOREIGN KEY (`pharmacy_id`) REFERENCES `mc_pharmacies` (`pharmacy_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_member_order_lines` (
  `order_id` bigint unsigned NOT NULL,
  `drug_id` bigint unsigned NOT NULL,
  `qty` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `line_total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`order_id`,`drug_id`),
  CONSTRAINT `fk_mc_moline_order` FOREIGN KEY (`order_id`) REFERENCES `mc_member_orders` (`order_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mc_moline_drug` FOREIGN KEY (`drug_id`) REFERENCES `mc_drugs` (`drug_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

		if (!$conn->multi_query($sql)) {
			throw new RuntimeException('Member portal schema: ' . $conn->error);
		}
		while ($conn->more_results() && $conn->next_result()) {
			if ($flush = $conn->store_result()) {
				$flush->free();
			}
		}

		mc_seed_pharmacy_inventory_if_empty($conn);
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

/**
 * Map coordinates for network pharmacies + directory of non-member pharmacies nearby.
 */
function mc_bootstrap_map_schema(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacies', 'pharmacy_id')) {
		return;
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		if (!mc_table_has_column($conn, 'mc_pharmacies', 'latitude')) {
			@$conn->query(
				'ALTER TABLE `mc_pharmacies` ADD COLUMN `latitude` DECIMAL(10,7) DEFAULT NULL AFTER `phone`, ADD COLUMN `longitude` DECIMAL(10,7) DEFAULT NULL AFTER `latitude`'
			);
		}

		$sql = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_pharmacy_places` (
  `place_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` DECIMAL(10,7) NOT NULL,
  `longitude` DECIMAL(10,7) NOT NULL,
  `google_place_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`place_id`),
  KEY `ix_mc_phplaces_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
		@$conn->query($sql);

		mc_seed_pharmacy_coordinates($conn);
		mc_seed_external_pharmacy_places_if_empty($conn);
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

function mc_seed_pharmacy_coordinates(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacies', 'latitude')) {
		return;
	}

	$coords = [
		'central-hub' => [9.0320, 38.7469],
		'greenleaf' => [8.9806, 38.7578],
		'sunrise' => [9.0054, 38.7636],
	];

	$st = $conn->prepare(
		'UPDATE mc_pharmacies SET latitude = ?, longitude = ? WHERE slug = ? AND (latitude IS NULL OR longitude IS NULL)'
	);
	if (!$st) {
		return;
	}
	foreach ($coords as $slug => $pair) {
		$lat = $pair[0];
		$lng = $pair[1];
		$st->bind_param('dds', $lat, $lng, $slug);
		$st->execute();
	}
	$st->close();

	$fallback = $conn->query(
		'SELECT pharmacy_id FROM mc_pharmacies WHERE is_active = 1 AND (latitude IS NULL OR longitude IS NULL) LIMIT 20'
	);
	if ($fallback) {
		$baseLat = 9.02;
		$baseLng = 38.75;
		$i = 0;
		$upd = $conn->prepare('UPDATE mc_pharmacies SET latitude = ?, longitude = ? WHERE pharmacy_id = ?');
		if ($upd) {
			while ($row = $fallback->fetch_assoc()) {
				$pid = (int) $row['pharmacy_id'];
				$lat = $baseLat + ($i * 0.008);
				$lng = $baseLng + ($i * 0.012);
				$upd->bind_param('ddi', $lat, $lng, $pid);
				$upd->execute();
				$i++;
			}
			$upd->close();
		}
	}
}

function mc_seed_external_pharmacy_places_if_empty(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacy_places', 'place_id')) {
		return;
	}
	$c = $conn->query('SELECT COUNT(*) AS n FROM mc_pharmacy_places');
	if (!$c || (int) ($c->fetch_assoc()['n'] ?? 0) > 0) {
		return;
	}

	$rows = [
		['Bole Mini Pharmacy', 'Ring Road, Bole', 'Addis Ababa', '+251-11-555-0101', 8.9872, 38.7891],
		['Kazanchis Drug Store', 'Kazanchis', 'Addis Ababa', '+251-11-555-0202', 9.0108, 38.7698],
		['Piassa Corner Pharmacy', 'Churchill Ave', 'Addis Ababa', '+251-11-555-0303', 9.0335, 38.7521],
		['CMC Retail Pharmacy', 'CMC Road', 'Addis Ababa', null, 9.0621, 38.8102],
		['Megenagna Health Pharmacy', 'Megenagna', 'Addis Ababa', null, 9.0203, 38.8254],
	];

	$st = $conn->prepare(
		'INSERT INTO mc_pharmacy_places (name, address, city, phone, latitude, longitude, is_active) VALUES (?,?,?,?,?,?,1)'
	);
	if (!$st) {
		return;
	}
	foreach ($rows as $r) {
		$phone = $r[3] ?? '';
		$st->bind_param('ssssdd', $r[0], $r[1], $r[2], $phone, $r[4], $r[5]);
		$st->execute();
	}
	$st->close();
}

function mc_seed_pharmacy_inventory_if_empty(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacy_inventory', 'inventory_id')) {
		return;
	}
	$c = $conn->query('SELECT COUNT(*) AS n FROM mc_pharmacy_inventory');
	if (!$c || (int) ($c->fetch_assoc()['n'] ?? 0) > 0) {
		return;
	}

	$phs = [];
	$rph = $conn->query('SELECT pharmacy_id FROM mc_pharmacies WHERE is_active = 1 ORDER BY pharmacy_id');
	if ($rph) {
		while ($row = $rph->fetch_assoc()) {
			$phs[] = (int) $row['pharmacy_id'];
		}
	}
	if ($phs === []) {
		return;
	}

	$rdr = $conn->query('SELECT drug_id, quantity, unit_price FROM mc_drugs ORDER BY drug_id');
	if (!$rdr) {
		return;
	}

	$stmt = $conn->prepare(
		'INSERT INTO mc_pharmacy_inventory (pharmacy_id, drug_id, quantity, unit_price) VALUES (?,?,?,?)'
	);
	if (!$stmt) {
		return;
	}

	$idx = 0;
	$nph = count($phs);
	while ($d = $rdr->fetch_assoc()) {
		$did = (int) $d['drug_id'];
		$qty = (int) $d['quantity'];
		$price = (float) $d['unit_price'];
		$pid = $phs[$idx % $nph];
		$idx++;
		$splitQty = max(1, (int) floor($qty / $nph));
		$stmt->bind_param('iiid', $pid, $did, $splitQty, $price);
		$stmt->execute();
		if ($nph > 1 && $qty > $splitQty) {
			$pid2 = $phs[($idx) % $nph];
			$rest = max(0, $qty - $splitQty);
			if ($rest > 0) {
				$stmt->bind_param('iiid', $pid2, $did, $rest, $price);
				$stmt->execute();
			}
		}
	}
	$stmt->close();
}

function mc_esc_ident(string $s): string
{
	return str_replace('\'', '\'\'', $s);
}

function mc_table_has_column(mysqli $conn, string $table, string $column): bool
{
	if (!$conn->real_query('SELECT DATABASE()')) {
		return false;
	}
	$res = $conn->store_result();
	if (!$res || !($schemaRow = $res->fetch_row())) {
		return false;
	}
	$res->free();

	$db = mc_esc_ident($schemaRow[0]);
	$tab = mc_esc_ident($table);
	$col = mc_esc_ident($column);

	$r = @$conn->query(
		"SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '{$db}' AND TABLE_NAME = '{$tab}' AND COLUMN_NAME = '{$col}' LIMIT 1"
	);

	return $r !== false && $r->num_rows > 0;
}

function mc_table_has_index(mysqli $conn, string $table, string $indexName): bool
{
	if (!$conn->real_query('SELECT DATABASE()')) {
		return false;
	}
	$res = $conn->store_result();
	if (!$res || !($schemaRow = $res->fetch_row())) {
		return false;
	}
	$res->free();

	$db = mc_esc_ident($schemaRow[0]);
	$tab = mc_esc_ident($table);
	$inx = mc_esc_ident($indexName);

	$r = @$conn->query(
		"SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = '{$db}' AND TABLE_NAME = '{$tab}' AND INDEX_NAME = '{$inx}' LIMIT 1"
	);

	return $r !== false && $r->num_rows > 0;
}

/** Add name/email columns when upgrading an older `mc_admins` table. */
function mc_upgrade_mc_admins_profile_columns(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_admins', 'first_name')) {
		if (!$conn->query('ALTER TABLE `mc_admins` ADD COLUMN `first_name` VARCHAR(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `username`')) {
			throw new RuntimeException('mc_admins: add first_name failed: ' . $conn->error);
		}
	}
	if (!mc_table_has_column($conn, 'mc_admins', 'last_name')) {
		if (!$conn->query('ALTER TABLE `mc_admins` ADD COLUMN `last_name` VARCHAR(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `first_name`')) {
			throw new RuntimeException('mc_admins: add last_name failed: ' . $conn->error);
		}
	}
	if (!mc_table_has_column($conn, 'mc_admins', 'email')) {
		if (!$conn->query('ALTER TABLE `mc_admins` ADD COLUMN `email` VARCHAR(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `last_name`')) {
			throw new RuntimeException('mc_admins: add email failed: ' . $conn->error);
		}
	}
	if (!mc_table_has_index($conn, 'mc_admins', 'ux_mc_admins_email')) {
		if (!$conn->query('ALTER TABLE `mc_admins` ADD UNIQUE KEY `ux_mc_admins_email` (`email`)')) {
			// 1062 duplicate values; 1061 duplicate index name — skip so the portal can still run.
			if ($conn->errno !== 1061 && $conn->errno !== 1062) {
				throw new RuntimeException(
					'mc_admins: add ux_mc_admins_email failed: ' . $conn->error
				);
			}
		}
	}
}

/** @return bool true when no row exists for this username */
function mc_admin_username_available(mysqli $conn, string $username): bool
{
	$stmt = $conn->prepare('SELECT 1 FROM mc_admins WHERE username = ? LIMIT 1');
	if ($stmt === false) {
		return false;
	}
	$stmt->bind_param('s', $username);
	if (!$stmt->execute()) {
		$stmt->close();

		return false;
	}
	$stmt->store_result();
	$free = $stmt->num_rows === 0;
	$stmt->close();

	return $free;
}

/**
 * Nahom starter accounts — inserted only when usernames are not taken (will not overwrite).
 */
function mc_seed_nahom_accounts_if_missing(mysqli $conn): void
{
	static $done = false;
	if ($done) {
		return;
	}
	$done = true;

	require_once __DIR__ . '/includes/pharmacist_pro.php';

	$nahomPw = getenv('MC_SEED_NAHOM_PASSWORD');
	if ($nahomPw === false || $nahomPw === '') {
		$nahomPw = '12345678';
	}

	$pwHash = password_hash($nahomPw, PASSWORD_DEFAULT);
	$fname = 'Nahom';
	$lname = 'Tessema';

	if (mc_admin_username_available($conn, 'nahomtessema')) {
		$u = 'nahomtessema';
		$mail = 'nahomtessema@gmail.com';
		$stmt = $conn->prepare(
			'INSERT INTO mc_admins (username, password_hash, first_name, last_name, email) VALUES (?,?,?,?,?)'
		);
		if ($stmt) {
			$stmt->bind_param('sssss', $u, $pwHash, $fname, $lname, $mail);
			$stmt->execute();
			$stmt->close();
		}
	}

	if (mc_pharmacist_username_available($conn, 'nahomtessema1')) {
		$u = 'nahomtessema1';
		$mail = 'nahomtessema1@gmail.com';
		$active = 1;
		$stmt = $conn->prepare(
			'INSERT INTO mc_pharmacists (username, password_hash, first_name, last_name, email, is_active) VALUES (?,?,?,?,?,?)'
		);
		if ($stmt) {
			$stmt->bind_param('sssssi', $u, $pwHash, $fname, $lname, $mail, $active);
			$stmt->execute();
			$stmt->close();
		}
	}
}

/**
 * Inventory / sales tables for admin dashboard (MediCentral portal only).
 */
function mc_bootstrap_operational_schema(mysqli $conn): void
{
	$migrations = <<<SQL
CREATE TABLE IF NOT EXISTS `mc_drugs` (
  `drug_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr_code` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT 'Uncategorized',
  `quantity` int NOT NULL DEFAULT 0,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `reorder_level` int NOT NULL DEFAULT 10,
  `expiry_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`drug_id`),
  UNIQUE KEY `ux_mc_drugs_barcode` (`barcode`),
  UNIQUE KEY `ux_mc_drugs_qr` (`qr_code`),
  KEY `ix_mc_drugs_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_sales` (
  `sale_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacist_id` bigint unsigned DEFAULT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `sale_note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sale_id`),
  KEY `ix_mc_sales_ph` (`pharmacist_id`),
  KEY `ix_mc_sales_at` (`sale_at`),
  CONSTRAINT `fk_mc_sales_pharmacist` FOREIGN KEY (`pharmacist_id`) REFERENCES `mc_pharmacists` (`pharmacist_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_sale_items` (
  `sale_id` bigint unsigned NOT NULL,
  `drug_id` bigint unsigned NOT NULL,
  `qty` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `line_total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`sale_id`,`drug_id`),
  KEY `ix_mc_sale_items_drug` (`drug_id`),
  CONSTRAINT `fk_mc_sale_items_sale` FOREIGN KEY (`sale_id`) REFERENCES `mc_sales` (`sale_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mc_sale_items_drug` FOREIGN KEY (`drug_id`) REFERENCES `mc_drugs` (`drug_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

	if (!$conn->multi_query($migrations)) {
		throw new RuntimeException('Operational schema failed: ' . $conn->error);
	}
	while ($conn->more_results() && $conn->next_result()) {
		if ($flush = $conn->store_result()) {
			$flush->free();
		}
	}

	mc_seed_demo_operational_data_if_empty($conn);
}

function mc_seed_demo_operational_data_if_empty(mysqli $conn): void
{
	$c = $conn->query('SELECT COUNT(*) AS n FROM mc_drugs');
	if (!$c || (int) ($c->fetch_assoc()['n'] ?? 0) > 0) {
		return;
	}

	$exSoon = (new DateTimeImmutable('+55 days'))->format('Y-m-d');
	$exMid = (new DateTimeImmutable('+120 days'))->format('Y-m-d');
	$exWarn = (new DateTimeImmutable('+25 days'))->format('Y-m-d');

	$rows = [
		['Dolo 650', '5901234123457', 'Pain relief', 620, 2.50, 550, $exSoon],
		['Vitamin C 500mg', null, 'Vitamins', 180, 8.00, 140, $exMid],
		['Amoxicillin 500mg', '0123456789123', 'Antibiotics', 90, 18.50, 100, $exMid],
		['Cetirizine syrup', null, 'Allergies', 40, 11.25, 60, $exWarn],
	];

	$stmt = $conn->prepare(
		'INSERT INTO mc_drugs (name, barcode, category, quantity, unit_price, reorder_level, expiry_date) VALUES (?,?,?,?,?,?,?)'
	);
	if (!$stmt) {
		return;
	}

	foreach ($rows as $r) {
		$nm = $r[0];
		$bc = $r[1];
		$cat = $r[2];
		$q = $r[3];
		$pr = $r[4];
		$ro = $r[5];
		$ex = $r[6];
		$stmt->bind_param(str_repeat('s', 3) . 'idis', $nm, $bc, $cat, $q, $pr, $ro, $ex);
		$stmt->execute();
	}
	$stmt->close();

	$ph = $conn->query('SELECT pharmacist_id FROM mc_pharmacists WHERE is_active = 1 ORDER BY pharmacist_id LIMIT 1');
	$dr = $conn->query('SELECT drug_id, unit_price, quantity FROM mc_drugs ORDER BY drug_id LIMIT 1');
	if (!$ph || !$dr) {
		return;
	}
	$prow = $ph->fetch_assoc();
	$drow = $dr->fetch_assoc();
	if (!$prow || !$drow) {
		return;
	}

	$pid = (int) $prow['pharmacist_id'];
	$did = (int) $drow['drug_id'];
	$price = (float) $drow['unit_price'];
	$qty = 2;
	$total = $qty * $price;

	$stmtS = $conn->prepare(
		'INSERT INTO mc_sales (pharmacist_id, customer_id, total_amount, sale_note) VALUES (?, NULL, ?, ?)'
	);
	if (!$stmtS) {
		return;
	}
	$note = 'Demo sale for dashboard';
	$stmtS->bind_param('ids', $pid, $total, $note);
	$stmtS->execute();
	$sid = (int) $conn->insert_id;
	$stmtS->close();

	$line = $qty * $price;
	$stmtL = $conn->prepare('INSERT INTO mc_sale_items (sale_id, drug_id, qty, unit_price, line_total) VALUES (?,?,?,?,?)');
	if ($stmtL) {
		$stmtL->bind_param('iiidd', $sid, $did, $qty, $price, $line);
		$stmtL->execute();
		$stmtL->close();
	}
}

/** Default system admin seed: `nahi` / `12345678`. */
function mc_seed_default_system_admin(mysqli $conn): void
{
	$hash = password_hash('12345678', PASSWORD_DEFAULT);
	$stmt = $conn->prepare(
		'INSERT INTO mc_system_admins (username, password_hash, display_name, email, is_active) VALUES (?,?,?,?,1)'
	);
	if (!$stmt) {
		return;
	}
	$user = 'nahi';
	$name = 'System Administrator';
	$mail = 'nahi@medicentral.local';
	$stmt->bind_param('ssss', $user, $hash, $name, $mail);
	$stmt->execute();
	$stmt->close();
}

/**
 * Rename legacy `sysadmin` to `nahi` and apply the default password.
 */
function mc_migrate_system_admin_to_nahi(mysqli $conn): void
{
	static $done = false;
	if ($done || !mc_table_has_column($conn, 'mc_system_admins', 'username')) {
		return;
	}
	$done = true;

	$hash = password_hash('12345678', PASSWORD_DEFAULT);
	$legacy = 'sysadmin';
	$target = 'nahi';

	$stmt = $conn->prepare('SELECT system_admin_id FROM mc_system_admins WHERE username = ? LIMIT 1');
	if (!$stmt) {
		return;
	}
	$stmt->bind_param('s', $legacy);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();
	if ($row === null) {
		return;
	}

	$id = (int) $row['system_admin_id'];
	$chk = $conn->prepare('SELECT 1 FROM mc_system_admins WHERE username = ? AND system_admin_id <> ? LIMIT 1');
	if ($chk) {
		$chk->bind_param('si', $target, $id);
		$chk->execute();
		$cr = $chk->get_result();
		$exists = $cr !== false && $cr->fetch_row() !== null;
		$chk->close();
		if ($exists) {
			$upd = $conn->prepare('UPDATE mc_system_admins SET password_hash = ? WHERE system_admin_id = ? LIMIT 1');
			if ($upd) {
				$upd->bind_param('si', $hash, $id);
				$upd->execute();
				$upd->close();
			}
			return;
		}
	}

	$upd = $conn->prepare(
		'UPDATE mc_system_admins SET username = ?, password_hash = ?, email = ? WHERE system_admin_id = ? LIMIT 1'
	);
	if ($upd) {
		$mail = 'nahi@medicentral.local';
		$upd->bind_param('sssi', $target, $hash, $mail, $id);
		$upd->execute();
		$upd->close();
	}
}

/**
 * System administrator accounts, pharmacy licensing fields, audit trail.
 */
function mc_bootstrap_system_admin_schema(mysqli $conn): void
{
	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$sql = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_system_admins` (
  `system_admin_id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`system_admin_id`),
  UNIQUE KEY `ux_mc_system_admins_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_system_audit_log` (
  `audit_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `system_admin_id` int unsigned DEFAULT NULL,
  `action` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` bigint unsigned DEFAULT NULL,
  `summary` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_json` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`audit_id`),
  KEY `ix_mc_audit_created` (`created_at`),
  KEY `ix_mc_audit_entity` (`entity_type`, `entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

		if (!$conn->multi_query($sql)) {
			throw new RuntimeException('System admin schema failed: ' . $conn->error);
		}
		while ($conn->more_results() && $conn->next_result()) {
			if ($flush = $conn->store_result()) {
				$flush->free();
			}
		}

		mc_upgrade_mc_pharmacies_licensing_columns($conn);
		mc_upgrade_mc_admins_pharmacy_columns($conn);

		$resCount = $conn->query('SELECT COUNT(*) AS c FROM mc_system_admins');
		if ($resCount && ($r = $resCount->fetch_assoc()) !== null && (int) $r['c'] === 0) {
			mc_seed_default_system_admin($conn);
		}

		mc_migrate_system_admin_to_nahi($conn);
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}

function mc_upgrade_mc_pharmacies_licensing_columns(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacies', 'pharmacy_id')) {
		return;
	}

	$adds = [
		'email' => 'VARCHAR(120) NULL AFTER `phone`',
		'website' => 'VARCHAR(255) NULL AFTER `email`',
		'owner_name' => 'VARCHAR(120) NULL AFTER `website`',
		'registration_number' => 'VARCHAR(80) NULL AFTER `owner_name`',
		'tax_id' => 'VARCHAR(80) NULL AFTER `registration_number`',
		'license_number' => 'VARCHAR(80) NULL AFTER `tax_id`',
		'license_authority' => 'VARCHAR(160) NULL AFTER `license_number`',
		'license_expiry' => 'DATE NULL AFTER `license_authority`',
		'license_notes' => 'TEXT NULL AFTER `license_expiry`',
		'license_document_url' => 'VARCHAR(500) NULL AFTER `license_notes`',
		'is_verified' => 'TINYINT(1) NOT NULL DEFAULT 0 AFTER `license_document_url`',
		'verified_at' => 'TIMESTAMP NULL DEFAULT NULL AFTER `is_verified`',
		'updated_at' => 'TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`',
	];

	foreach ($adds as $col => $def) {
		if (!mc_table_has_column($conn, 'mc_pharmacies', $col)) {
			@$conn->query("ALTER TABLE `mc_pharmacies` ADD COLUMN `{$col}` {$def}");
		}
	}

	if (mc_table_has_column($conn, 'mc_pharmacies', 'license_expiry')
		&& !mc_table_has_index($conn, 'mc_pharmacies', 'ix_mc_pharmacies_license_exp')) {
		@$conn->query('ALTER TABLE `mc_pharmacies` ADD KEY `ix_mc_pharmacies_license_exp` (`license_expiry`)');
	}
}

function mc_upgrade_mc_admins_pharmacy_columns(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_admins', 'admin_id')) {
		return;
	}
	if (!mc_table_has_column($conn, 'mc_admins', 'pharmacy_id')) {
		@$conn->query(
			'ALTER TABLE `mc_admins` ADD COLUMN `pharmacy_id` bigint unsigned DEFAULT NULL AFTER `email`'
		);
		if (mc_table_has_column($conn, 'mc_pharmacies', 'pharmacy_id')) {
			@$conn->query(
				'ALTER TABLE `mc_admins` ADD KEY `ix_mc_admins_pharmacy` (`pharmacy_id`)'
			);
			@$conn->query(
				'ALTER TABLE `mc_admins` ADD CONSTRAINT `fk_mc_admins_pharmacy` FOREIGN KEY (`pharmacy_id`) REFERENCES `mc_pharmacies` (`pharmacy_id`) ON DELETE SET NULL'
			);
		}
	}
	if (!mc_table_has_column($conn, 'mc_admins', 'member_id')) {
		@$conn->query(
			'ALTER TABLE `mc_admins` ADD COLUMN `member_id` bigint unsigned DEFAULT NULL AFTER `pharmacy_id`'
		);
		@$conn->query(
			'ALTER TABLE `mc_admins` ADD UNIQUE KEY `ux_mc_admins_member` (`member_id`)'
		);
	}
}

/**
 * Pharmacist self-registration, approval, ratings, chat, work opportunities.
 */
function mc_bootstrap_pharmacist_professional_schema(mysqli $conn): void
{
	if (!mc_table_has_column($conn, 'mc_pharmacists', 'pharmacist_id')) {
		return;
	}

	mysqli_report(MYSQLI_REPORT_OFF);
	try {
		$cols = [
			'approval_status' => "VARCHAR(20) NOT NULL DEFAULT 'approved' AFTER `is_active`",
			'phone' => 'VARCHAR(40) NULL AFTER `email`',
			'bio' => 'TEXT NULL AFTER `phone`',
			'cv_summary' => 'TEXT NULL AFTER `bio`',
			'cv_document_url' => 'VARCHAR(500) NULL AFTER `cv_summary`',
			'license_number' => 'VARCHAR(80) NULL AFTER `cv_document_url`',
			'license_authority' => 'VARCHAR(160) NULL AFTER `license_number`',
			'license_expiry' => 'DATE NULL AFTER `license_authority`',
			'license_document_url' => 'VARCHAR(500) NULL AFTER `license_expiry`',
			'performance_score' => 'DECIMAL(4,2) NOT NULL DEFAULT 0.00 AFTER `license_document_url`',
			'rating_count' => 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER `performance_score`',
			'approved_at' => 'TIMESTAMP NULL DEFAULT NULL AFTER `rating_count`',
			'approved_by_system_admin_id' => 'INT UNSIGNED NULL AFTER `approved_at`',
		];
		foreach ($cols as $col => $def) {
			if (!mc_table_has_column($conn, 'mc_pharmacists', $col)) {
				@$conn->query("ALTER TABLE `mc_pharmacists` ADD COLUMN `{$col}` {$def}");
			}
		}

		$sql = <<<'SQL'
CREATE TABLE IF NOT EXISTS `mc_pharmacist_ratings` (
  `rating_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacist_id` bigint unsigned NOT NULL,
  `rater_type` enum('member','admin') NOT NULL,
  `member_id` bigint unsigned DEFAULT NULL,
  `admin_id` int unsigned DEFAULT NULL,
  `score` tinyint unsigned NOT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rating_id`),
  KEY `ix_ph_rating_pharmacist` (`pharmacist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_pharmacist_messages` (
  `message_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacist_id` bigint unsigned NOT NULL,
  `channel` enum('user','admin','work') NOT NULL DEFAULT 'user',
  `sender_type` enum('member','admin','pharmacist','system') NOT NULL,
  `member_id` bigint unsigned DEFAULT NULL,
  `admin_id` int unsigned DEFAULT NULL,
  `sender_pharmacist_id` bigint unsigned DEFAULT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `ix_ph_msg_pharmacist_channel` (`pharmacist_id`,`channel`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mc_pharmacy_opportunities` (
  `opportunity_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacy_id` bigint unsigned NOT NULL,
  `admin_id` int unsigned NOT NULL,
  `pharmacist_id` bigint unsigned NOT NULL,
  `title` varchar(160) NOT NULL,
  `message` text,
  `status` enum('pending','accepted','declined') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `responded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`opportunity_id`),
  KEY `ix_ph_opp_pharmacist` (`pharmacist_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

		if (!$conn->multi_query($sql)) {
			throw new RuntimeException('Pharmacist professional schema failed: ' . $conn->error);
		}
		while ($conn->more_results() && $conn->next_result()) {
			if ($flush = $conn->store_result()) {
				$flush->free();
			}
		}

		@$conn->query(
			"UPDATE mc_pharmacists SET approval_status = 'approved' WHERE approval_status IS NULL OR approval_status = ''"
		);
	} finally {
		mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	}
}
