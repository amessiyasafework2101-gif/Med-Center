<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/require_pharmacist_approved.php';
require_once __DIR__ . '/includes/pharmacist_shell.php';
require_once __DIR__ . '/includes/inventory_ops.php';

mc_upgrade_inventory_unit_schema($conn);

$pid = (int) ($_SESSION['mc_pharmacist_id'] ?? 0);
$display = 'Pharmacist';
$error = '';
$notice = '';

$stmt = $conn->prepare(
	'SELECT first_name, last_name FROM mc_pharmacists WHERE pharmacist_id = ? AND is_active = 1 LIMIT 1'
);
if ($stmt) {
	$stmt->bind_param('i', $pid);
	$stmt->execute();
	$f = '';
	$l = '';
	$stmt->bind_result($f, $l);
	if ($stmt->fetch()) {
		$display = trim((string) $f . ' ' . (string) ($l ?? ''));
	}
	$stmt->close();
}

function mc_pharmacist_reload_drugs(mysqli $conn): array
{
	$list = [];
	$res = $conn->query(
		'SELECT drug_id, name, barcode, qr_code, unit_type, quantity, unit_price FROM mc_drugs ORDER BY name ASC'
	);
	if ($res) {
		while ($r = $res->fetch_assoc()) {
			$list[] = $r;
		}
	}

	return $list;
}

$pharmacyId = 0;
$phSt = $conn->prepare('SELECT pharmacy_id FROM mc_pharmacists WHERE pharmacist_id = ? LIMIT 1');
if ($phSt) {
	$phSt->bind_param('i', $pid);
	$phSt->execute();
	$phSt->bind_result($pharmacyId);
	$phSt->fetch();
	$phSt->close();
}

$drugs = mc_pharmacist_reload_drugs($conn);
$posCatalog = mc_inventory_pos_catalog($conn);

$useCust = mc_table_has_column($conn, 'mc_sales', 'customer_id');
$custChoices = [];
if ($useCust) {
	$cq = $conn->query(
		'SELECT customer_id, first_name, last_name, phone FROM mc_customers ORDER BY last_name ASC, first_name ASC LIMIT 500'
	);
	if ($cq) {
		while ($crow = $cq->fetch_assoc()) {
			$custChoices[] = $crow;
		}
	}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'
	&& isset($_POST['mc_action'])
	&& (string) $_POST['mc_action'] === 'record_sale') {
	$noteTrim = trim((string) ($_POST['sale_note'] ?? ''));
	$noteNull = $noteTrim === '' ? null : $noteTrim;
	$custSale = $useCust ? (int) ($_POST['customer_id'] ?? 0) : 0;
	$cBind = ($useCust && $custSale > 0) ? $custSale : null;

	$dids = $_POST['line_drug_id'] ?? [];
	$qtys = $_POST['line_qty'] ?? [];

	if (!is_array($dids) || !is_array($qtys) || count($dids) !== count($qtys)) {
		$error = 'Invalid line payload.';
	} else {
		$combinedQty = [];
		$nlines = count($dids);
		for ($ix = 0; $ix < $nlines; $ix++) {
			$did = (int) $dids[$ix];
			$qadd = (int) $qtys[$ix];
			if ($did <= 0 || $qadd <= 0) {
				continue;
			}
			if (!isset($combinedQty[$did])) {
				$combinedQty[$did] = 0;
			}
			$combinedQty[$did] += $qadd;
		}

		if ($combinedQty === []) {
			$error = 'Add at least one product line with quantity.';
		} else {
			mysqli_report(MYSQLI_REPORT_OFF);
			$failMsg = '';

			try {
				$conn->begin_transaction();

				$priced = [];

				foreach ($combinedQty as $did => $qneed) {
					$stkStmt = $conn->prepare(
						'SELECT unit_price, quantity FROM mc_drugs WHERE drug_id = ? LIMIT 1 FOR UPDATE'
					);
					if (!$stkStmt) {
						throw new RuntimeException('stock_prepare');
					}
					$stkStmt->bind_param('i', $did);
					if (!$stkStmt->execute()) {
						$stkStmt->close();
						throw new RuntimeException('stock_lookup');
					}
					$up = 0.0;
					$stk = 0;
					$stkStmt->bind_result($up, $stk);
					if (!$stkStmt->fetch()) {
						$stkStmt->close();
						throw new RuntimeException('unknown_drug');
					}
					$stkStmt->close();

					if ($stk < $qneed) {
						throw new RuntimeException('insufficient');
					}

					$priced[$did] = ['unit_price' => (float) $up, 'qty' => $qneed];
				}

				$saleTotal = 0.0;
				foreach ($priced as $pack) {
					$saleTotal += $pack['qty'] * $pack['unit_price'];
				}
				$saleTotal = round($saleTotal, 2);

				if ($useCust) {
					$insSale = $conn->prepare(
						'INSERT INTO mc_sales (pharmacist_id, customer_id, total_amount, sale_note) VALUES (?,?,?,?)'
					);
					if (!$insSale) {
						throw new RuntimeException('sale_prepare');
					}
					if (!$insSale->bind_param('iids', $pid, $cBind, $saleTotal, $noteNull) || !$insSale->execute()) {
						$insSale->close();
						throw new RuntimeException('sale_insert');
					}
				} else {
					$insSale = $conn->prepare(
						'INSERT INTO mc_sales (pharmacist_id, total_amount, sale_note) VALUES (?,?,?)'
					);
					if (!$insSale) {
						throw new RuntimeException('sale_prepare');
					}
					if (!$insSale->bind_param('ids', $pid, $saleTotal, $noteNull) || !$insSale->execute()) {
						$insSale->close();
						throw new RuntimeException('sale_insert');
					}
				}
				$saleId = (int) $conn->insert_id;
				$insSale->close();

				$insLine = $conn->prepare(
					'INSERT INTO mc_sale_items (sale_id, drug_id, qty, unit_price, line_total) VALUES (?,?,?,?,?)'
				);
				$upd = $conn->prepare(
					'UPDATE mc_drugs SET quantity = quantity - ? WHERE drug_id = ? AND quantity >= ?'
				);

				if (!$insLine || !$upd) {
					if ($insLine) {
						$insLine->close();
					}
					if ($upd) {
						$upd->close();
					}
					throw new RuntimeException('line_prepare');
				}

				foreach ($priced as $did => $pack) {
					$qneed = $pack['qty'];
					$unit = $pack['unit_price'];
					$lineTot = round($unit * $qneed, 2);

					if (
						!$insLine->bind_param('iiidd', $saleId, $did, $qneed, $unit, $lineTot)
						|| !$insLine->execute()
					) {
						throw new RuntimeException('line_insert');
					}

					if (
						!$upd->bind_param('iii', $qneed, $did, $qneed)
						|| !$upd->execute()
						|| $upd->affected_rows !== 1
					) {
						throw new RuntimeException('stock_update');
					}
					if ($pharmacyId > 0) {
						mc_inventory_mirror_pharmacy_delta($conn, $did, -$qneed, $pharmacyId);
					}
				}
				$insLine->close();
				$upd->close();

				$conn->commit();

				$notice = 'Sale #' . $saleId . ' posted and inventory reduced.';
				$drugs = mc_pharmacist_reload_drugs($conn);
				$posCatalog = mc_inventory_pos_catalog($conn);
			} catch (Throwable $e) {
				@$conn->rollback();
				$code = $e instanceof RuntimeException ? $e->getMessage() : '';

				switch ($code) {
					case 'insufficient':
						$failMsg = 'Not enough stock on hand for one of the chosen products.';
						break;

					case 'unknown_drug':
					case 'stock_lookup':
					case 'stock_prepare':
						$failMsg = 'Unable to validate inventory for those products.';
						break;

					default:
						$failMsg = 'Sale could not be completed. Nothing was deducted from stock.';
				}

				$error = $failMsg;
			}

			mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
		}
	}
}

$recent = [];
$rSt = $conn->prepare(
	'SELECT sale_id, sale_at, total_amount, sale_note FROM mc_sales WHERE pharmacist_id = ? ORDER BY sale_at DESC LIMIT 12'
);
if ($rSt) {
	$rSt->bind_param('i', $pid);
	if ($rSt->execute()) {
		$rSt->bind_result($rsId, $rsAt, $rsTot, $rsNote);
		while ($rSt->fetch()) {
			$recent[] = [
				'id' => $rsId,
				'at' => $rsAt,
				'total' => $rsTot,
				'note' => $rsNote,
			];
		}
	}
	$rSt->close();
}

$jf = JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT;

mc_pharmacist_shell_start('Point of sale', $display);
?>
<header class="ph-intro">
	<h1>Point-of-sale</h1>
	<p>Record OTC or dispensed items — stock is validated and totals sync to admin dashboards.</p>
</header>

<?php if ($notice !== ''): ?>
	<?php mc_pharmacist_flash($notice, 'success'); ?>
<?php endif; ?>
<?php if ($error !== ''): ?>
	<?php mc_pharmacist_flash($error, 'error'); ?>
<?php endif; ?>

<section class="ph-card" id="pos-sale">
	<h2>New sale</h2>
	<p>Scan barcode or QR on the pack, enter how many units to sell (e.g. tablets), then post. Stock is reduced automatically.</p>
	<div class="ph-scan ph-pos-scan">
		<div class="ph-scan-actions">
			<button type="button" class="ph-btn-secondary" id="posScanStart">Scan barcode / QR</button>
			<button type="button" class="ph-btn-secondary" id="posScanStop">Stop camera</button>
		</div>
		<div id="pos-reader" class="ph-pos-reader"></div>
		<p class="ph-hint" id="posScanStatus">Or type a code below and press Enter.</p>
		<label class="ph-lbl" for="bcQuick">Barcode / QR quick pick</label>
		<input class="ph-input" id="bcQuick" type="text" autocomplete="off" placeholder="Scan or type code, then Enter">
	</div>

	<form method="post" action="" id="saleForm">
				<input type="hidden" name="mc_action" value="record_sale">
				<?php if ($useCust): ?>
				<label class="ph-lbl" for="customer_id">Customer · optional</label>
				<select class="ph-select" id="customer_id" name="customer_id">
					<option value="">Walk-in / not recorded</option>
					<?php foreach ($custChoices as $c): ?>
						<option value="<?php echo (int) $c['customer_id']; ?>">
							<?php echo htmlspecialchars(trim((string) $c['first_name'] . ' ' . ($c['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?>
							<?php echo ($c['phone'] ?? '') !== '' ? ' · ' . htmlspecialchars((string) $c['phone'], ENT_QUOTES, 'UTF-8') : ''; ?>
						</option>
					<?php endforeach; ?>
				</select>
				<?php endif; ?>
				<label class="ph-lbl" for="sale_note">Checkout note · optional</label>
				<input class="ph-input" id="sale_note" name="sale_note" maxlength="240" placeholder="e.g. Walk-in OTC">

				<p class="ph-lbl">Sale lines</p>
				<div class="ph-lines-wrap"><table class="ph-lines">
					<thead><tr><th>Product</th><th>Amount</th><th></th></tr></thead>
					<tbody id="lineBody">
						<tr>
							<td>
								<select class="ph-select line-drug-select" name="line_drug_id[]" required>
									<option value="">Select…</option>
									<?php foreach ($drugs as $dg): ?>
										<?php
										$dQty = (int) $dg['quantity'];
										$dBc = htmlspecialchars(trim((string) ($dg['barcode'] ?? '')), ENT_QUOTES, 'UTF-8');
										$dQr = htmlspecialchars(trim((string) ($dg['qr_code'] ?? '')), ENT_QUOTES, 'UTF-8');
										$dUnit = (string) ($dg['unit_type'] ?? 'unit');
										$dUnitLbl = mc_inventory_unit_label($dUnit);
										?>
										<option value="<?php echo (int) $dg['drug_id']; ?>"
												data-stock="<?php echo $dQty; ?>"
												data-bc="<?php echo $dBc; ?>"
												data-qr="<?php echo $dQr; ?>"
												data-unit="<?php echo htmlspecialchars($dUnit, ENT_QUOTES, 'UTF-8'); ?>"
												data-unit-label="<?php echo htmlspecialchars($dUnitLbl, ENT_QUOTES, 'UTF-8'); ?>"
												data-price="<?php echo htmlspecialchars((string) $dg['unit_price'], ENT_QUOTES, 'UTF-8'); ?>"
											<?php echo $dQty < 1 ? ' disabled' : ''; ?>>
											<?php echo htmlspecialchars((string) $dg['name'], ENT_QUOTES, 'UTF-8'); ?> · <?php echo $dQty; ?> <?php echo htmlspecialchars($dUnitLbl, ENT_QUOTES, 'UTF-8'); ?> · ETB <?php echo number_format((float) $dg['unit_price'], 2); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
							<td class="col-qty">
								<label class="ph-qty-lbl">Qty (<span class="line-unit-lbl">units</span>)</label>
								<input class="ph-input line-qty-input" name="line_qty[]" type="number" min="1" value="1" required>
							</td>
							<td class="col-act"><button type="button" class="ph-btn-remove" aria-label="Remove line">✕</button></td>
						</tr>
					</tbody>
				</table></div>

				<div class="ph-actions"><div class="ph-actions-left">
					<button type="button" id="btnAddLine" class="ph-btn-secondary">+ Add line</button></div>
					<button type="submit" class="mc-btn">Post sale</button>
				</div>
			</form>
</section>

<section class="ph-card" id="recent-sales">
			<h2>Recent sales</h2>
			<?php if (!$recent): ?>
				<p>Your cashier history appears here.</p>
			<?php else: ?>
				<div class="ph-history-wrap">
					<table class="ph-history">
						<thead><tr><th>ID</th><th>When</th><th>Total</th><th>Note</th></tr></thead>
						<tbody>
							<?php foreach ($recent as $rc): ?>
								<tr>
									<td>#<?php echo (int) $rc['id']; ?></td>
									<td><?php echo htmlspecialchars((string) $rc['at'], ENT_QUOTES, 'UTF-8'); ?></td>
									<td><?php echo '$' . number_format((float) $rc['total'], 2); ?></td>
									<td><?php echo htmlspecialchars((string) ($rc['note'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
</section>

	<script>window.MC_POS_CATALOG=<?php echo json_encode($posCatalog, $jf); ?>;</script>
	<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
	<script src="js/pharmacist-pos-scan.js"></script>
<?php mc_pharmacist_shell_end(); ?>

