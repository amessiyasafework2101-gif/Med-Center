<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/member_drugs.php';
require_once dirname(__DIR__) . '/includes/member_order_payment.php';
require_once dirname(__DIR__) . '/includes/currency.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$mid = (int) ($_SESSION['mc_member_id'] ?? 0);
$profile = mc_member_load_profile($conn, $mid);
$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
	$phId = (int) ($_POST['pharmacy_id'] ?? 0);
	$drugId = (int) ($_POST['drug_id'] ?? 0);
	$qty = (int) ($_POST['qty'] ?? 0);
	$note = trim((string) ($_POST['order_note'] ?? ''));
	$rxQr = trim((string) ($_POST['prescription_qr'] ?? ''));

	$rxPath = '';
	$file = $_FILES['prescription_photo'] ?? null;
	$hasFile = is_array($file) && ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK;
	if ($hasFile) {
		$up = mc_member_save_prescription_upload($mid, $file);
		if (!$up['ok']) {
			$flash = $up['error'];
			$flashKind = 'error';
		} else {
			$rxPath = $up['path'];
		}
	}

	if ($flash === null) {
		$res = mc_member_place_order_with_prescription($conn, $mid, [
			'pharmacy_id' => $phId,
			'drug_id' => $drugId,
			'qty' => $qty,
			'note' => $note,
			'prescription_path' => $rxPath,
			'prescription_qr' => $rxQr,
		]);
		if ($res['ok'] && !empty($res['order_id'])) {
			header('Location: order-pay.php?order_id=' . (int) $res['order_id']);
			exit;
		}
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
	}
}

$filters = [
	'q' => $_GET['q'] ?? '',
	'pharmacy_id' => $_GET['pharmacy_id'] ?? '',
	'category' => $_GET['category'] ?? '',
	'in_stock' => isset($_GET['in_stock']),
	'sort' => $_GET['sort'] ?? 'name',
];
$search = mc_member_search_drugs($conn, $filters);
$rows = $search['rows'];
$categories = $search['categories'];

$pharmacies = [];
$pq = $conn->query('SELECT pharmacy_id, name FROM mc_pharmacies WHERE is_active = 1 ORDER BY name');
if ($pq) {
	while ($r = $pq->fetch_assoc()) {
		$pharmacies[] = $r;
	}
}

mc_member_shell_start('Search & order', 'search', $profile);
if ($flash) {
	mc_member_flash($flash, $flashKind);
}
mc_member_page_head('Search & order', 'Prices in Ethiopian Birr (ETB). Every order needs a prescription photo or QR, then Tele Birr payment.');
?>
<section class="mc-hub-section">

	<form method="get" action="" class="mc-filter-form">
		<div class="mc-filter-grid">
			<div class="mc-field-lite">
				<label for="q">Search</label>
				<input type="search" id="q" name="q" value="<?php echo htmlspecialchars((string) $filters['q'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="Name, barcode…">
			</div>
			<div class="mc-field-lite">
				<label for="pharmacy_id">Pharmacy</label>
				<select id="pharmacy_id" name="pharmacy_id">
					<option value="">All pharmacies</option>
					<?php foreach ($pharmacies as $p): ?>
						<option value="<?php echo (int) $p['pharmacy_id']; ?>"<?php echo (int) $filters['pharmacy_id'] === (int) $p['pharmacy_id'] ? ' selected' : ''; ?>><?php echo htmlspecialchars((string) $p['name'], ENT_QUOTES, 'UTF-8'); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="mc-field-lite">
				<label for="category">Category</label>
				<select id="category" name="category">
					<option value="">All categories</option>
					<?php foreach ($categories as $cat): ?>
						<option value="<?php echo htmlspecialchars($cat, ENT_QUOTES, 'UTF-8'); ?>"<?php echo $filters['category'] === $cat ? ' selected' : ''; ?>><?php echo htmlspecialchars($cat, ENT_QUOTES, 'UTF-8'); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="mc-field-lite">
				<label for="sort">Sort</label>
				<select id="sort" name="sort">
					<option value="name"<?php echo $filters['sort'] === 'name' ? ' selected' : ''; ?>>Name</option>
					<option value="stock_desc"<?php echo $filters['sort'] === 'stock_desc' ? ' selected' : ''; ?>>Stock high → low</option>
					<option value="price_asc"<?php echo $filters['sort'] === 'price_asc' ? ' selected' : ''; ?>>Price low → high</option>
					<option value="price_desc"<?php echo $filters['sort'] === 'price_desc' ? ' selected' : ''; ?>>Price high → low</option>
				</select>
			</div>
			<div class="mc-field-lite mc-check-lite">
				<label><input type="checkbox" name="in_stock" value="1"<?php echo $filters['in_stock'] ? ' checked' : ''; ?>> In stock only</label>
			</div>
		</div>
		<button type="submit" class="mc-btn mc-btn-inline">Apply filters</button>
	</form>

	<?php if (!$rows): ?>
		<p class="mc-hub-muted" style="margin-top:1.5rem;">No listings match. Try another filter.</p>
	<?php else: ?>
		<div class="mc-hub-grid mc-order-grid">
			<?php foreach ($rows as $d): ?>
				<article class="mc-hub-card">
					<h3><?php echo htmlspecialchars((string) $d['name'], ENT_QUOTES, 'UTF-8'); ?></h3>
					<p class="mc-hub-muted"><?php echo htmlspecialchars((string) $d['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?></p>
					<p class="mc-hub-meta">
						<?php echo htmlspecialchars((string) $d['category'], ENT_QUOTES, 'UTF-8'); ?>
						· <?php echo (int) $d['shelf_qty']; ?> in stock
						· <strong><?php echo htmlspecialchars(mc_format_etb((float) $d['shelf_price']), ENT_QUOTES, 'UTF-8'); ?></strong>
					</p>
					<?php if ((int) $d['shelf_qty'] > 0): ?>
						<form method="post" class="mc-order-form mc-order-form-rx" enctype="multipart/form-data">
							<input type="hidden" name="place_order" value="1">
							<input type="hidden" name="pharmacy_id" value="<?php echo (int) $d['pharmacy_id']; ?>">
							<input type="hidden" name="drug_id" value="<?php echo (int) $d['drug_id']; ?>">
							<label>Quantity <input type="number" name="qty" min="1" max="<?php echo (int) $d['shelf_qty']; ?>" value="1" required></label>

							<div class="mc-rx-block">
								<p class="mc-rx-title">Prescription (required)</p>
								<label class="mc-rx-file">Upload photo or PDF
									<input type="file" id="prescription_photo" name="prescription_photo" accept="image/jpeg,image/png,image/webp,application/pdf">
								</label>
								<p class="mc-hub-muted">— or scan prescription QR —</p>
								<input type="hidden" name="prescription_qr" id="prescription_qr" value="">
								<div class="mc-rx-qr">
									<div id="rxQrReader" class="mc-rx-qr-view"></div>
									<p id="rxQrStatus" class="mc-hub-muted">Optional if you upload a file.</p>
									<div class="mc-scan-actions">
										<button type="button" class="mc-btn mc-btn-inline secondary" id="rxQrStart">Scan QR</button>
										<button type="button" class="mc-btn mc-btn-inline secondary" id="rxQrStop">Stop</button>
									</div>
								</div>
							</div>

							<input type="text" name="order_note" maxlength="200" placeholder="Note for pharmacy (optional)">
							<button type="submit" class="mc-btn mc-btn-inline">Continue to Tele Birr payment</button>
						</form>
					<?php else: ?>
						<span class="mc-hub-pill">Out of stock</span>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js" defer></script>
<script src="../js/member-order-rx.js" defer></script>
<?php mc_member_shell_end(); ?>
