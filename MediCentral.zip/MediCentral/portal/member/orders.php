<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/member_orders.php';
require_once dirname(__DIR__) . '/includes/currency.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$mid = (int) ($_SESSION['mc_member_id'] ?? 0);
$profile = mc_member_load_profile($conn, $mid);
$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_order'])) {
	$oid = (int) ($_POST['order_id'] ?? 0);
	$res = mc_member_cancel_order($conn, $mid, $oid);
	$flash = $res['msg'];
	$flashKind = $res['ok'] ? 'success' : 'error';
}

$statusFilter = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
$stats = mc_member_order_stats($conn, $mid);
$orders = mc_member_load_orders($conn, $mid, $statusFilter);

mc_member_shell_start('My orders', 'orders', $profile);
mc_member_page_head('My orders', 'Track requests, filter by status, cancel pending orders, or reorder from a pharmacy.');
if ($flash) {
	mc_member_flash($flash, $flashKind);
}
?>
<section class="mc-hub-section mc-orders-section">

	<div class="mc-order-stats">
		<article class="mc-order-stat">
			<span class="mc-order-stat-val"><?php echo (int) $stats['total']; ?></span>
			<span class="mc-order-stat-lbl">Total orders</span>
		</article>
		<article class="mc-order-stat mc-order-stat-pending">
			<span class="mc-order-stat-val"><?php echo (int) $stats['pending']; ?></span>
			<span class="mc-order-stat-lbl">Pending</span>
		</article>
		<article class="mc-order-stat mc-order-stat-ok">
			<span class="mc-order-stat-val"><?php echo (int) $stats['confirmed']; ?></span>
			<span class="mc-order-stat-lbl">In progress</span>
		</article>
		<article class="mc-order-stat">
			<span class="mc-order-stat-val"><?php echo htmlspecialchars(mc_format_etb((float) $stats['spent']), ENT_QUOTES, 'UTF-8'); ?></span>
			<span class="mc-order-stat-lbl">Total spent</span>
		</article>
	</div>

	<form method="get" action="" class="mc-order-filters">
		<label for="status">Filter by status</label>
		<select id="status" name="status" onchange="this.form.submit()">
			<option value=""<?php echo $statusFilter === '' ? ' selected' : ''; ?>>All orders</option>
			<option value="awaiting_payment"<?php echo $statusFilter === 'awaiting_payment' ? ' selected' : ''; ?>>Awaiting payment</option>
			<option value="pending"<?php echo $statusFilter === 'pending' ? ' selected' : ''; ?>>Pending</option>
			<option value="confirmed"<?php echo $statusFilter === 'confirmed' ? ' selected' : ''; ?>>Confirmed</option>
			<option value="ready"<?php echo $statusFilter === 'ready' ? ' selected' : ''; ?>>Ready for pickup</option>
			<option value="cancelled"<?php echo $statusFilter === 'cancelled' ? ' selected' : ''; ?>>Cancelled</option>
		</select>
		<a class="mc-ph-link-btn mc-order-filter-btn" href="search.php">Place new order</a>
	</form>

	<?php if (!$orders): ?>
		<p class="mc-hub-muted">No orders match this filter. <a href="search.php">Search drugs</a> to place your first request.</p>
	<?php else: ?>
		<?php foreach ($orders as $o): ?>
			<?php
			$st = (string) $o['status'];
			$stClass = 'mc-status-' . preg_replace('/[^a-z0-9]/', '', $st);
			?>
			<article class="mc-hub-card mc-order-card">
				<div class="mc-order-head">
					<strong>Order #<?php echo (int) $o['order_id']; ?></strong>
					<span class="mc-hub-pill <?php echo htmlspecialchars($stClass, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(mc_member_order_status_label($st), ENT_QUOTES, 'UTF-8'); ?></span>
				</div>
				<p class="mc-hub-meta"><?php echo htmlspecialchars((string) $o['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?> · <?php echo htmlspecialchars((string) $o['created_at'], ENT_QUOTES, 'UTF-8'); ?></p>

				<ul class="mc-order-timeline" aria-label="Order progress">
					<li class="<?php echo in_array($st, ['pending', 'confirmed', 'ready', 'cancelled'], true) ? 'is-done' : ''; ?>">Submitted</li>
					<li class="<?php echo in_array($st, ['confirmed', 'ready'], true) ? 'is-done' : ''; ?>">Confirmed</li>
					<li class="<?php echo $st === 'ready' ? 'is-done' : ''; ?>">Ready</li>
				</ul>

				<ul class="mc-hub-list mc-order-lines">
					<?php foreach ($o['lines'] as $ln): ?>
						<li><?php echo htmlspecialchars((string) $ln['name'], ENT_QUOTES, 'UTF-8'); ?> × <?php echo (int) $ln['qty']; ?> — <?php echo htmlspecialchars(mc_format_etb((float) $ln['line_total']), ENT_QUOTES, 'UTF-8'); ?></li>
					<?php endforeach; ?>
				</ul>
				<p class="mc-order-total"><strong>Total <?php echo htmlspecialchars(mc_format_etb((float) $o['total_amount']), ENT_QUOTES, 'UTF-8'); ?></strong></p>
				<?php if ($o['order_note']): ?>
					<p class="mc-hub-muted">Note: <?php echo htmlspecialchars((string) $o['order_note'], ENT_QUOTES, 'UTF-8'); ?></p>
				<?php endif; ?>

				<div class="mc-order-actions">
					<a class="mc-btn mc-btn-inline secondary" href="search.php?pharmacy_id=<?php echo (int) $o['pharmacy_id']; ?>">Reorder at pharmacy</a>
					<?php if ($st === 'awaiting_payment'): ?>
						<a class="mc-btn mc-btn-inline" href="order-pay.php?order_id=<?php echo (int) $o['order_id']; ?>">Complete Tele Birr payment</a>
					<?php endif; ?>
					<?php if (in_array($st, ['pending', 'awaiting_payment'], true)): ?>
						<form method="post" class="mc-order-cancel-form" onsubmit="return confirm('Cancel this order?');">
							<input type="hidden" name="cancel_order" value="1">
							<input type="hidden" name="order_id" value="<?php echo (int) $o['order_id']; ?>">
							<button type="submit" class="mc-btn-cancel">Cancel order</button>
						</form>
					<?php endif; ?>
				</div>
			</article>
		<?php endforeach; ?>
	<?php endif; ?>
</section>
<?php mc_member_shell_end(); ?>
