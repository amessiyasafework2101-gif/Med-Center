<?php

declare(strict_types=1);

header('Location: ../about.php', true, 302);
exit;
