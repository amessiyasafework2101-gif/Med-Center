<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_map.php';

header('Content-Type: application/json; charset=utf-8');

$members = mc_map_load_member_pharmacies($conn);
$others = mc_map_load_external_places($conn);
$all = array_merge($members, $others);

$userLat = isset($_GET['lat']) ? (float) $_GET['lat'] : null;
$userLng = isset($_GET['lng']) ? (float) $_GET['lng'] : null;
if ($userLat !== null && $userLng !== null && abs($userLat) <= 90 && abs($userLng) <= 180) {
	$all = mc_map_sort_by_distance($all, $userLat, $userLng);
}

echo json_encode([
	'members' => $members,
	'others' => $others,
	'markers' => $all,
	'member_count' => count($members),
	'other_count' => count($others),
], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
