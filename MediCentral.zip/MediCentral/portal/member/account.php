<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/member_account.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$mid = (int) ($_SESSION['mc_member_id'] ?? 0);
$profile = mc_member_load_profile($conn, $mid);
$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$action = (string) ($_POST['mc_action'] ?? '');
	if ($action === 'update_profile') {
		$res = mc_member_update_profile(
			$conn,
			$mid,
			(string) ($_POST['first_name'] ?? ''),
			(string) ($_POST['last_name'] ?? ''),
			isset($_POST['email']) ? (string) $_POST['email'] : null,
			isset($_POST['phone']) ? (string) $_POST['phone'] : null
		);
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
		if ($res['ok']) {
			$profile = mc_member_load_profile($conn, $mid);
		}
	} elseif ($action === 'change_password') {
		$res = mc_member_change_password(
			$conn,
			$mid,
			(string) ($_POST['current_password'] ?? ''),
			(string) ($_POST['new_password'] ?? '')
		);
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
	}
}

mc_member_shell_start('My account', 'account', $profile);
mc_member_page_head('My account', 'Update your contact details and password.');
if ($flash) {
	mc_member_flash($flash, $flashKind);
}
?>
<section class="mc-hub-section mc-account-section">
	<div class="mc-hub-grid mc-account-grid">
		<article class="mc-hub-card">
			<h2 class="mc-ph-block-title">Profile</h2>
			<form method="post" class="mc-account-form">
				<input type="hidden" name="mc_action" value="update_profile">
				<label class="ph-lbl" for="first_name">First name</label>
				<input class="ph-input" id="first_name" name="first_name" required maxlength="80" value="<?php echo htmlspecialchars((string) $profile['first_name'], ENT_QUOTES, 'UTF-8'); ?>">

				<label class="ph-lbl" for="last_name">Last name</label>
				<input class="ph-input" id="last_name" name="last_name" maxlength="80" value="<?php echo htmlspecialchars((string) $profile['last_name'], ENT_QUOTES, 'UTF-8'); ?>">

				<label class="ph-lbl" for="email">Email</label>
				<input class="ph-input" id="email" name="email" type="email" maxlength="120" value="<?php echo htmlspecialchars((string) $profile['email'], ENT_QUOTES, 'UTF-8'); ?>">

				<label class="ph-lbl" for="phone">Phone</label>
				<input class="ph-input" id="phone" name="phone" type="tel" maxlength="40" value="<?php echo htmlspecialchars((string) $profile['phone'], ENT_QUOTES, 'UTF-8'); ?>">

				<p class="mc-hub-muted">Username: <strong><?php echo htmlspecialchars((string) $profile['username'], ENT_QUOTES, 'UTF-8'); ?></strong> (cannot be changed)</p>

				<button type="submit" class="mc-btn mc-btn-inline">Save profile</button>
			</form>
		</article>

		<article class="mc-hub-card">
			<h2 class="mc-ph-block-title">Password</h2>
			<form method="post" class="mc-account-form">
				<input type="hidden" name="mc_action" value="change_password">
				<label class="ph-lbl" for="current_password">Current password</label>
				<input class="ph-input" id="current_password" name="current_password" type="password" required autocomplete="current-password">

				<label class="ph-lbl" for="new_password">New password</label>
				<input class="ph-input" id="new_password" name="new_password" type="password" required minlength="8" autocomplete="new-password">

				<label class="ph-lbl" for="new_password2">Confirm new password</label>
				<input class="ph-input" id="new_password2" name="new_password2" type="password" required minlength="8" autocomplete="new-password">

				<button type="submit" class="mc-btn mc-btn-inline">Change password</button>
			</form>
		</article>
	</div>
</section>
<script>
(function () {
	var form = document.querySelector('form input[name="mc_action"][value="change_password"]');
	if (!form) return;
	form = form.closest("form");
	form.addEventListener("submit", function (ev) {
		var a = document.getElementById("new_password");
		var b = document.getElementById("new_password2");
		if (a && b && a.value !== b.value) {
			ev.preventDefault();
			alert("New passwords do not match.");
		}
	});
})();
</script>
<?php mc_member_shell_end(); ?>
