<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/member_drugs.php';
require_once dirname(__DIR__) . '/includes/currency.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$profile = mc_member_load_profile($conn, (int) ($_SESSION['mc_member_id'] ?? 0));
$code = isset($_REQUEST['code']) ? trim((string) $_REQUEST['code']) : '';
$lookup = $code !== '' ? mc_drug_lookup_by_code($conn, $code) : null;
$primary = $lookup ? $lookup[0] : null;

mc_member_shell_start('Verify scan', 'scan', $profile);
mc_member_page_head('Verify product', 'Scan at pickup to confirm expiry, price, manufacturer, and network availability.');
?>
<section class="mc-hub-section">

	<div class="mc-scan-layout">
		<div class="mc-scan-panel">
			<div class="mc-scan-box">
				<div class="mc-scan-actions">
					<button type="button" class="mc-btn mc-btn-inline" id="btnScanStart">Start camera</button>
					<button type="button" class="mc-btn mc-btn-inline secondary" id="btnScanStop">Stop</button>
				</div>
				<div id="member-scanner"></div>
				<p class="mc-hub-muted" id="scanStatus">Point at the barcode or QR on the package.</p>
			</div>

			<form method="get" action="" class="mc-scan-manual">
				<label for="code">Or enter code manually</label>
				<div class="mc-hub-search">
					<input type="text" name="code" id="code" value="<?php echo htmlspecialchars($code, ENT_QUOTES, 'UTF-8'); ?>" placeholder="GTIN / QR payload" autocomplete="off">
					<button type="submit" class="mc-btn">Look up</button>
				</div>
			</form>
		</div>

		<div class="mc-scan-result">
			<?php if ($code !== '' && !$lookup): ?>
				<div class="mc-hub-flash error">No product found for that code. Ask the pharmacy to register the SKU.</div>
			<?php elseif ($primary): ?>
				<article class="mc-hub-card mc-drug-detail">
					<h2><?php echo htmlspecialchars((string) $primary['name'], ENT_QUOTES, 'UTF-8'); ?></h2>
					<p class="mc-hub-pill"><?php echo htmlspecialchars((string) ($primary['category'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></p>
					<dl class="mc-dl">
						<dt>Expiry date</dt>
						<dd><?php
						$exp = $primary['expiry_date'] ?? null;
						if ($exp) {
							echo htmlspecialchars((string) $exp, ENT_QUOTES, 'UTF-8');
							try {
								$ed = new DateTimeImmutable((string) $exp);
								$today = new DateTimeImmutable('today');
								if ($ed < $today) {
									echo ' <span class="mc-tag danger">Expired</span>';
								} elseif ($ed <= $today->modify('+90 days')) {
									echo ' <span class="mc-tag warn">Expiring soon</span>';
								}
							} catch (Throwable $e) {
							}
						} else {
							echo 'Not recorded';
						}
						?></dd>
						<dt>Listed price</dt>
						<dd><?php echo htmlspecialchars(mc_format_etb((float) $primary['shelf_price']), ENT_QUOTES, 'UTF-8'); ?></dd>
						<dt>Barcode</dt>
						<dd><?php echo htmlspecialchars((string) ($primary['barcode'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></dd>
						<dt>Manufacturer</dt>
						<dd><?php echo htmlspecialchars((string) ($primary['manufacturer'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></dd>
						<dt>Reorder level</dt>
						<dd><?php echo (int) ($primary['reorder_level'] ?? 0); ?> units</dd>
					</dl>
					<?php if (!empty($primary['description'])): ?>
						<p><?php echo htmlspecialchars((string) $primary['description'], ENT_QUOTES, 'UTF-8'); ?></p>
					<?php endif; ?>

					<h3>Network availability</h3>
					<ul class="mc-hub-list">
						<?php foreach ($lookup as $row): ?>
							<?php if (!empty($row['pharmacy_name'])): ?>
								<li>
									<strong><?php echo htmlspecialchars((string) $row['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?></strong>
									— <?php echo (int) $row['shelf_qty']; ?> left · <?php echo htmlspecialchars(mc_format_etb((float) $row['shelf_price']), ENT_QUOTES, 'UTF-8'); ?>
									<?php if (!empty($row['pharmacy_id'])): ?>
										<a href="search.php?pharmacy_id=<?php echo (int) $row['pharmacy_id']; ?>&amp;q=<?php echo urlencode((string) $primary['name']); ?>">Order</a>
									<?php endif; ?>
								</li>
							<?php endif; ?>
						<?php endforeach; ?>
						<?php if ((int) ($primary['global_qty'] ?? 0) > 0): ?>
							<li class="mc-hub-muted">Network catalogue total: <?php echo (int) $primary['global_qty']; ?> units indexed.</li>
						<?php endif; ?>
					</ul>
				</article>
			<?php else: ?>
				<p class="mc-hub-muted">Scan or type a code to view product authenticity and shelf information.</p>
			<?php endif; ?>
		</div>
	</div>
</section>
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script src="../js/member-scan.js" defer></script>
<?php mc_member_shell_end(); ?>
