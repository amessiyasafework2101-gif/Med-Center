<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/member_orders.php';
require_once dirname(__DIR__) . '/includes/currency.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$mid = (int) ($_SESSION['mc_member_id'] ?? 0);
$profile = mc_member_load_profile($conn, $mid);

$phCount = 0;
$drugCount = 0;
$orderCount = 0;
$r1 = $conn->query('SELECT COUNT(*) AS c FROM mc_pharmacies WHERE is_active = 1');
if ($r1) {
	$phCount = (int) ($r1->fetch_assoc()['c'] ?? 0);
}
$r2 = $conn->query('SELECT COUNT(*) AS c FROM mc_drugs');
if ($r2) {
	$drugCount = (int) ($r2->fetch_assoc()['c'] ?? 0);
}
$stats = mc_member_order_stats($conn, $mid);
$orderCount = (int) $stats['total'];
$pendingOrders = (int) $stats['pending'];
$awaitingPay = (int) ($stats['awaiting_payment'] ?? 0);
$recentOrders = mc_member_load_recent_orders($conn, $mid, 4);

mc_member_shell_start('Home', 'home', $profile);
?>
<section class="mc-hero-panel">
	<div class="mc-hero-glow" aria-hidden="true"></div>
	<div class="mc-hero-inner">
		<span class="mc-hero-badge">Your health network</span>
		<h1>Welcome back, <?php echo htmlspecialchars((string) $profile['first_name'], ENT_QUOTES, 'UTF-8'); ?></h1>
		<p class="mc-hub-lead">Search medicines across <?php echo $phCount; ?> partner pharmacies, verify packs at pickup, and place orders — all from one place.</p>
		<div class="mc-hub-actions">
			<a class="mc-btn mc-btn-inline" href="search.php">Search &amp; order</a>
			<a class="mc-btn mc-btn-inline secondary" href="scan.php">Scan barcode / QR</a>
			<a class="mc-btn mc-btn-inline secondary" href="../ai/index.php">Dr. Aklilu AI</a>
		</div>
		<div class="mc-stat-row">
			<article class="mc-stat">
				<span class="mc-stat-val"><?php echo $phCount; ?></span>
				<span class="mc-stat-lbl">Pharmacies</span>
			</article>
			<article class="mc-stat">
				<span class="mc-stat-val"><?php echo number_format($drugCount); ?></span>
				<span class="mc-stat-lbl">Medicines indexed</span>
			</article>
			<article class="mc-stat">
				<span class="mc-stat-val"><?php echo $orderCount; ?></span>
				<span class="mc-stat-lbl">Your orders</span>
			</article>
		</div>
	</div>
</section>

<section class="mc-hub-tiles" aria-label="Quick links">
	<a class="mc-hub-tile tile-nearby" href="nearby.php">
		<span class="mc-tile-icon" aria-hidden="true">⌖</span>
		<strong>Nearby map</strong>
		<span>Members vs other pharmacies · nearest first</span>
	</a>
	<a class="mc-hub-tile tile-pharmacies" href="pharmacies.php">
		<span class="mc-tile-icon" aria-hidden="true">✚</span>
		<strong>Our pharmacies</strong>
		<span>Network members · locations &amp; teams</span>
	</a>
	<a class="mc-hub-tile tile-scan" href="scan.php">
		<span class="mc-tile-icon" aria-hidden="true">◎</span>
		<strong>Verify at exchange</strong>
		<span>Scan for expiry, price &amp; authenticity</span>
	</a>
	<a class="mc-hub-tile tile-search" href="search.php">
		<span class="mc-tile-icon" aria-hidden="true">⌕</span>
		<strong>Search inventory</strong>
		<span>Filter by stock, category &amp; pharmacy</span>
	</a>
	<a class="mc-hub-tile tile-orders" href="orders.php">
		<span class="mc-tile-icon" aria-hidden="true">◫</span>
		<strong>My orders</strong>
		<span><?php echo $orderCount; ?> request<?php echo $orderCount === 1 ? '' : 's'; ?> placed</span>
	</a>
	<a class="mc-hub-tile tile-account" href="account.php">
		<span class="mc-tile-icon" aria-hidden="true">◉</span>
		<strong>My account</strong>
		<span>Profile, email &amp; password</span>
	</a>
	<a class="mc-hub-tile tile-about" href="about.php">
		<span class="mc-tile-icon" aria-hidden="true">◈</span>
		<strong>About MediCentral</strong>
		<span>How the platform works for you</span>
	</a>
</section>

<?php if ($awaitingPay > 0): ?>
<section class="mc-hub-section mc-home-alert">
	<p><strong><?php echo $awaitingPay; ?> order<?php echo $awaitingPay === 1 ? '' : 's'; ?></strong> need Tele Birr payment. <a href="orders.php?status=awaiting_payment">Complete payment →</a></p>
</section>
<?php endif; ?>
<?php if ($pendingOrders > 0): ?>
<section class="mc-hub-section mc-home-alert">
	<p><strong><?php echo $pendingOrders; ?> order<?php echo $pendingOrders === 1 ? '' : 's'; ?></strong> awaiting pharmacy confirmation. <a href="orders.php?status=pending">View pending →</a></p>
</section>
<?php endif; ?>

<?php if ($recentOrders): ?>
<section class="mc-hub-section">
	<h2 class="mc-ph-block-title">Recent orders</h2>
	<div class="mc-home-orders">
		<?php foreach ($recentOrders as $ro): ?>
			<a class="mc-home-order-row" href="<?php echo (string) $ro['status'] === 'awaiting_payment' ? 'order-pay.php?order_id=' . (int) $ro['order_id'] : 'orders.php'; ?>">
				<span class="mc-home-order-id">#<?php echo (int) $ro['order_id']; ?></span>
				<span class="mc-home-order-ph"><?php echo htmlspecialchars((string) $ro['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?></span>
				<span class="mc-hub-pill mc-status-<?php echo htmlspecialchars(preg_replace('/[^a-z0-9]/', '', (string) $ro['status']), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(mc_member_order_status_label((string) $ro['status']), ENT_QUOTES, 'UTF-8'); ?></span>
				<span class="mc-home-order-amt"><?php echo htmlspecialchars(mc_format_etb((float) $ro['total_amount']), ENT_QUOTES, 'UTF-8'); ?></span>
			</a>
		<?php endforeach; ?>
	</div>
	<p class="mc-ph-table-cta"><a class="mc-ph-link-btn" href="orders.php">View all orders →</a></p>
</section>
<?php endif; ?>
<?php mc_member_shell_end(); ?>
