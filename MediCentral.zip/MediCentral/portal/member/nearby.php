<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/maps_config.php';
require_once dirname(__DIR__) . '/includes/member_map.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$profile = mc_member_load_profile($conn, (int) ($_SESSION['mc_member_id'] ?? 0));
$mapKey = mc_google_maps_api_key();
$mapId = mc_google_maps_map_id();
$locatorData = mc_map_build_locator_configuration($conn, $mapKey, $mapId);

mc_member_shell_start('Nearby map', 'nearby', $profile);
mc_member_page_head(
	'Nearby pharmacies',
	'Find MediCentral partner pharmacies on the map, then order medicines in Ethiopian Birr from Search & order.'
);
?>
<section class="mc-hub-section mc-map-section mc-locator-section mc-map-only">
	<?php if ($mapKey === ''): ?>
		<div class="mc-hub-flash error">
			Maps are not configured. Add your Google Maps key in <code>portal/includes/maps_config.local.php</code>.
		</div>
	<?php else: ?>
		<p class="mc-map-only-hint">Search an area on the map to locate pharmacies. Tap a location, then use <a href="search.php">Search &amp; order</a> to buy with prescription and Tele Birr payment.</p>
		<div class="mc-locator-host mc-locator-host-full">
			<script type="module" src="https://ajax.googleapis.com/ajax/libs/@googlemaps/extended-component-library/0.6.11/index.min.js"></script>
			<gmpx-api-loader
				key="<?php echo htmlspecialchars($mapKey, ENT_QUOTES, 'UTF-8'); ?>"
				solution-channel="GMP_QB_locatorplus_v11_cABD"></gmpx-api-loader>
			<gmpx-store-locator map-id="<?php echo htmlspecialchars($mapId, ENT_QUOTES, 'UTF-8'); ?>"></gmpx-store-locator>
		</div>
	<?php endif; ?>
</section>
<?php
if ($mapKey !== '') {
	$payload = [
		'configuration' => $locatorData['configuration'],
		'catalog' => $locatorData['catalog'],
	];
	echo '<script>window.MC_LOCATOR_DATA=' . json_encode($payload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) . ';</script>';
	echo '<script type="module" src="../js/member-locator.js"></script>';
}
mc_member_shell_end();
