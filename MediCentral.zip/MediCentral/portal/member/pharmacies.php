<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/currency.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$profile = mc_member_load_profile($conn, (int) ($_SESSION['mc_member_id'] ?? 0));
$viewId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$pharmacies = [];
$sql = <<<'SQL'
SELECT ph.pharmacy_id, ph.name, ph.slug, ph.tagline, ph.address, ph.city, ph.phone,
  (SELECT COUNT(*) FROM mc_pharmacy_inventory i WHERE i.pharmacy_id = ph.pharmacy_id AND i.quantity > 0) AS sku_in_stock,
  (SELECT COUNT(*) FROM mc_pharmacists p WHERE p.pharmacy_id = ph.pharmacy_id AND p.is_active = 1) AS staff_cnt
FROM mc_pharmacies ph
WHERE ph.is_active = 1
ORDER BY ph.name ASC
SQL;
$res = $conn->query($sql);
if ($res) {
	while ($r = $res->fetch_assoc()) {
		$pharmacies[] = $r;
	}
}

$detail = null;
$staff = [];
$inventory = [];
if ($viewId > 0) {
	$st = $conn->prepare(
		'SELECT pharmacy_id, name, tagline, address, city, phone FROM mc_pharmacies WHERE pharmacy_id = ? AND is_active = 1 LIMIT 1'
	);
	if ($st) {
		$st->bind_param('i', $viewId);
		$st->execute();
		$st->bind_result($pid, $pn, $ptg, $paddr, $pcity, $pph);
		if ($st->fetch()) {
			$detail = [
				'pharmacy_id' => $pid,
				'name' => $pn,
				'tagline' => $ptg,
				'address' => $paddr,
				'city' => $pcity,
				'phone' => $pph,
			];
		}
		$st->close();
	}
	if ($detail) {
		$sq = $conn->prepare(
			'SELECT username, first_name, last_name, email FROM mc_pharmacists WHERE pharmacy_id = ? AND is_active = 1 ORDER BY first_name'
		);
		if ($sq) {
			$sq->bind_param('i', $viewId);
			$sq->execute();
			$sq->bind_result($su, $sf, $sl, $se);
			while ($sq->fetch()) {
				$staff[] = ['username' => $su, 'first_name' => $sf, 'last_name' => $sl, 'email' => $se];
			}
			$sq->close();
		}
		$si = $conn->prepare(
			'SELECT d.name, d.category, i.quantity, COALESCE(i.unit_price, d.unit_price) AS price
			FROM mc_pharmacy_inventory i
			INNER JOIN mc_drugs d ON d.drug_id = i.drug_id
			WHERE i.pharmacy_id = ? AND i.quantity > 0
			ORDER BY d.name ASC LIMIT 30'
		);
		if ($si) {
			$si->bind_param('i', $viewId);
			$si->execute();
			$si->bind_result($dn, $dc, $iq, $ip);
			while ($si->fetch()) {
				$inventory[] = ['name' => $dn, 'category' => $dc, 'quantity' => $iq, 'price' => $ip];
			}
			$si->close();
		}
	}
}

mc_member_shell_start($detail ? (string) $detail['name'] : 'Our pharmacies', 'pharmacies', $profile);
if ($detail) {
	mc_member_page_head((string) $detail['name'], 'Pharmacy profile, team, and live shelf highlights.');
} else {
	mc_member_page_head('Our pharmacies', 'Browse partner locations on the MediCentral network.');
}
?>
<section class="mc-hub-section mc-ph-section">
	<?php if (!$detail): ?>
		<p class="mc-ph-table-cta" style="margin-top:0;"><a class="mc-ph-link-btn" href="nearby.php">Open nearby map →</a></p>
	<?php endif; ?>

	<?php if ($detail): ?>
		<nav class="mc-ph-breadcrumb" aria-label="Breadcrumb">
			<a href="pharmacies.php">Our pharmacies</a>
			<span class="mc-ph-crumb-sep" aria-hidden="true">/</span>
			<span><?php echo htmlspecialchars((string) $detail['name'], ENT_QUOTES, 'UTF-8'); ?></span>
		</nav>

		<article class="mc-ph-hero">
			<div class="mc-ph-hero-body">
				<?php if (!empty($detail['tagline'])): ?>
					<p class="mc-ph-tagline"><?php echo htmlspecialchars((string) $detail['tagline'], ENT_QUOTES, 'UTF-8'); ?></p>
				<?php endif; ?>
				<ul class="mc-ph-facts">
					<li>
						<span class="mc-ph-fact-lbl">Location</span>
						<span><?php echo htmlspecialchars(trim((string) ($detail['address'] ?? '') . ', ' . ($detail['city'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></span>
					</li>
					<li>
						<span class="mc-ph-fact-lbl">Phone</span>
						<span><?php echo htmlspecialchars((string) ($detail['phone'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></span>
					</li>
				</ul>
			</div>
			<div class="mc-ph-hero-actions">
				<a class="mc-btn mc-btn-inline" href="search.php?pharmacy_id=<?php echo (int) $detail['pharmacy_id']; ?>">Order from here</a>
				<a class="mc-btn mc-btn-inline secondary" href="pharmacies.php">All pharmacies</a>
			</div>
		</article>

		<div class="mc-ph-block">
			<h2 class="mc-ph-block-title">Pharmacy team</h2>
			<?php if (!$staff): ?>
				<p class="mc-hub-muted">Staff roster not linked yet — you can still place orders with this pharmacy.</p>
			<?php else: ?>
				<div class="mc-hub-grid mc-ph-team-grid">
					<?php foreach ($staff as $s): ?>
						<article class="mc-hub-card mc-ph-team-card">
							<span class="mc-ph-team-avatar" aria-hidden="true"><?php echo htmlspecialchars(mb_strtoupper(mb_substr((string) $s['first_name'], 0, 1, 'UTF-8'), 'UTF-8'), ENT_QUOTES, 'UTF-8'); ?></span>
							<h3><?php echo htmlspecialchars(trim((string) $s['first_name'] . ' ' . ($s['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></h3>
							<p class="mc-hub-meta">@<?php echo htmlspecialchars((string) $s['username'], ENT_QUOTES, 'UTF-8'); ?></p>
							<?php if ($s['email']): ?>
								<p class="mc-hub-meta mc-ph-email"><?php echo htmlspecialchars((string) $s['email'], ENT_QUOTES, 'UTF-8'); ?></p>
							<?php endif; ?>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<div class="mc-ph-block">
			<h2 class="mc-ph-block-title">In-stock highlights</h2>
			<?php if (!$inventory): ?>
				<p class="mc-hub-muted">No shelf stock listed at the moment.</p>
			<?php else: ?>
				<div class="mc-hub-table-wrap">
					<table class="mc-hub-table">
						<thead><tr><th>Product</th><th>Category</th><th>Qty</th><th>Price</th></tr></thead>
						<tbody>
						<?php foreach ($inventory as $row): ?>
							<tr>
								<td><?php echo htmlspecialchars((string) $row['name'], ENT_QUOTES, 'UTF-8'); ?></td>
								<td><?php echo htmlspecialchars((string) $row['category'], ENT_QUOTES, 'UTF-8'); ?></td>
								<td><?php echo (int) $row['quantity']; ?></td>
								<td><?php echo htmlspecialchars(mc_format_etb((float) $row['price']), ENT_QUOTES, 'UTF-8'); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<p class="mc-ph-table-cta">
					<a class="mc-ph-link-btn" href="search.php?pharmacy_id=<?php echo (int) $detail['pharmacy_id']; ?>">Search full inventory →</a>
				</p>
			<?php endif; ?>
		</div>

	<?php else: ?>
		<?php if (!$pharmacies): ?>
			<p class="mc-hub-muted">No partner pharmacies are listed yet. Check back soon.</p>
		<?php else: ?>
			<div class="mc-ph-grid">
				<?php foreach ($pharmacies as $p): ?>
					<a class="mc-ph-tile" href="pharmacies.php?id=<?php echo (int) $p['pharmacy_id']; ?>">
						<span class="mc-ph-tile-icon" aria-hidden="true">✚</span>
						<span class="mc-ph-tile-city"><?php echo htmlspecialchars((string) ($p['city'] ?? 'Network'), ENT_QUOTES, 'UTF-8'); ?></span>
						<h3 class="mc-ph-tile-name"><?php echo htmlspecialchars((string) $p['name'], ENT_QUOTES, 'UTF-8'); ?></h3>
						<?php if (!empty($p['tagline'])): ?>
							<p class="mc-ph-tile-tag"><?php echo htmlspecialchars((string) $p['tagline'], ENT_QUOTES, 'UTF-8'); ?></p>
						<?php endif; ?>
						<div class="mc-ph-tile-stats">
							<span class="mc-ph-stat"><?php echo (int) $p['sku_in_stock']; ?> in stock</span>
							<span class="mc-ph-stat"><?php echo (int) $p['staff_cnt']; ?> staff</span>
						</div>
						<span class="mc-ph-tile-arrow" aria-hidden="true">View profile →</span>
					</a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</section>
<?php mc_member_shell_end(); ?>
