<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/member_order_payment.php';
require_once dirname(__DIR__) . '/includes/member_orders.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';

$mid = (int) ($_SESSION['mc_member_id'] ?? 0);
$profile = mc_member_load_profile($conn, $mid);
$orderId = (int) ($_GET['order_id'] ?? $_POST['order_id'] ?? 0);
$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_telebirr'])) {
	$tx = trim((string) ($_POST['telebirr_transaction_id'] ?? ''));
	$res = mc_member_submit_telebirr_payment($conn, $mid, $orderId, $tx);
	$flash = $res['msg'];
	$flashKind = $res['ok'] ? 'success' : 'error';
	if ($res['ok']) {
		header('Location: orders.php?status=pending');
		exit;
	}
}

$order = $orderId > 0 ? mc_member_load_order_for_payment($conn, $mid, $orderId) : null;
if ($order === null) {
	header('Location: orders.php');
	exit;
}

mc_member_shell_start('Complete payment', 'orders', $profile);
mc_member_page_head('Pay with Tele Birr', 'Send payment to the pharmacy, then enter your transaction ID.');
if ($flash) {
	mc_member_flash($flash, $flashKind);
}
$phone = (string) $order['telebirr_display_phone'];
$st = (string) $order['status'];
?>
<section class="mc-hub-section mc-pay-section">
	<article class="mc-hub-card mc-pay-card">
		<h2>Order #<?php echo (int) $order['order_id']; ?> · <?php echo htmlspecialchars((string) $order['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
		<ul class="mc-hub-list">
			<?php foreach ($order['lines'] as $ln): ?>
				<li><?php echo htmlspecialchars((string) $ln['name'], ENT_QUOTES, 'UTF-8'); ?> × <?php echo (int) $ln['qty']; ?> — <?php echo htmlspecialchars(mc_format_etb((float) $ln['line_total']), ENT_QUOTES, 'UTF-8'); ?></li>
			<?php endforeach; ?>
		</ul>
		<p class="mc-order-total"><strong>Total <?php echo htmlspecialchars(mc_format_etb((float) $order['total_amount']), ENT_QUOTES, 'UTF-8'); ?></strong></p>

		<?php if ($st === 'awaiting_payment'): ?>
		<div class="mc-pay-steps">
			<h3>Tele Birr payment</h3>
			<ol class="mc-pay-ol">
				<li>Open the <strong>Tele Birr</strong> app on your phone.</li>
				<li>Send <strong><?php echo htmlspecialchars(mc_format_etb((float) $order['total_amount']), ENT_QUOTES, 'UTF-8'); ?></strong> to:</li>
			</ol>
			<p class="mc-pay-phone"><?php echo $phone !== '' ? htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') : 'Phone not set — contact the pharmacy'; ?></p>
			<p class="mc-hub-muted">Use the pharmacy’s registered Tele Birr number. Include your name in the payment note if possible.</p>
			<form method="post" class="mc-pay-form">
				<input type="hidden" name="order_id" value="<?php echo (int) $order['order_id']; ?>">
				<div class="mc-field-lite">
					<label for="telebirr_transaction_id">Tele Birr transaction ID</label>
					<input type="text" id="telebirr_transaction_id" name="telebirr_transaction_id" required minlength="6" maxlength="40" pattern="[A-Za-z0-9\-]+" placeholder="e.g. from SMS or receipt" autocomplete="off">
					<p class="mc-hub-muted mc-tx-hint">Copy the reference from your Tele Birr SMS or app receipt after you pay.</p>
				</div>
				<div class="mc-tx-verify-actions">
					<button type="button" id="mc-telebirr-check" class="mc-btn mc-btn-ghost">Ask Dr. Aklilu if this ID looks real</button>
				</div>
				<div id="mc-telebirr-verify-result" class="mc-tx-verify" hidden role="status"></div>
				<button type="submit" name="submit_telebirr" value="1" class="mc-btn mc-btn-inline">Submit payment</button>
			</form>
		</div>
		<?php elseif ($order['telebirr_transaction_id']): ?>
		<p class="mc-hub-muted">Transaction ID: <strong><?php echo htmlspecialchars((string) $order['telebirr_transaction_id'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
		<p class="mc-hub-muted">Status: <?php echo htmlspecialchars(mc_member_order_status_label($st), ENT_QUOTES, 'UTF-8'); ?></p>
		<?php endif; ?>

		<p class="mc-hub-muted" style="margin-top:1rem;"><a href="orders.php">← Back to orders</a></p>
	</article>
</section>
<?php if ($st === 'awaiting_payment'): ?>
<script src="../js/mc-telebirr-verify.js" defer></script>
<?php endif; ?>
<?php mc_member_shell_end(); ?>
