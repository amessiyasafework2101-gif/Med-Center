<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_member.php';
require_once dirname(__DIR__) . '/includes/member_shell.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';
require_once dirname(__DIR__) . '/includes/pharmacist_ratings.php';
require_once dirname(__DIR__) . '/includes/chat_ui.php';

$mid = (int) ($_SESSION['mc_member_id'] ?? 0);
$profile = mc_member_load_profile($conn, $mid);
$flash = null;
$flashKind = 'success';
$selectedPh = isset($_GET['pharmacist_id']) ? (int) $_GET['pharmacist_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$action = (string) ($_POST['action'] ?? '');
	$phId = (int) ($_POST['pharmacist_id'] ?? 0);
	if ($action === 'rate' && $phId > 0) {
		$score = (int) ($_POST['score'] ?? 0);
		$comment = trim((string) ($_POST['comment'] ?? ''));
		$res = mc_pharmacist_save_rating($conn, $phId, 'member', $score, $comment, $mid, null);
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
		$selectedPh = $phId;
	} elseif ($action === 'message' && $phId > 0) {
		$body = trim((string) ($_POST['body'] ?? ''));
		if ($body !== '') {
			mc_pharmacist_post_message($conn, $phId, 'user', 'member', $body, $mid, null, null);
			$flash = 'Message sent.';
			$selectedPh = $phId;
		}
	}
}

$list = mc_pharmacist_list_approved($conn, 50);
$selectedRow = null;
$messages = [];
$myRating = null;
if ($selectedPh > 0) {
	foreach ($list as $ph) {
		if ((int) $ph['pharmacist_id'] === $selectedPh) {
			$selectedRow = $ph;
			break;
		}
	}
	if ($selectedRow) {
		$messages = mc_chat_thread_member_pharmacist($conn, $selectedPh, $mid);
		$myRating = mc_pharmacist_get_member_rating($conn, $selectedPh, $mid);
	}
}

mc_member_shell_start('Pharmacists', 'pharmacists', $profile);
echo '<link rel="stylesheet" href="../css/mc-chat.css">';
mc_member_page_head('Find pharmacists', 'Rate professionals and chat in real time. Ratings update their performance score for pharmacy invitations.');
if ($flash) {
	mc_member_flash($flash, $flashKind);
}
?>
<div class="mc-ph-dir-layout">
	<aside class="mc-ph-dir-list">
		<h2 class="mc-ph-block-title">Pharmacists</h2>
		<?php if (!$list): ?>
			<p class="mc-hub-muted">No pharmacists available yet.</p>
		<?php else: ?>
			<?php foreach ($list as $ph):
				$pid = (int) $ph['pharmacist_id'];
				$active = $pid === $selectedPh ? ' is-active' : '';
				?>
				<a class="mc-ph-dir-item<?php echo $active; ?>" href="pharmacists.php?pharmacist_id=<?php echo $pid; ?>">
					<strong><?php echo htmlspecialchars(trim($ph['first_name'] . ' ' . ($ph['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></strong>
					<?php echo mc_pharmacist_render_stars((float) $ph['performance_score'], true, (int) $ph['rating_count']); ?>
				</a>
			<?php endforeach; ?>
		<?php endif; ?>
	</aside>

	<section class="mc-ph-dir-detail">
		<?php if (!$selectedRow): ?>
			<p class="mc-hub-muted">Select a pharmacist to rate them and open chat.</p>
		<?php else: ?>
			<header class="mc-ph-dir-header">
				<h2><?php echo htmlspecialchars(trim($selectedRow['first_name'] . ' ' . ($selectedRow['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></h2>
				<?php echo mc_pharmacist_render_stars((float) $selectedRow['performance_score'], true, (int) $selectedRow['rating_count']); ?>
				<?php if (!empty($selectedRow['bio'])): ?>
					<p class="mc-hub-muted"><?php echo htmlspecialchars((string) $selectedRow['bio'], ENT_QUOTES, 'UTF-8'); ?></p>
				<?php endif; ?>
			</header>

			<form method="post" class="mc-rate-form">
				<input type="hidden" name="action" value="rate">
				<input type="hidden" name="pharmacist_id" value="<?php echo (int) $selectedPh; ?>">
				<?php mc_rating_render_picker('score', $myRating ? (int) $myRating['score'] : 0, $myRating ? 'Update your rating' : 'Your rating'); ?>
				<input type="text" name="comment" class="mc-rate-comment" maxlength="500" placeholder="Optional comment (helps pharmacy admins decide)" value="<?php echo htmlspecialchars($myRating['comment'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
				<button type="submit" class="mc-btn mc-btn-inline">Save rating</button>
			</form>

			<h3 class="mc-ph-block-title" style="margin-top:1.25rem;">Chat</h3>
			<?php mc_chat_render_bubbles($messages, 'member'); ?>
			<?php mc_chat_render_composer('Message this pharmacist…', ['action' => 'message', 'pharmacist_id' => (string) $selectedPh]); ?>
		<?php endif; ?>
	</section>
</div>
<script src="../js/mc-star-rating.js" defer></script>
<?php
mc_member_shell_end();
