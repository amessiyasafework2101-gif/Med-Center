<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/auth_helpers.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';
require_once dirname(__DIR__) . '/includes/member_context.php';
require_once dirname(__DIR__) . '/includes/dr_aklilu_ui.php';
require_once dirname(__DIR__) . '/includes/site_footer.php';
require_once dirname(__DIR__) . '/includes/site_nav.php';

mc_session_start();
mc_set_signin_portal('network');

$role = (string) ($_SESSION['mc_role'] ?? '');
$portal = 'network';
$showCv = false;
$backHref = '../index.php';
$backLabel = 'Sign in';
$displayName = 'Guest';
$pageTitle = 'Dr. Aklilu AI';

if ($role === 'member' && (int) ($_SESSION['mc_member_id'] ?? 0) > 0) {
	$mid = (int) $_SESSION['mc_member_id'];
	$profile = mc_member_load_profile($conn, $mid);
	$displayName = (string) ($profile['display'] ?? 'Member');
	$backHref = '../member/index.php';
	$backLabel = 'Member home';
} elseif ($role === 'pharmacist' && (int) ($_SESSION['mc_pharmacist_id'] ?? 0) > 0) {
	$pid = (int) $_SESSION['mc_pharmacist_id'];
	$p = mc_pharmacist_load($conn, $pid);
	if ($p) {
		$displayName = trim((string) ($p['first_name'] ?? '') . ' ' . (string) ($p['last_name'] ?? ''));
	}
	$showCv = true;
	if ($p && !mc_pharmacist_is_approved($p)) {
		$backHref = '../pharmacist/pending.php';
		$backLabel = 'Application status';
	} else {
		$backHref = '../pharmacist/index.php';
		$backLabel = 'Pharmacist home';
	}
} else {
	header('Location: ../index.php?ai=1');
	exit;
}

$safeName = htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?> · MediCentral</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400..700&family=Outfit:wght@500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../css/signin.css">
	<link rel="stylesheet" href="../css/public-pages.css">
	<link rel="stylesheet" href="../css/dr-aklilu.css">
</head>
<body class="dr-ak-page-body">
	<div class="dr-ak-page-wrap">
		<header class="dr-ak-page-top">
			<a href="<?php echo htmlspecialchars((mc_site_nav_items('ai', '../')[0]['href'] ?? '../index.php'), ENT_QUOTES, 'UTF-8'); ?>" class="dr-ak-page-brand"><strong>MediCentral</strong><span>Dr. Aklilu AI</span></a>
			<?php mc_render_site_nav_bar('ai', mc_site_nav_items('ai', '../'), 'dr-ak-page-nav mc-pub-nav'); ?>
			<span class="dr-ak-page-user"><?php echo $safeName; ?></span>
		</header>
		<?php
		mc_dr_aklilu_render_ui($portal, '../', 'page', $showCv, $backHref, $backLabel);
		mc_render_site_footer('../');
		?>
	</div>
	<script src="../js/dr-aklilu-format.js" defer></script>
	<script src="../js/dr-aklilu.js" defer></script>
</body>
</html>
