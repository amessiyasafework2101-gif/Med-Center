<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/public_page.php';

mc_session_start();

mc_public_page_start('About us', 'about', '');
?>
<section class="mc-pub-card">
	<h1>About MediCentral</h1>
	<p class="mc-pub-lead">We connect members, pharmacists, and pharmacy partners on one trusted platform — from medicine search and orders to professional collaboration.</p>

	<div class="mc-pub-grid">
		<article class="mc-pub-block">
			<h2>For members</h2>
			<ul>
				<li><strong>Search</strong> medicines across partner pharmacies with live stock filters.</li>
				<li><strong>Verify</strong> packs at pickup with barcode or QR scanning.</li>
				<li><strong>Order</strong> directly from pharmacies on the network.</li>
				<li><strong>Dr. Aklilu AI</strong> for general health education and medicine guidance after sign-in.</li>
			</ul>
		</article>
		<article class="mc-pub-block">
			<h2>For pharmacists</h2>
			<ul>
				<li>Join the professional network with <strong>optional</strong> CV and license verification.</li>
				<li>Chat with members, receive work offers, and use <strong>Dr. Aklilu</strong> for clinical support.</li>
				<li>Access POS and inventory tools when linked to a pharmacy team.</li>
			</ul>
		</article>
		<article class="mc-pub-block">
			<h2>For pharmacy partners</h2>
			<p>Licensed pharmacies manage inventory, dispensing, member orders, and staff through the operations portal. Network administrators oversee quality and compliance.</p>
		</article>
		<article class="mc-pub-block">
			<h2>Trust &amp; safety</h2>
			<p>MediCentral provides catalogue and workflow tools — not a replacement for prescriptions, emergency care, or face-to-face clinical judgement. Always consult a qualified professional for personal medical decisions.</p>
		</article>
	</div>

	<p class="mc-pub-cta"><a class="mc-btn" href="contact.php">Contact us</a> <a class="mc-btn secondary" href="index.php">Sign in</a></p>
</section>
<?php mc_public_page_end(); ?>
