<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/username_format.php';
require_once __DIR__ . '/includes/auth_helpers.php';
require_once __DIR__ . '/includes/signin_handlers.php';
require_once __DIR__ . '/includes/signin_view.php';

mc_session_start();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
	mc_auth_redirect_if_logged_in($conn, 'network');
}

$error = '';
if (isset($_GET['pharmacist']) && (string) $_GET['pharmacist'] === 'rejected') {
	$error = 'Your pharmacist application was not approved. Contact support if you believe this is an error.';
}
$uname_display = '';
$role = isset($_POST['role']) ? (string) $_POST['role'] : 'member';
if (!in_array($role, ['member', 'staff'], true)) {
	$role = 'member';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
	$uname = isset($_POST['uname']) ? trim((string) $_POST['uname']) : '';
	$pwd = isset($_POST['pwd']) ? trim((string) $_POST['pwd']) : '';

	if ($uname === '' || $pwd === '') {
		$error = 'Enter both username and password to continue.';
		$uname_display = $uname !== '' ? mc_format_signin_username($uname) : '';
	} else {
		$uname_display = mc_format_signin_username($uname);
		$userNorm = mc_normalize_login_username($uname);

		if ($role === 'member') {
			$result = mc_signin_attempt_member($conn, $userNorm, $pwd);
			$error = $result['error'];
		} else {
			$result = mc_signin_attempt_pharmacist_network($conn, $userNorm, $pwd);
			$error = $result['error'];
		}
	}
}

mc_render_signin_page([
	'portal' => 'network',
	'page_title' => 'Network sign in · MediCentral',
	'badge' => 'Member & pharmacist network',
	'headline' => 'Every pharmacy.',
	'headline_span' => 'One connected platform.',
	'blurb' => 'Search drugs, order across pharmacies, connect with pharmacists, and manage your care on the MediCentral network.',
	'card_title' => 'Network sign in',
	'card_sub' => 'For members and pharmacists. Optional CV/license for verified status — or sign up and chat with Dr. Aklilu right away.',
	'roles' => [
		['id' => 'roleMember', 'value' => 'member', 'label' => 'Member', 'checked' => $role === 'member'],
		['id' => 'roleStaff', 'value' => 'staff', 'label' => 'Pharmacist', 'checked' => $role === 'staff'],
	],
	'error' => $error,
	'uname_display' => $uname_display,
	'mini_link_html' => 'New here? <a href="signup.php">Create a member account</a> · <a href="pharmacist-signup.php">Register as a pharmacist</a>',
	'foot_html' => 'Pharmacy inventory &amp; POS? <a href="pharmacy/signin.php">Operations sign-in</a> · <a href="pharmacy/register.php">Register pharmacy</a>',
	'switch_label' => '→ Pharmacy inventory &amp; POS sign-in',
	'switch_href' => 'pharmacy/signin.php',
	'form_action' => '',
	'asset_prefix' => '',
]);
