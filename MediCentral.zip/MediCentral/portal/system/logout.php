<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/session.php';

mc_session_start();
unset($_SESSION['mc_role'], $_SESSION['mc_system_admin_id'], $_SESSION['mc_system_display'], $_SESSION['mc_username']);
$_SESSION = [];
session_destroy();
mc_clear_session_cookie();
session_write_close();

header('Location: index.php');
exit;
