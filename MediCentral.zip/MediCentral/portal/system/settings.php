<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$adminId = (int) ($_SESSION['mc_system_admin_id'] ?? 0);
$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action'])) {
	$action = (string) $_POST['mc_action'];

	if ($action === 'profile') {
		$name = trim((string) ($_POST['display_name'] ?? ''));
		$email = trim((string) ($_POST['email'] ?? ''));
		$mail = $email === '' ? null : $email;
		if ($name === '') {
			$flashKind = 'error';
			$flash = 'Display name is required.';
		} else {
			$stmt = $conn->prepare('UPDATE mc_system_admins SET display_name = ?, email = ? WHERE system_admin_id = ? LIMIT 1');
			if ($stmt) {
				$stmt->bind_param('ssi', $name, $mail, $adminId);
				if ($stmt->execute()) {
					$_SESSION['mc_system_display'] = $name;
					$flash = 'Profile updated.';
					mc_system_audit_log($conn, 'profile_update', 'system_admin', $adminId, 'Updated system admin profile');
				}
				$stmt->close();
			}
		}
	} elseif ($action === 'password') {
		$cur = (string) ($_POST['current_password'] ?? '');
		$new = (string) ($_POST['new_password'] ?? '');
		$confirm = (string) ($_POST['confirm_password'] ?? '');
		if (strlen($new) < 12) {
			$flashKind = 'error';
			$flash = 'New password must be at least 12 characters.';
		} elseif ($new !== $confirm) {
			$flashKind = 'error';
			$flash = 'Passwords do not match.';
		} else {
			$stmt = $conn->prepare('SELECT password_hash FROM mc_system_admins WHERE system_admin_id = ? LIMIT 1');
			if ($stmt) {
				$stmt->bind_param('i', $adminId);
				$stmt->execute();
				$stmt->bind_result($hashDb);
				$ok = $stmt->fetch() && password_verify($cur, $hashDb);
				$stmt->close();
				if (!$ok) {
					$flashKind = 'error';
					$flash = 'Current password is incorrect.';
				} else {
					$h = password_hash($new, PASSWORD_DEFAULT);
					$upd = $conn->prepare('UPDATE mc_system_admins SET password_hash = ? WHERE system_admin_id = ? LIMIT 1');
					if ($upd) {
						$upd->bind_param('si', $h, $adminId);
						if ($upd->execute()) {
							$flash = 'Password changed successfully.';
							mc_system_audit_log($conn, 'password_change', 'system_admin', $adminId, 'System admin password changed');
						}
						$upd->close();
					}
				}
			}
		}
	}
}

$row = null;
$stmt = $conn->prepare('SELECT username, display_name, email FROM mc_system_admins WHERE system_admin_id = ? LIMIT 1');
if ($stmt) {
	$stmt->bind_param('i', $adminId);
	$stmt->execute();
	$res = $stmt->get_result();
	$row = $res ? $res->fetch_assoc() : null;
	$stmt->close();
}

mc_system_shell_start('Security', 'settings');
if ($flash) {
	mc_system_flash($flash, $flashKind);
}
?>
<div class="sys-split">
	<section class="sys-panel">
		<h2>Your profile</h2>
		<form method="post" class="sys-form">
			<input type="hidden" name="mc_action" value="profile">
			<label>Username
				<input type="text" value="<?php echo htmlspecialchars((string) ($row['username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" disabled>
			</label>
			<label>Display name
				<input type="text" name="display_name" required value="<?php echo htmlspecialchars((string) ($row['display_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
			</label>
			<label>Email
				<input type="email" name="email" value="<?php echo htmlspecialchars((string) ($row['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
			</label>
			<button type="submit" class="sys-btn sys-btn-primary">Save profile</button>
		</form>
	</section>

	<section class="sys-panel">
		<h2>Change password</h2>
		<form method="post" class="sys-form">
			<input type="hidden" name="mc_action" value="password">
			<label>Current password <input type="password" name="current_password" required autocomplete="current-password"></label>
			<label>New password <input type="password" name="new_password" minlength="12" required autocomplete="new-password"></label>
			<label>Confirm new password <input type="password" name="confirm_password" minlength="12" required></label>
			<button type="submit" class="sys-btn sys-btn-primary">Update password</button>
		</form>
	</section>
</div>

<section class="sys-panel sys-panel-muted">
	<h2>Access configuration</h2>
	<ul class="sys-list">
		<li>Direct URL: <code>/MediCentral/portal/system/</code></li>
		<li>Gate password: <code>includes/system_config.local.php</code> → <code>MC_SYSTEM_GATE_PASSWORD</code></li>
		<li>Not linked from the public sign-in page</li>
	</ul>
</section>
<?php
mc_system_shell_end();
