<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/system_auth.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

mc_session_start();

if (mc_system_is_logged_in()) {
	header('Location: dashboard.php');
	exit;
}

$step = isset($_GET['step']) ? (string) $_GET['step'] : 'gate';
$error = '';
$gateConfigured = mc_system_gate_password() !== '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$form = (string) ($_POST['form'] ?? '');

	if ($form === 'gate') {
		$pw = (string) ($_POST['gate_password'] ?? '');
		if (!$gateConfigured) {
			$error = 'System gate password is not configured. Set MC_SYSTEM_GATE_PASSWORD in portal/includes/system_config.local.php';
		} elseif (mc_system_verify_gate_password($pw)) {
			mc_system_unlock_gate();
			header('Location: index.php?step=login');
			exit;
		} else {
			$error = 'Incorrect access password.';
		}
	} elseif ($form === 'login' && mc_system_gate_unlocked()) {
		$user = (string) ($_POST['username'] ?? '');
		$pw = (string) ($_POST['password'] ?? '');
		$result = mc_system_attempt_login($conn, $user, $pw);
		if ($result['ok'] && isset($result['admin'])) {
			$a = $result['admin'];
			mc_system_start_session((int) $a['system_admin_id'], (string) $a['username'], (string) $a['display_name']);
			mc_system_touch_login($conn, (int) $a['system_admin_id']);
			mc_system_audit_log($conn, 'login', 'system_admin', (int) $a['system_admin_id'], 'System administrator signed in');
			header('Location: dashboard.php');
			exit;
		}
		$error = $result['error'];
	} elseif ($form === 'login') {
		header('Location: index.php');
		exit;
	}
}

if ($step === 'login' && !mc_system_gate_unlocked()) {
	header('Location: index.php');
	exit;
}

$showLogin = $step === 'login' && mc_system_gate_unlocked();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>System access · MediCentral</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../css/system-admin.css">
</head>
<body class="sys-gate-body">
	<div class="sys-gate-card">
		<div class="sys-gate-mark" aria-hidden="true">⬡</div>
		<h1>System control</h1>
		<p class="sys-gate-lead">Main administrator access — not listed on the public site. Enter the access password, then sign in.</p>

		<?php if ($error !== ''): ?>
			<div class="sys-flash error" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
		<?php endif; ?>

		<?php if (!$gateConfigured): ?>
			<div class="sys-flash error">Configure <code>MC_SYSTEM_GATE_PASSWORD</code> in <code>includes/system_config.local.php</code> first.</div>
		<?php elseif ($showLogin): ?>
			<form method="post" class="sys-form">
				<input type="hidden" name="form" value="login">
				<label>System administrator username
					<input type="text" name="username" autocomplete="username" required autofocus>
				</label>
				<label>Password
					<input type="password" name="password" autocomplete="current-password" required>
				</label>
				<button type="submit" class="sys-btn sys-btn-primary">Enter control panel</button>
			</form>
			<p class="sys-gate-foot">Default seed account: <code>nahi</code> — change password after first login in Security.</p>
		<?php else: ?>
			<form method="post" class="sys-form">
				<input type="hidden" name="form" value="gate">
				<label>Access password
					<input type="password" name="gate_password" autocomplete="off" required autofocus placeholder="Direct URL gate password">
				</label>
				<button type="submit" class="sys-btn sys-btn-primary">Continue</button>
			</form>
		<?php endif; ?>
		<p class="sys-gate-public">
			<a class="sys-link" href="../member/index.php">Member portal (public site)</a>
			·
			<a class="sys-link" href="../pharmacy/signin.php">Operations sign-in</a>
			·
			<a class="sys-link" href="../index.php">Network sign-in</a>
		</p>
	</div>
</body>
</html>
