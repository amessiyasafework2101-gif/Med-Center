<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_pharmacies.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$stats = mc_system_network_stats($conn);
$recent = mc_system_audit_recent($conn, 12);
$pharmacies = mc_system_pharmacy_list($conn, 'license_expiring');

mc_system_shell_start('Command center', 'dashboard');
?>
<div class="sys-kpi-grid">
	<article class="sys-kpi"><span class="sys-kpi-label">Network pharmacies</span><strong><?php echo (int) $stats['pharmacies_active']; ?></strong><small><?php echo (int) $stats['pharmacies']; ?> total · <?php echo (int) $stats['pharmacies_verified']; ?> verified</small></article>
	<article class="sys-kpi warn"><span class="sys-kpi-label">Licenses expiring (60d)</span><strong><?php echo (int) $stats['license_expiring']; ?></strong><small><a href="pharmacies.php?filter=license_expiring">Review →</a></small></article>
	<article class="sys-kpi"><span class="sys-kpi-label">Members</span><strong><?php echo (int) $stats['members_active']; ?></strong><small><?php echo (int) $stats['members']; ?> registered</small></article>
	<article class="sys-kpi"><span class="sys-kpi-label">Pharmacists</span><strong><?php echo (int) $stats['pharmacists']; ?></strong><small>Staff accounts</small></article>
	<article class="sys-kpi"><span class="sys-kpi-label">Member orders</span><strong><?php echo (int) $stats['orders']; ?></strong><small><?php echo (int) $stats['orders_pending']; ?> pending</small></article>
	<article class="sys-kpi"><span class="sys-kpi-label">Portal admins</span><strong><?php echo (int) $stats['admins']; ?></strong><small>Operational administrators</small></article>
</div>

<section class="sys-panel">
	<h2>Quick actions</h2>
	<div class="sys-actions">
		<a class="sys-btn sys-btn-primary" href="pharmacy.php">+ Register pharmacy</a>
		<a class="sys-btn" href="pharmacies.php">Manage pharmacies</a>
		<a class="sys-btn sys-btn-primary" href="admins.php">+ Pharmacy admin</a>
		<a class="sys-btn" href="members.php">Members</a>
		<a class="sys-btn" href="orders.php">Member orders</a>
	</div>
</section>

<?php if ($pharmacies !== []): ?>
<section class="sys-panel">
	<h2>License alerts</h2>
	<div class="sys-table-wrap">
		<table class="sys-table">
			<thead><tr><th>Pharmacy</th><th>License</th><th>Expires</th><th></th></tr></thead>
			<tbody>
			<?php foreach ($pharmacies as $p): ?>
				<tr>
					<td><?php echo htmlspecialchars((string) $p['name'], ENT_QUOTES, 'UTF-8'); ?></td>
					<td><?php echo htmlspecialchars((string) ($p['license_number'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></td>
					<td><span class="sys-tag warn"><?php echo htmlspecialchars((string) $p['license_expiry'], ENT_QUOTES, 'UTF-8'); ?></span></td>
					<td><a href="pharmacy.php?id=<?php echo (int) $p['pharmacy_id']; ?>">Edit</a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</section>
<?php endif; ?>

<section class="sys-panel">
	<h2>Recent system activity</h2>
	<div class="sys-table-wrap">
		<table class="sys-table compact">
			<thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Summary</th></tr></thead>
			<tbody>
			<?php foreach ($recent as $a): ?>
				<tr>
					<td><?php echo htmlspecialchars((string) $a['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
					<td><?php echo htmlspecialchars((string) $a['actor_name'], ENT_QUOTES, 'UTF-8'); ?></td>
					<td><code><?php echo htmlspecialchars((string) $a['action'], ENT_QUOTES, 'UTF-8'); ?></code></td>
					<td><?php echo htmlspecialchars((string) ($a['summary'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<p class="sys-muted"><a href="audit.php">Full audit log →</a></p>
</section>
<?php
mc_system_shell_end();
