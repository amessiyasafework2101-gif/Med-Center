<?php

declare(strict_types=1);

header('Location: admins.php');
exit;
