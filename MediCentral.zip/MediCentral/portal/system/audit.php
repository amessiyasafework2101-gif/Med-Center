<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$logs = mc_system_audit_recent($conn, 150);

mc_system_shell_start('Audit log', 'audit');
?>
<p class="sys-muted">Immutable trail of system administrator actions across pharmacies and accounts.</p>

<div class="sys-table-wrap">
	<table class="sys-table compact">
		<thead><tr><th>ID</th><th>Time</th><th>Actor</th><th>Action</th><th>Entity</th><th>Summary</th><th>IP</th></tr></thead>
		<tbody>
		<?php foreach ($logs as $a): ?>
			<tr>
				<td><?php echo (int) $a['audit_id']; ?></td>
				<td><?php echo htmlspecialchars((string) $a['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo htmlspecialchars((string) $a['actor_name'], ENT_QUOTES, 'UTF-8'); ?></td>
				<td><code><?php echo htmlspecialchars((string) $a['action'], ENT_QUOTES, 'UTF-8'); ?></code></td>
				<td><?php echo htmlspecialchars((string) $a['entity_type'], ENT_QUOTES, 'UTF-8'); ?> #<?php echo (int) ($a['entity_id'] ?? 0); ?></td>
				<td><?php echo htmlspecialchars((string) ($a['summary'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo htmlspecialchars((string) ($a['ip_address'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php
mc_system_shell_end();
