<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_pharmacies.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$row = $id > 0 ? mc_system_pharmacy_get($conn, $id) : null;
if ($id > 0 && $row === null) {
	header('Location: pharmacies.php');
	exit;
}

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action']) && $_POST['mc_action'] === 'save_pharmacy') {
	$result = mc_system_pharmacy_save($conn, $_POST, $id);
	if ($result['ok']) {
		$newId = (int) ($result['id'] ?? $id);
		mc_system_audit_log(
			$conn,
			$id > 0 ? 'pharmacy_update' : 'pharmacy_create',
			'pharmacy',
			$newId,
			($id > 0 ? 'Updated' : 'Registered') . ' pharmacy: ' . trim((string) ($_POST['name'] ?? ''))
		);
		header('Location: pharmacy.php?id=' . $newId . '&saved=1');
		exit;
	}
	$flashKind = 'error';
	$flash = $result['error'];
}

if (isset($_GET['saved'])) {
	$flash = 'Pharmacy saved successfully.';
}

$v = static function (string $key, $default = '') use ($row): string {
	if ($row === null) {
		return (string) $default;
	}

	return (string) ($row[$key] ?? $default);
};

mc_system_shell_start($id > 0 ? 'Edit pharmacy' : 'Register pharmacy', 'pharmacy');
if ($flash) {
	mc_system_flash($flash, $flashKind);
}
?>
<p class="sys-muted"><a href="pharmacies.php">← All pharmacies</a></p>

<form method="post" class="sys-form sys-form-grid">
	<input type="hidden" name="mc_action" value="save_pharmacy">

	<fieldset class="sys-fieldset">
		<legend>Identity</legend>
		<label>Pharmacy name *
			<input type="text" name="name" required value="<?php echo htmlspecialchars($v('name'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>URL slug <span class="sys-hint">auto if empty</span>
			<input type="text" name="slug" value="<?php echo htmlspecialchars($v('slug'), ENT_QUOTES, 'UTF-8'); ?>" pattern="[a-z0-9-]+">
		</label>
		<label>Tagline
			<input type="text" name="tagline" value="<?php echo htmlspecialchars($v('tagline'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>Owner / responsible pharmacist
			<input type="text" name="owner_name" value="<?php echo htmlspecialchars($v('owner_name'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
	</fieldset>

	<fieldset class="sys-fieldset">
		<legend>Contact & location</legend>
		<label>Street address
			<input type="text" name="address" value="<?php echo htmlspecialchars($v('address'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>City
			<input type="text" name="city" value="<?php echo htmlspecialchars($v('city'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>Phone
			<input type="text" name="phone" value="<?php echo htmlspecialchars($v('phone'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>Tele Birr phone
			<input type="text" name="telebirr_phone" value="<?php echo htmlspecialchars($v('telebirr_phone'), ENT_QUOTES, 'UTF-8'); ?>" placeholder="09xxxxxxxx — shown to members for payment">
		</label>
		<label>Email
			<input type="email" name="email" value="<?php echo htmlspecialchars($v('email'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>Website
			<input type="url" name="website" value="<?php echo htmlspecialchars($v('website'), ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://">
		</label>
		<div class="sys-row-2">
			<label>Latitude
				<input type="text" name="latitude" value="<?php echo htmlspecialchars($v('latitude'), ENT_QUOTES, 'UTF-8'); ?>">
			</label>
			<label>Longitude
				<input type="text" name="longitude" value="<?php echo htmlspecialchars($v('longitude'), ENT_QUOTES, 'UTF-8'); ?>">
			</label>
		</div>
	</fieldset>

	<fieldset class="sys-fieldset sys-fieldset-accent">
		<legend>Licensing & compliance</legend>
		<label>License number *
			<input type="text" name="license_number" required value="<?php echo htmlspecialchars($v('license_number'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>Issuing authority
			<input type="text" name="license_authority" value="<?php echo htmlspecialchars($v('license_authority'), ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. EFDA / regional board">
		</label>
		<label>License expiry
			<input type="date" name="license_expiry" value="<?php echo htmlspecialchars($v('license_expiry'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>Registration number
			<input type="text" name="registration_number" value="<?php echo htmlspecialchars($v('registration_number'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>Tax ID
			<input type="text" name="tax_id" value="<?php echo htmlspecialchars($v('tax_id'), ENT_QUOTES, 'UTF-8'); ?>">
		</label>
		<label>License document URL
			<input type="url" name="license_document_url" value="<?php echo htmlspecialchars($v('license_document_url'), ENT_QUOTES, 'UTF-8'); ?>" placeholder="Link to scanned license PDF">
		</label>
		<label>License notes
			<textarea name="license_notes" rows="3"><?php echo htmlspecialchars($v('license_notes'), ENT_QUOTES, 'UTF-8'); ?></textarea>
		</label>
	</fieldset>

	<fieldset class="sys-fieldset">
		<legend>Network status</legend>
		<label class="sys-check"><input type="checkbox" name="is_active" value="1" <?php echo $row === null || (int) ($row['is_active'] ?? 1) ? 'checked' : ''; ?>> Active on MediCentral network</label>
		<label class="sys-check"><input type="checkbox" name="is_verified" value="1" <?php echo (int) ($row['is_verified'] ?? 0) ? 'checked' : ''; ?>> Verified partner (shown as trusted on member map)</label>
	</fieldset>

	<div class="sys-form-actions">
		<button type="submit" class="sys-btn sys-btn-primary"><?php echo $id > 0 ? 'Save changes' : 'Register pharmacy'; ?></button>
		<a class="sys-btn" href="pharmacies.php">Cancel</a>
	</div>
</form>
<?php
mc_system_shell_end();
