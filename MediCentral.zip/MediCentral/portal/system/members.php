<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action'])) {
	$action = (string) $_POST['mc_action'];
	$mid = (int) ($_POST['member_id'] ?? 0);

	if ($mid > 0 && $action === 'toggle_active') {
		$active = isset($_POST['is_active']) ? 1 : 0;
		$stmt = $conn->prepare('UPDATE mc_members SET is_active = ? WHERE member_id = ? LIMIT 1');
		if ($stmt) {
			$stmt->bind_param('ii', $active, $mid);
			if ($stmt->execute()) {
				$flash = $active ? 'Member reactivated.' : 'Member suspended.';
				mc_system_audit_log($conn, 'member_status', 'member', $mid, $active ? 'Reactivated member' : 'Suspended member');
			}
			$stmt->close();
		}
	} elseif ($mid > 0 && $action === 'reset_password') {
		$pw = (string) ($_POST['new_password'] ?? '');
		if (strlen($pw) < 8) {
			$flashKind = 'error';
			$flash = 'Password must be at least 8 characters.';
		} else {
			$h = password_hash($pw, PASSWORD_DEFAULT);
			$stmt = $conn->prepare('UPDATE mc_members SET password_hash = ? WHERE member_id = ? LIMIT 1');
			if ($stmt) {
				$stmt->bind_param('si', $h, $mid);
				if ($stmt->execute()) {
					$flash = 'Member password reset.';
					mc_system_audit_log($conn, 'member_password_reset', 'member', $mid, 'Password reset by system admin');
				}
				$stmt->close();
			}
		}
	}
}

$q = trim((string) ($_GET['q'] ?? ''));
$sql = 'SELECT member_id, username, first_name, last_name, email, phone, is_active, created_at, last_login_at FROM mc_members';
$params = [];
$types = '';
if ($q !== '') {
	$sql .= ' WHERE username LIKE ? OR email LIKE ? OR first_name LIKE ? OR last_name LIKE ?';
	$like = '%' . $q . '%';
	$params = [$like, $like, $like, $like];
	$types = 'ssss';
}
$sql .= ' ORDER BY member_id DESC LIMIT 200';
$stmt = $conn->prepare($sql);
$rows = [];
if ($stmt) {
	if ($params !== []) {
		$stmt->bind_param($types, ...$params);
	}
	$stmt->execute();
	$res = $stmt->get_result();
	while ($r = $res->fetch_assoc()) {
		$rows[] = $r;
	}
	$stmt->close();
}

mc_system_shell_start('Members', 'members');
if ($flash) {
	mc_system_flash($flash, $flashKind);
}
?>
<form method="get" class="sys-toolbar">
	<input type="search" name="q" value="<?php echo htmlspecialchars($q, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search username, name, email…" class="sys-search">
	<button type="submit" class="sys-btn">Search</button>
</form>

<div class="sys-table-wrap">
	<table class="sys-table">
		<thead><tr><th>Member</th><th>Contact</th><th>Joined</th><th>Last login</th><th>Status</th><th>Actions</th></tr></thead>
		<tbody>
		<?php foreach ($rows as $m): ?>
			<tr>
				<td><strong><?php echo htmlspecialchars((string) $m['first_name'] . ' ' . (string) ($m['last_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></strong><br><code>@<?php echo htmlspecialchars((string) $m['username'], ENT_QUOTES, 'UTF-8'); ?></code></td>
				<td><?php echo htmlspecialchars((string) ($m['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?><br><?php echo htmlspecialchars((string) ($m['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo htmlspecialchars((string) $m['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo htmlspecialchars((string) ($m['last_login_at'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo (int) $m['is_active'] ? '<span class="sys-tag ok">Active</span>' : '<span class="sys-tag danger">Suspended</span>'; ?></td>
				<td class="sys-actions-cell">
					<form method="post" class="sys-inline-form">
						<input type="hidden" name="mc_action" value="toggle_active">
						<input type="hidden" name="member_id" value="<?php echo (int) $m['member_id']; ?>">
						<?php if ((int) $m['is_active']): ?>
							<input type="hidden" name="is_active" value="0">
							<button type="submit" class="sys-btn sys-btn-sm danger">Suspend</button>
						<?php else: ?>
							<input type="hidden" name="is_active" value="1">
							<button type="submit" class="sys-btn sys-btn-sm">Activate</button>
						<?php endif; ?>
					</form>
					<details class="sys-details">
						<summary>Reset password</summary>
						<form method="post" class="sys-inline-form">
							<input type="hidden" name="mc_action" value="reset_password">
							<input type="hidden" name="member_id" value="<?php echo (int) $m['member_id']; ?>">
							<input type="password" name="new_password" minlength="8" required placeholder="New password">
							<button type="submit" class="sys-btn sys-btn-sm">Set</button>
						</form>
					</details>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php
mc_system_shell_end();
