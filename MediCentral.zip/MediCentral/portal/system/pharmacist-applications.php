<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';

$flash = null;
$flashKind = 'success';
$sysId = (int) ($_SESSION['mc_system_admin_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pharmacist_id'], $_POST['decision'])) {
	$phId = (int) $_POST['pharmacist_id'];
	$dec = (string) $_POST['decision'];
	if ($dec === 'approve') {
		$stmt = $conn->prepare(
			"UPDATE mc_pharmacists SET approval_status = 'approved', is_active = 1, approved_at = CURRENT_TIMESTAMP, approved_by_system_admin_id = ? WHERE pharmacist_id = ? LIMIT 1"
		);
		if ($stmt) {
			$stmt->bind_param('ii', $sysId, $phId);
			$stmt->execute();
			$stmt->close();
			$flash = 'Pharmacist approved.';
			mc_system_audit_log($conn, 'pharmacist_approve', 'pharmacist', $phId, 'Approved pharmacist application');
		}
	} elseif ($dec === 'reject') {
		$stmt = $conn->prepare(
			"UPDATE mc_pharmacists SET approval_status = 'rejected', is_active = 0 WHERE pharmacist_id = ? LIMIT 1"
		);
		if ($stmt) {
			$stmt->bind_param('i', $phId);
			$stmt->execute();
			$stmt->close();
			$flash = 'Application rejected.';
			mc_system_audit_log($conn, 'pharmacist_reject', 'pharmacist', $phId, 'Rejected pharmacist application');
		}
	}
}

$pending = [];
$res = $conn->query(
	"SELECT pharmacist_id, username, first_name, last_name, email, phone, cv_summary, cv_document_url,
	license_number, license_authority, license_expiry, license_document_url, bio, created_at
	FROM mc_pharmacists WHERE approval_status = 'pending' ORDER BY pharmacist_id DESC"
);
if ($res) {
	while ($r = $res->fetch_assoc()) {
		$pending[] = $r;
	}
}

mc_system_shell_start('Pharmacist applications', 'phapps');
if ($flash) {
	mc_system_flash($flash, $flashKind);
}
?>
<p class="sys-muted">Review optional CV and license submissions. Pharmacists who register without credentials already have Dr. Aklilu access; approve those who submitted documents for verified network status.</p>
<?php foreach ($pending as $ph): ?>
	<section class="sys-panel" style="margin-bottom:1.25rem;">
		<h2><?php echo htmlspecialchars(trim($ph['first_name'] . ' ' . ($ph['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?> <code>@<?php echo htmlspecialchars((string) $ph['username'], ENT_QUOTES, 'UTF-8'); ?></code></h2>
		<?php if (trim((string) ($ph['license_number'] ?? '')) !== ''): ?>
		<p><strong>License:</strong> <?php echo htmlspecialchars((string) $ph['license_number'], ENT_QUOTES, 'UTF-8'); ?>
			<?php if ($ph['license_authority']): ?> · <?php echo htmlspecialchars((string) $ph['license_authority'], ENT_QUOTES, 'UTF-8'); ?><?php endif; ?>
			<?php if ($ph['license_expiry']): ?> · exp <?php echo htmlspecialchars((string) $ph['license_expiry'], ENT_QUOTES, 'UTF-8'); ?><?php endif; ?>
		</p>
		<?php if ($ph['license_document_url']): ?><p><a class="sys-link" href="<?php echo htmlspecialchars((string) $ph['license_document_url'], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener">License document</a></p><?php endif; ?>
		<?php else: ?><p class="sys-muted">No license number submitted.</p><?php endif; ?>
		<h3>CV</h3>
		<?php if (trim((string) ($ph['cv_summary'] ?? '')) !== ''): ?>
		<pre class="sys-cv"><?php echo htmlspecialchars((string) $ph['cv_summary'], ENT_QUOTES, 'UTF-8'); ?></pre>
		<?php else: ?><p class="sys-muted">No CV summary submitted.</p><?php endif; ?>
		<?php if ($ph['cv_document_url']): ?><p><a class="sys-link" href="<?php echo htmlspecialchars((string) $ph['cv_document_url'], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener">CV file</a></p><?php endif; ?>
		<form method="post" class="sys-form-actions">
			<input type="hidden" name="pharmacist_id" value="<?php echo (int) $ph['pharmacist_id']; ?>">
			<button type="submit" name="decision" value="approve" class="sys-btn sys-btn-primary">Approve</button>
			<button type="submit" name="decision" value="reject" class="sys-btn danger">Reject</button>
		</form>
	</section>
<?php endforeach; ?>
<?php if ($pending === []): ?><p class="sys-muted">No pending applications.</p><?php endif; ?>
<?php
mc_system_shell_end();
