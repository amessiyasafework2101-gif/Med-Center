<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_admins.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$pharmacies = [];
$phRes = $conn->query('SELECT pharmacy_id, name FROM mc_pharmacies WHERE is_active = 1 ORDER BY name');
if ($phRes) {
	while ($r = $phRes->fetch_assoc()) {
		$pharmacies[] = $r;
	}
}

$eligibleMembers = mc_system_members_eligible_for_admin($conn);
$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mc_action']) && $_POST['mc_action'] === 'promote_member') {
	$memberId = (int) ($_POST['member_id'] ?? 0);
	$pharmacyId = (int) ($_POST['pharmacy_id'] ?? 0);
	$pw = (string) ($_POST['password'] ?? '');
	$result = mc_system_promote_member_to_pharmacy_admin($conn, $memberId, $pharmacyId, $pw);
	if ($result['ok']) {
		$flash = 'Pharmacy administrator created from member account.';
		mc_system_audit_log(
			$conn,
			'admin_promote_member',
			'admin',
			(int) ($result['admin_id'] ?? 0),
			'Promoted member #' . $memberId . ' to pharmacy admin'
		);
		$eligibleMembers = mc_system_members_eligible_for_admin($conn);
	} else {
		$flashKind = 'error';
		$flash = $result['error'];
	}
}

$rows = mc_system_list_pharmacy_admins($conn);

mc_system_shell_start('Pharmacy administrators', 'admins');
if ($flash) {
	mc_system_flash($flash, $flashKind);
}
?>
<p class="sys-muted">Promote an active <strong>network member</strong> to run a pharmacy on the portal. They manage inventory, staff, and orders for that location. Adding pharmacists is done by the pharmacy administrator, not here.</p>

<section class="sys-panel">
	<h2>Add pharmacy administrator from member</h2>
	<?php if ($eligibleMembers === []): ?>
		<p class="sys-muted">No eligible members — all active members may already be administrators, or none are registered yet.</p>
	<?php elseif ($pharmacies === []): ?>
		<p class="sys-muted">Register a pharmacy first before assigning an administrator.</p>
		<p><a class="sys-link" href="pharmacy.php">Register pharmacy →</a></p>
	<?php else: ?>
		<form method="post" class="sys-form sys-promote-form">
			<input type="hidden" name="mc_action" value="promote_member">
			<label>Network member *
				<select name="member_id" required>
					<option value="">— Select member —</option>
					<?php foreach ($eligibleMembers as $m): ?>
						<?php
						$label = trim((string) $m['first_name'] . ' ' . (string) ($m['last_name'] ?? ''));
						$label .= ' (@' . (string) $m['username'] . ')';
						if (!empty($m['email'])) {
							$label .= ' · ' . (string) $m['email'];
						}
						?>
						<option value="<?php echo (int) $m['member_id']; ?>"><?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>Assign to pharmacy *
				<select name="pharmacy_id" required>
					<option value="">— Select pharmacy —</option>
					<?php foreach ($pharmacies as $ph): ?>
						<option value="<?php echo (int) $ph['pharmacy_id']; ?>"><?php echo htmlspecialchars((string) $ph['name'], ENT_QUOTES, 'UTF-8'); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>Temporary sign-in password *
				<input type="password" name="password" minlength="10" required autocomplete="new-password" placeholder="Min 10 characters — they should change it after first login">
			</label>
			<div class="sys-form-actions">
				<button type="submit" class="sys-btn sys-btn-primary">Create pharmacy administrator</button>
			</div>
		</form>
	<?php endif; ?>
</section>

<div class="sys-table-wrap">
	<table class="sys-table">
		<thead><tr><th>Administrator</th><th>Pharmacy</th><th>From member</th><th>Created</th><th>Last login</th></tr></thead>
		<tbody>
		<?php if ($rows === []): ?>
			<tr><td colspan="5" class="sys-empty">No pharmacy administrators yet.</td></tr>
		<?php endif; ?>
		<?php foreach ($rows as $a): ?>
			<tr>
				<td>
					<strong><?php echo htmlspecialchars(trim((string) ($a['first_name'] ?? '') . ' ' . (string) ($a['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></strong><br>
					<code>@<?php echo htmlspecialchars((string) $a['username'], ENT_QUOTES, 'UTF-8'); ?></code>
				</td>
				<td><?php echo htmlspecialchars((string) ($a['pharmacy_name'] ?? '— Unassigned —'), ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo !empty($a['member_id']) ? '<span class="sys-tag ok">#' . (int) $a['member_id'] . '</span>' : '<span class="sys-muted">—</span>'; ?></td>
				<td><?php echo htmlspecialchars((string) $a['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo htmlspecialchars((string) ($a['last_login_at'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php
mc_system_shell_end();
