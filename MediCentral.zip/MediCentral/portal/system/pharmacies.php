<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_pharmacies.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$filter = isset($_GET['filter']) ? (string) $_GET['filter'] : 'all';
$allowed = ['all', 'active', 'inactive', 'unverified', 'license_expiring'];
if (!in_array($filter, $allowed, true)) {
	$filter = 'all';
}

$list = mc_system_pharmacy_list($conn, $filter === 'all' ? null : $filter);

mc_system_shell_start('Pharmacies', 'pharmacies');
?>
<div class="sys-toolbar">
	<div class="sys-filter-tabs">
		<?php foreach (['all' => 'All', 'active' => 'Active', 'inactive' => 'Inactive', 'unverified' => 'Unverified', 'license_expiring' => 'License alert'] as $k => $lbl): ?>
			<a class="sys-tab<?php echo $filter === $k ? ' is-on' : ''; ?>" href="pharmacies.php?filter=<?php echo urlencode($k); ?>"><?php echo htmlspecialchars($lbl, ENT_QUOTES, 'UTF-8'); ?></a>
		<?php endforeach; ?>
	</div>
	<a class="sys-btn sys-btn-primary" href="pharmacy.php">+ Add pharmacy</a>
</div>

<div class="sys-table-wrap">
	<table class="sys-table">
		<thead>
			<tr>
				<th>Pharmacy</th>
				<th>Location</th>
				<th>License</th>
				<th>Staff</th>
				<th>Orders</th>
				<th>Status</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
		<?php if ($list === []): ?>
			<tr><td colspan="7" class="sys-empty">No pharmacies match this filter.</td></tr>
		<?php endif; ?>
		<?php foreach ($list as $p): ?>
			<tr>
				<td>
					<strong><?php echo htmlspecialchars((string) $p['name'], ENT_QUOTES, 'UTF-8'); ?></strong>
					<?php if (!empty($p['is_verified'])): ?><span class="sys-tag ok">Verified</span><?php else: ?><span class="sys-tag">Unverified</span><?php endif; ?>
					<br><span class="sys-muted"><?php echo htmlspecialchars((string) ($p['tagline'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></span>
				</td>
				<td><?php echo htmlspecialchars(trim((string) ($p['city'] ?? '') . ' · ' . (string) ($p['address'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></td>
				<td>
					<?php echo htmlspecialchars((string) ($p['license_number'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?>
					<?php if (!empty($p['license_expiry'])): ?><br><small>exp <?php echo htmlspecialchars((string) $p['license_expiry'], ENT_QUOTES, 'UTF-8'); ?></small><?php endif; ?>
				</td>
				<td><?php echo (int) ($p['staff_cnt'] ?? 0); ?></td>
				<td><?php echo (int) ($p['order_cnt'] ?? 0); ?></td>
				<td><?php echo (int) ($p['is_active'] ?? 0) ? '<span class="sys-tag ok">Active</span>' : '<span class="sys-tag danger">Suspended</span>'; ?></td>
				<td><a href="pharmacy.php?id=<?php echo (int) $p['pharmacy_id']; ?>">Manage</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php
mc_system_shell_end();
