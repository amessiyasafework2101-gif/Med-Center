<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_system.php';
require_once dirname(__DIR__) . '/includes/system_shell.php';
require_once dirname(__DIR__) . '/includes/system_audit.php';

$flash = null;
$flashKind = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['new_status'])) {
	$oid = (int) $_POST['order_id'];
	$st = trim((string) $_POST['new_status']);
	$allowed = ['pending', 'confirmed', 'ready', 'cancelled'];
	if (!in_array($st, $allowed, true)) {
		$flashKind = 'error';
		$flash = 'Invalid status.';
	} else {
		$upd = $conn->prepare('UPDATE mc_member_orders SET status = ? WHERE order_id = ? LIMIT 1');
		if ($upd) {
			$upd->bind_param('si', $st, $oid);
			if ($upd->execute() && $upd->affected_rows === 1) {
				$flash = 'Order #' . $oid . ' → ' . $st;
				mc_system_audit_log($conn, 'order_status', 'member_order', $oid, 'Status set to ' . $st);
			} else {
				$flashKind = 'error';
				$flash = 'Could not update order.';
			}
			$upd->close();
		}
	}
}

$orders = [];
if (mc_table_has_column($conn, 'mc_member_orders', 'order_id')) {
	$res = $conn->query(
		<<<'SQL'
SELECT o.order_id, o.status, o.total_amount, o.created_at,
  m.first_name, m.last_name, m.username, ph.name AS pharmacy_name
FROM mc_member_orders o
INNER JOIN mc_members m ON m.member_id = o.member_id
INNER JOIN mc_pharmacies ph ON ph.pharmacy_id = o.pharmacy_id
ORDER BY o.created_at DESC
LIMIT 150
SQL
	);
	if ($res) {
		while ($row = $res->fetch_assoc()) {
			$orders[] = $row;
		}
	}
}

mc_system_shell_start('Member orders', 'orders');
if ($flash) {
	mc_system_flash($flash, $flashKind);
}
?>
<p class="sys-muted">Network-wide member orders — override status across all pharmacies.</p>

<div class="sys-table-wrap">
	<table class="sys-table">
		<thead><tr><th>ID</th><th>Member</th><th>Pharmacy</th><th>Total</th><th>When</th><th>Status</th><th>Update</th></tr></thead>
		<tbody>
		<?php if ($orders === []): ?>
			<tr><td colspan="7" class="sys-empty">No member orders yet.</td></tr>
		<?php endif; ?>
		<?php foreach ($orders as $o): ?>
			<tr>
				<td>#<?php echo (int) $o['order_id']; ?></td>
				<td><?php echo htmlspecialchars(trim((string) $o['first_name'] . ' ' . ($o['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?><br><code>@<?php echo htmlspecialchars((string) $o['username'], ENT_QUOTES, 'UTF-8'); ?></code></td>
				<td><?php echo htmlspecialchars((string) $o['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?></td>
				<td><?php echo number_format((float) $o['total_amount'], 2); ?></td>
				<td><?php echo htmlspecialchars((string) $o['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
				<td><span class="sys-tag"><?php echo htmlspecialchars((string) $o['status'], ENT_QUOTES, 'UTF-8'); ?></span></td>
				<td>
					<form method="post" class="sys-inline-form">
						<input type="hidden" name="order_id" value="<?php echo (int) $o['order_id']; ?>">
						<select name="new_status">
							<?php foreach (['pending', 'confirmed', 'ready', 'cancelled'] as $s): ?>
								<option value="<?php echo $s; ?>"<?php echo $o['status'] === $s ? ' selected' : ''; ?>><?php echo $s; ?></option>
							<?php endforeach; ?>
						</select>
						<button type="submit" class="sys-btn sys-btn-sm">Save</button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php
mc_system_shell_end();
