<?php



declare(strict_types=1);



require_once __DIR__ . '/config.php';

require_once __DIR__ . '/includes/session.php';

require_once __DIR__ . '/includes/username_format.php';

require_once __DIR__ . '/includes/auth_helpers.php';

require_once __DIR__ . '/includes/pharmacist_pro.php';

require_once __DIR__ . '/includes/site_footer.php';



mc_session_start();

mc_auth_redirect_if_logged_in($conn, 'network');



$error = '';

$ok = false;

$autoApproved = false;



if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {

	$data = [

		'username' => $_POST['uname'] ?? '',

		'password' => $_POST['pwd'] ?? '',

		'first_name' => $_POST['first_name'] ?? '',

		'last_name' => $_POST['last_name'] ?? '',

		'email' => $_POST['email'] ?? '',

		'phone' => $_POST['phone'] ?? '',

		'bio' => $_POST['bio'] ?? '',

		'cv_summary' => $_POST['cv_summary'] ?? '',

		'cv_document_url' => $_POST['cv_document_url'] ?? '',

		'license_number' => $_POST['license_number'] ?? '',

		'license_authority' => $_POST['license_authority'] ?? '',

		'license_expiry' => $_POST['license_expiry'] ?? '',

		'license_document_url' => $_POST['license_document_url'] ?? '',

	];

	$result = mc_pharmacist_register($conn, $data);

	if ($result['ok']) {

		$ok = true;

		$autoApproved = !empty($result['auto_approved']);

	} else {

		$error = $result['error'];

	}

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Pharmacist registration · MediCentral</title>

	<link rel="stylesheet" href="css/signin.css">

	<link rel="stylesheet" href="css/pharmacist-network.css">

</head>

<body class="phn-signup-body">

	<div class="mc-wrap" style="max-width:720px;margin:2rem auto;">

		<div class="mc-signin-card">

			<h2 class="mc-title">Pharmacist registration</h2>

			<p class="mc-sub">Create your account to join the network. <strong>CV and license are optional</strong> — sign in right away and chat with <strong>Dr. Aklilu</strong> for clinical guidance. Add credentials later if you want a verified professional profile reviewed by the system administrator.</p>

			<?php if ($ok): ?>

				<div class="mc-alert mc-show success" role="status">

					<?php if ($autoApproved): ?>

						Account ready. <a href="index.php">Sign in</a> as Pharmacist and open <strong>Dr. Aklilu</strong> for assistance.

					<?php else: ?>

						Application submitted with your credentials. An administrator will review your CV/license. <a href="index.php">Sign in</a> to check status or use Dr. Aklilu while you wait.

					<?php endif; ?>

				</div>

			<?php else: ?>

				<?php if ($error !== ''): ?><div class="mc-alert mc-show" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>

				<form method="post" class="phn-form">

					<input type="hidden" name="register" value="1">

					<h3>Account</h3>

					<div class="mc-field"><input type="text" name="uname" required placeholder=" "><label class="mc-float-label">Username</label></div>

					<div class="mc-field"><input type="password" name="pwd" required minlength="10" placeholder=" "><label class="mc-float-label">Password</label></div>

					<div class="mc-field"><input type="text" name="first_name" required placeholder=" "><label class="mc-float-label">First name</label></div>

					<div class="mc-field"><input type="text" name="last_name" placeholder=" "><label class="mc-float-label">Last name</label></div>

					<div class="mc-field"><input type="email" name="email" placeholder=" "><label class="mc-float-label">Email</label></div>

					<div class="mc-field"><input type="text" name="phone" placeholder=" "><label class="mc-float-label">Phone</label></div>

					<h3>Optional — CV &amp; license (verified profile)</h3>

					<p class="mc-sub" style="margin:0 0 0.75rem;font-size:0.85rem;">Skip this section to use Dr. Aklilu immediately after sign-in. Fill it in when you want full network verification.</p>

					<div class="mc-field"><textarea name="cv_summary" rows="5" placeholder="Education, experience, specialties… (optional)"></textarea></div>

					<div class="mc-field"><input type="url" name="cv_document_url" placeholder="https:// link to CV (optional)"><label class="mc-float-label">CV document URL</label></div>

					<div class="mc-field"><input type="text" name="license_number" placeholder=" "><label class="mc-float-label">License number (optional)</label></div>

					<div class="mc-field"><input type="text" name="license_authority" placeholder=" "><label class="mc-float-label">Issuing authority (optional)</label></div>

					<div class="mc-field"><input type="date" name="license_expiry"><label class="mc-float-label">License expiry (optional)</label></div>

					<div class="mc-field"><input type="url" name="license_document_url" placeholder="https://"><label class="mc-float-label">License document URL (optional)</label></div>

					<div class="mc-field"><textarea name="bio" rows="3" placeholder="Short professional bio (optional)"></textarea></div>

					<button type="submit" class="mc-btn">Create account</button>

				</form>

			<?php endif; ?>

			<p class="mc-mini-link"><a href="index.php">← Back to sign in</a></p>

		</div>

	</div>

</body>

</html>

