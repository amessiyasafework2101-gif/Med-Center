<?php

declare(strict_types=1);

@set_time_limit(120);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/telebirr_verify.php';

mc_session_start();
header('Content-Type: application/json; charset=utf-8');

if (($_SESSION['mc_role'] ?? '') !== 'member') {
	http_response_code(403);
	echo json_encode(['ok' => false, 'error' => 'Sign in as a member to verify a transaction ID.']);
	exit;
}

$memberId = (int) ($_SESSION['mc_member_id'] ?? 0);
$orderId = (int) ($_POST['order_id'] ?? 0);
$tx = trim((string) ($_POST['telebirr_transaction_id'] ?? ''));

if ($orderId <= 0 || $tx === '') {
	echo json_encode(['ok' => false, 'error' => 'Enter an order and transaction ID.']);
	exit;
}

$result = mc_telebirr_verify_transaction($conn, $memberId, $orderId, $tx);
echo json_encode([
	'ok' => $result['ok'],
	'verdict' => $result['verdict'],
	'msg' => $result['msg'],
	'ai_note' => $result['ai_note'],
	'confidence' => $result['confidence'],
	'ai_used' => $result['ai_used'],
	'label' => mc_telebirr_verify_status_label($result['verdict']),
], JSON_THROW_ON_ERROR);
