<?php

declare(strict_types=1);

@set_time_limit(180);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/dr_aklilu.php';

mc_session_start();
header('Content-Type: application/json; charset=utf-8');

$role = (string) ($_SESSION['mc_role'] ?? '');
$portal = isset($_POST['portal']) ? (string) $_POST['portal'] : '';
if (!in_array($portal, ['network', 'pharmacy'], true)) {
	$portal = 'network';
}

$action = isset($_POST['action']) ? (string) $_POST['action'] : 'chat';

if ($action === 'reset') {
	unset($_SESSION[mc_dr_aklilu_session_key($portal)]);
	echo json_encode(['ok' => true, 'message' => 'Conversation reset.']);
	exit;
}

if ($portal === 'pharmacy') {
	if ($role !== 'pharmacist' && $role !== 'admin') {
		http_response_code(403);
		echo json_encode(['ok' => false, 'error' => 'Sign in to pharmacy operations to use Dr. Aklilu.']);
		exit;
	}
} elseif ($role !== 'member' && $role !== 'pharmacist') {
	http_response_code(403);
	echo json_encode(['ok' => false, 'error' => 'Sign in to the network to use Dr. Aklilu.']);
	exit;
}

$message = trim((string) ($_POST['message'] ?? ''));
$cvExtra = trim((string) ($_POST['cv_text'] ?? ''));

if (isset($_FILES['cv_file']) && is_array($_FILES['cv_file']) && ($_FILES['cv_file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
	$tmp = (string) ($_FILES['cv_file']['tmp_name'] ?? '');
	$size = (int) ($_FILES['cv_file']['size'] ?? 0);
	if ($tmp !== '' && $size > 0 && $size <= 512000 && is_readable($tmp)) {
		$mime = (string) ($_FILES['cv_file']['type'] ?? '');
		$name = (string) ($_FILES['cv_file']['name'] ?? '');
		$allowed = ['text/plain', 'text/markdown', 'application/pdf'];
		if (in_array($mime, $allowed, true) || preg_match('/\.(txt|md)$/i', $name)) {
			$fileText = (string) file_get_contents($tmp);
			if ($fileText !== '') {
				$cvExtra = $cvExtra !== '' ? $cvExtra . "\n\n" . $fileText : $fileText;
			}
		}
	}
}

$sessionKey = mc_dr_aklilu_session_key($portal);
$agentId = isset($_SESSION[$sessionKey]) ? (string) $_SESSION[$sessionKey] : null;
if ($agentId === '') {
	$agentId = null;
}

if ($portal === 'pharmacy') {
	$pid = (int) ($_SESSION['mc_pharmacist_id'] ?? 0);
	if ($role === 'admin') {
		$systemContext = "You are Dr. Aklilu, MediCentral's pharmacy operations advisor for administrators.\n";
		$systemContext .= "Help with recruitment, staff performance, inventory strategy, and pharmacist CV review.\n\n";
		$adminId = (int) ($_SESSION['mc_admin_id'] ?? 0);
		$systemContext .= 'Administrator session id: ' . $adminId . "\n";
		if ($cvExtra !== '') {
			$systemContext .= "\nUploaded CV / document:\n" . mb_substr($cvExtra, 0, 12000) . "\n";
		}
	} else {
		$systemContext = mc_dr_aklilu_build_pharmacy_context($conn, $pid, $cvExtra);
	}
} else {
	if ($role === 'member') {
		$systemContext = mc_dr_aklilu_build_member_context($conn, (int) ($_SESSION['mc_member_id'] ?? 0));
	} else {
		$systemContext = mc_dr_aklilu_build_pharmacy_context($conn, (int) ($_SESSION['mc_pharmacist_id'] ?? 0), $cvExtra);
		$systemContext .= "\nNote: pharmacist is using the member network portal.\n";
	}
}

try {
	$result = mc_dr_aklilu_chat($portal, $message, $systemContext, $agentId);
	if ($result['ok'] && $result['agent_id'] !== '') {
		$_SESSION[$sessionKey] = $result['agent_id'];
	}
	echo json_encode([
		'ok' => $result['ok'],
		'error' => $result['error'],
		'reply' => $result['text'],
		'configured' => mc_cursor_api_configured(),
	]);
} catch (Throwable $e) {
	http_response_code(500);
	echo json_encode([
		'ok' => false,
		'error' => 'Dr. Aklilu error: ' . $e->getMessage(),
		'reply' => '',
		'configured' => mc_cursor_api_configured(),
	]);
}
