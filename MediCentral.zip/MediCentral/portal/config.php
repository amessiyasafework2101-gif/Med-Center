<?php
/** MediCentral application database (`medicentral`). */

$conn = mysqli_connect('localhost', 'root', '', 'medicentral');
if (!$conn || $conn->connect_error) {
	die('Connection failed: ' . ($conn ? $conn->connect_error : mysqli_connect_error()));
}
$GLOBALS['conn'] = $conn;

require_once __DIR__ . '/includes/maps_config.php';
require_once __DIR__ . '/bootstrap_schema.php';
try {
	mc_bootstrap_medical_schema($conn);
} catch (Throwable $e) {
	error_log('MediCentral portal bootstrap: ' . $e->getMessage());
	$hint = getenv('MC_PORTAL_DEBUG') ? ' Detail: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') : '';
	die('Database setup failed. Check your MySQL medicentral schema and PHP error log.' . $hint);
}
