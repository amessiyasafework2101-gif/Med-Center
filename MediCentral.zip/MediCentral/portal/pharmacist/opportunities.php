<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_pharmacist_approved.php';
require_once dirname(__DIR__) . '/includes/pharmacist_network_shell.php';

$pid = (int) $_SESSION['mc_pharmacist_id'];
$p = mc_pharmacist_load($conn, $pid);
$display = trim((string) ($p['first_name'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['opportunity_id'], $_POST['decision'])) {
	$oid = (int) $_POST['opportunity_id'];
	$dec = (string) $_POST['decision'];
	$status = $dec === 'accept' ? 'accepted' : 'declined';
	$stmt = $conn->prepare(
		"UPDATE mc_pharmacy_opportunities SET status = ?, responded_at = CURRENT_TIMESTAMP
		WHERE opportunity_id = ? AND pharmacist_id = ? AND status = 'pending' LIMIT 1"
	);
	if ($stmt) {
		$stmt->bind_param('sii', $status, $oid, $pid);
		$stmt->execute();
		if ($stmt->affected_rows === 1 && $status === 'accepted') {
			$q = $conn->prepare('SELECT pharmacy_id FROM mc_pharmacy_opportunities WHERE opportunity_id = ? LIMIT 1');
			if ($q) {
				$q->bind_param('i', $oid);
				$q->execute();
				$q->bind_result($phId);
				if ($q->fetch() && $phId > 0) {
					$upd = $conn->prepare('UPDATE mc_pharmacists SET pharmacy_id = ? WHERE pharmacist_id = ? LIMIT 1');
					if ($upd) {
						$upd->bind_param('ii', $phId, $pid);
						$upd->execute();
						$upd->close();
					}
				}
				$q->close();
			}
		}
		$stmt->close();
	}
	header('Location: opportunities.php');
	exit;
}

$list = [];
$res = $conn->prepare(
	'SELECT o.opportunity_id, o.title, o.message, o.status, o.created_at, ph.name AS pharmacy_name
	FROM mc_pharmacy_opportunities o
	INNER JOIN mc_pharmacies ph ON ph.pharmacy_id = o.pharmacy_id
	WHERE o.pharmacist_id = ? ORDER BY o.created_at DESC'
);
if ($res) {
	$res->bind_param('i', $pid);
	$res->execute();
	$r = $res->get_result();
	while ($row = $r->fetch_assoc()) {
		$list[] = $row;
	}
	$res->close();
}

mc_ph_network_shell_start('Work offers', 'opportunities', $display);
?>
<p class="phn-muted">Pharmacy administrators send offers based on your profile and performance. Accepting links you to their pharmacy team.</p>
<?php foreach ($list as $o): ?>
	<article class="phn-card" style="margin-bottom:1rem;">
		<h3><?php echo htmlspecialchars((string) $o['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
		<p><strong><?php echo htmlspecialchars((string) $o['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?></strong> · <span class="phn-badge"><?php echo htmlspecialchars((string) $o['status'], ENT_QUOTES, 'UTF-8'); ?></span></p>
		<p><?php echo nl2br(htmlspecialchars((string) ($o['message'] ?? ''), ENT_QUOTES, 'UTF-8')); ?></p>
		<?php if ($o['status'] === 'pending'): ?>
		<form method="post" class="phn-inline">
			<input type="hidden" name="opportunity_id" value="<?php echo (int) $o['opportunity_id']; ?>">
			<button type="submit" name="decision" value="accept" class="phn-btn">Accept</button>
			<button type="submit" name="decision" value="decline" class="phn-btn secondary">Decline</button>
		</form>
		<?php endif; ?>
	</article>
<?php endforeach; ?>
<?php if ($list === []): ?><p class="phn-muted">No work offers yet.</p><?php endif; ?>
<?php
mc_ph_network_shell_end();
