<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_pharmacist_approved.php';
require_once dirname(__DIR__) . '/includes/pharmacist_network_shell.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';
require_once dirname(__DIR__) . '/includes/admin_chat.php';
require_once dirname(__DIR__) . '/includes/chat_ui.php';

$pid = (int) $_SESSION['mc_pharmacist_id'];
$p = mc_pharmacist_load($conn, $pid);
$display = trim((string) ($p['first_name'] ?? ''));
$flash = '';
$flashKind = 'success';

$channel = isset($_GET['channel']) ? (string) $_GET['channel'] : 'user';
if (!in_array($channel, ['user', 'admin', 'work'], true)) {
	$channel = 'user';
}
$threadMember = isset($_GET['member_id']) ? (int) $_GET['member_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['respond_chat'])) {
		$cid = (int) ($_POST['connection_id'] ?? 0);
		$approve = isset($_POST['approve']) && (string) $_POST['approve'] === '1';
		$res = mc_pharmacist_respond_chat_request($conn, $pid, $cid, $approve);
		$flash = $res['msg'];
		$flashKind = $res['ok'] ? 'success' : 'error';
		header('Location: chat.php?channel=admin');
		exit;
	}
	if (isset($_POST['body'])) {
		$ch = (string) ($_POST['channel'] ?? 'user');
		if (!in_array($ch, ['user', 'admin', 'work'], true)) {
			$ch = 'user';
		}
		$body = trim((string) $_POST['body']);
		$memberForReply = $ch === 'user' ? (int) ($_POST['member_id'] ?? 0) : 0;
		if ($body !== '') {
			mc_pharmacist_post_message(
				$conn,
				$pid,
				$ch,
				'pharmacist',
				$body,
				$memberForReply > 0 ? $memberForReply : null,
				null,
				$pid
			);
		}
		$redir = 'chat.php?channel=' . urlencode($ch);
		if ($ch === 'user' && $memberForReply > 0) {
			$redir .= '&member_id=' . $memberForReply;
		}
		header('Location: ' . $redir);
		exit;
	}
}

$messages = [];
$memberThreads = [];
if ($channel === 'user') {
	$memberThreads = mc_chat_list_member_threads($conn, $pid);
	if ($threadMember <= 0 && $memberThreads !== []) {
		$threadMember = (int) $memberThreads[0]['member_id'];
	}
	if ($threadMember > 0) {
		$messages = mc_chat_thread_member_pharmacist($conn, $pid, $threadMember);
	}
} else {
	$messages = mc_pharmacist_messages($conn, $pid, $channel);
}

$pendingAdminChats = $channel === 'admin' ? mc_pharmacist_pending_chat_requests($conn, $pid) : [];

mc_ph_network_shell_start('Messages', 'chat', $display);
echo '<link rel="stylesheet" href="../css/mc-chat.css">';
if ($flash) {
	echo '<div class="phn-flash ' . htmlspecialchars($flashKind, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') . '</div>';
}
?>
<div class="phn-channel-tabs">
	<a class="phn-tab<?php echo $channel === 'user' ? ' on' : ''; ?>" href="chat.php?channel=user">Member messages</a>
	<a class="phn-tab<?php echo $channel === 'admin' ? ' on' : ''; ?>" href="chat.php?channel=admin">Admin chat</a>
	<a class="phn-tab<?php echo $channel === 'work' ? ' on' : ''; ?>" href="chat.php?channel=work">Work discussion</a>
</div>

<?php if ($channel === 'admin' && $pendingAdminChats): ?>
<section class="phn-pending-requests">
	<h3>Chat requests from pharmacy admins</h3>
	<?php foreach ($pendingAdminChats as $req): ?>
		<article class="phn-req-card">
			<p><strong><?php echo htmlspecialchars(trim(($req['first_name'] ?? '') . ' ' . ($req['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></strong>
				<?php if (!empty($req['pharmacy_name'])): ?> · <?php echo htmlspecialchars((string) $req['pharmacy_name'], ENT_QUOTES, 'UTF-8'); ?><?php endif; ?>
			</p>
			<p class="phn-muted">Requested <?php echo htmlspecialchars((string) $req['requested_at'], ENT_QUOTES, 'UTF-8'); ?></p>
			<form method="post" class="phn-req-actions">
				<input type="hidden" name="respond_chat" value="1">
				<input type="hidden" name="connection_id" value="<?php echo (int) $req['connection_id']; ?>">
				<button type="submit" name="approve" value="1" class="phn-btn">Approve</button>
				<button type="submit" name="approve" value="0" class="phn-btn secondary">Decline</button>
			</form>
		</article>
	<?php endforeach; ?>
</section>
<?php endif; ?>

<?php if ($channel === 'user'): ?>
<div class="phn-chat-layout">
	<aside>
		<p class="phn-muted" style="margin:0 0 0.5rem;font-size:0.8rem;">Members</p>
		<ul class="phn-member-threads">
			<?php if (!$memberThreads): ?>
				<li class="phn-muted">No member chats yet.</li>
			<?php else: ?>
				<?php foreach ($memberThreads as $mt): ?>
					<li>
						<a class="<?php echo (int) $mt['member_id'] === $threadMember ? 'on' : ''; ?>" href="chat.php?channel=user&amp;member_id=<?php echo (int) $mt['member_id']; ?>">
							<?php echo htmlspecialchars(trim($mt['first_name'] . ' ' . ($mt['last_name'] ?? '')), ENT_QUOTES, 'UTF-8'); ?>
						</a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</aside>
	<div>
		<?php if ($threadMember > 0): ?>
			<?php mc_chat_render_bubbles($messages, 'pharmacist'); ?>
			<?php mc_chat_render_composer('Reply to member…', ['channel' => 'user', 'member_id' => (string) $threadMember]); ?>
		<?php else: ?>
			<p class="phn-muted">Select a member conversation.</p>
		<?php endif; ?>
	</div>
</div>
<?php else: ?>
	<?php mc_chat_render_bubbles($messages, 'pharmacist'); ?>
	<?php mc_chat_render_composer($channel === 'admin' ? 'Reply to pharmacy admin…' : 'Reply…', ['channel' => $channel]); ?>
<?php endif; ?>

<script src="../js/mc-star-rating.js" defer></script>
<?php mc_ph_network_shell_end(); ?>
