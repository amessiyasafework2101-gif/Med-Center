<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/require_pharmacist_approved.php';
require_once dirname(__DIR__) . '/includes/pharmacist_network_shell.php';

$pid = (int) $_SESSION['mc_pharmacist_id'];
$p = mc_pharmacist_load($conn, $pid);
$display = trim((string) ($p['first_name'] ?? '') . ' ' . (string) ($p['last_name'] ?? ''));

mc_ph_network_shell_start('Network home', 'home', $display);
?>
<div class="phn-cards">
	<article class="phn-card">
		<span class="phn-kpi-label">Performance</span>
		<strong><?php echo number_format((float) ($p['performance_score'] ?? 0), 2); ?></strong>
		<small><?php echo (int) ($p['rating_count'] ?? 0); ?> ratings</small>
	</article>
	<article class="phn-card">
		<span class="phn-kpi-label">Status</span>
		<strong>Approved</strong>
		<small>Network access active</small>
	</article>
</div>
<p class="phn-muted">Use <strong>Messages</strong> to chat with members and pharmacy admins. Check <strong>Work offers</strong> for opportunities — when you accept, the pharmacy admin can add you to their team.</p>
<p class="phn-muted"><a class="phn-link" href="../ai/index.php">Open Dr. Aklilu AI</a> for clinical guidance anytime — CV and license optional.</p>
<?php
mc_ph_network_shell_end();
