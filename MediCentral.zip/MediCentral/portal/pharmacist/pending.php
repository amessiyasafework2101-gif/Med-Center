<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';
require_once dirname(__DIR__) . '/includes/auth_helpers.php';

mc_session_start();
mc_set_signin_portal('network');
$pid = (int) ($_SESSION['mc_pharmacist_id'] ?? 0);
if (($_SESSION['mc_role'] ?? '') !== 'pharmacist' || $pid <= 0) {
	header('Location: ../index.php');
	exit;
}
$p = mc_pharmacist_load($conn, $pid);
if ($p && mc_pharmacist_is_approved($p)) {
	header('Location: index.php');
	exit;
}
$status = (string) ($p['approval_status'] ?? 'pending');
$hasCredentials = trim((string) ($p['cv_summary'] ?? '')) !== '' || trim((string) ($p['license_number'] ?? '')) !== '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Application pending · MediCentral</title>
	<link rel="stylesheet" href="../css/signin.css">
	<link rel="stylesheet" href="../css/dr-aklilu.css">
</head>
<body class="mc-hub-body" style="min-height:100vh;">
	<div class="mc-wrap" style="max-width:640px;margin:2rem auto;padding-bottom:5rem;">
		<div class="mc-signin-card">
			<h2 class="mc-title">Application <?php echo htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?></h2>
			<?php if ($hasCredentials): ?>
				<p class="mc-sub">Your CV and/or license are being reviewed. Full network features unlock after administrator approval.</p>
			<?php else: ?>
				<p class="mc-sub">You can use <strong>Dr. Aklilu</strong> below for clinical guidance while you complete your profile or wait for optional verification.</p>
			<?php endif; ?>
			<p class="mc-sub" style="margin-top:1rem;">
				<a class="mc-btn mc-btn-inline" href="../ai/index.php" style="display:inline-block;text-decoration:none;">Open Dr. Aklilu AI</a>
			</p>
			<p class="mc-sub">Or use the chat button at the bottom-right for quick questions.</p>
			<p class="mc-mini-link"><a href="../index.php">Home</a> · <a href="../about.php">About</a> · <a href="../contact.php">Contact</a> · <a href="../logout.php?to=network">Sign out</a></p>
		</div>
	</div>
	<?php
	require_once dirname(__DIR__) . '/includes/dr_aklilu_panel.php';
	mc_dr_aklilu_render_panel('network', '../');
	?>
	<script src="../js/dr-aklilu-format.js" defer></script>
	<script src="../js/dr-aklilu.js" defer></script>
</body>
</html>
