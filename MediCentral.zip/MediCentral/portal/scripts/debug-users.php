<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';

echo "=== mc_members ===\n";
$r = $conn->query('SELECT member_id, username, is_active, LEFT(password_hash,20) AS ph FROM mc_members');
while ($row = $r->fetch_assoc()) {
	echo json_encode($row) . "\n";
}
echo "=== mc_pharmacists ===\n";
$r = $conn->query('SELECT pharmacist_id, username, is_active, approval_status, LEFT(password_hash,20) AS ph FROM mc_pharmacists');
while ($row = $r->fetch_assoc()) {
	echo json_encode($row) . "\n";
}
