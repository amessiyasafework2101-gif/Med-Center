# Downloads Mozilla CA bundle for Dr. Aklilu / Cursor API (fixes WAMP SSL errors).
$dest = Join-Path $PSScriptRoot '..\includes\cacert.pem'
$uri = 'https://curl.se/ca/cacert.pem'
Write-Host "Downloading CA bundle to $dest ..."
Invoke-WebRequest -Uri $uri -OutFile $dest -UseBasicParsing
if (Test-Path $dest) {
    Write-Host "Done. Restart Apache in WAMP and try Dr. Aklilu again."
} else {
    Write-Host "Download failed. Save cacert.pem manually from $uri"
    exit 1
}
