<?php

declare(strict_types=1);

/**
 * CLI/browser diagnostic for Dr. Aklilu → Cursor API.
 * Run: php scripts/test-dr-aklilu-api.php
 * Or open: http://localhost/MediCentral/portal/scripts/test-dr-aklilu-api.php
 */

require_once dirname(__DIR__) . '/includes/cursor_config.php';
require_once dirname(__DIR__) . '/includes/curl_ssl.php';
require_once dirname(__DIR__) . '/includes/dr_aklilu.php';

header('Content-Type: text/plain; charset=utf-8');

$apiKey = mc_cursor_api_key();
echo "API key configured: " . ($apiKey !== '' ? 'yes (' . strlen($apiKey) . ' chars)' : 'NO') . "\n";
echo "CA bundle: " . (mc_curl_ca_bundle_path() ?? 'not found') . "\n";
echo "Model: " . mc_cursor_model_id() . "\n\n";

if ($apiKey === '') {
	echo "Set MC_CURSOR_API_KEY in includes/cursor_config.local.php\n";
	exit(1);
}

echo "1) GET /v1/models ...\n";
$res = mc_cursor_api_json('GET', '/v1/models', null, $apiKey);
echo $res['ok'] ? "OK\n" : "FAIL: {$res['error']}\n";
if ($res['ok'] && isset($res['data']['models'])) {
	echo 'Models: ' . count((array) $res['data']['models']) . "\n";
}

echo "\n2) POST /v1/agents (short prompt) ...\n";
$body = [
	'prompt' => ['text' => 'Reply with exactly: MediCentral test OK'],
	'model' => ['id' => mc_cursor_model_id()],
];
$res = mc_cursor_api_json('POST', '/v1/agents', $body, $apiKey);
if (!$res['ok']) {
	echo "FAIL: {$res['error']}\n";
	if ($res['data'] !== []) {
		echo json_encode($res['data'], JSON_PRETTY_PRINT) . "\n";
	}
	exit(1);
}

$agentId = (string) ($res['data']['agent']['id'] ?? '');
$runId = (string) ($res['data']['run']['id'] ?? '');
echo "Agent: $agentId\nRun: $runId\n";

if ($agentId === '' || $runId === '') {
	echo "Unexpected response:\n" . json_encode($res['data'], JSON_PRETTY_PRINT) . "\n";
	exit(1);
}

echo "\n3) Poll run status (up to 60s) ...\n";
for ($i = 0; $i < 30; $i++) {
	sleep(2);
	$poll = mc_cursor_api_json(
		'GET',
		'/v1/agents/' . rawurlencode($agentId) . '/runs/' . rawurlencode($runId),
		null,
		$apiKey
	);
	if (!$poll['ok']) {
		echo "Poll error: {$poll['error']}\n";
		continue;
	}
	$status = (string) ($poll['data']['status'] ?? '');
	echo "  status=$status\n";
	if (in_array($status, ['FINISHED', 'FAILED', 'CANCELLED', 'ERROR'], true)) {
		echo json_encode($poll['data'], JSON_PRETTY_PRINT) . "\n";
		break;
	}
}

echo "\nDone.\n";
