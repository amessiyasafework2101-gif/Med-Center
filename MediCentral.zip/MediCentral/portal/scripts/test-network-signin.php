<?php

declare(strict_types=1);

/** CLI smoke test for network sign-in database integration. */
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/pharmacist_pro.php';

$failures = [];
$passes = [];

function check(bool $ok, string $label): void
{
	global $failures, $passes;
	if ($ok) {
		$passes[] = $label;
	} else {
		$failures[] = $label;
	}
}

check($conn instanceof mysqli && !$conn->connect_error, 'MySQL connection to medicentral');

$res = $conn->query("SHOW TABLES LIKE 'mc_members'");
check($res && $res->num_rows === 1, 'Table mc_members exists');

$res = $conn->query("SHOW TABLES LIKE 'mc_pharmacists'");
check($res && $res->num_rows === 1, 'Table mc_pharmacists exists');

$cols = [];
$r = $conn->query('SHOW COLUMNS FROM mc_members');
if ($r) {
	while ($row = $r->fetch_assoc()) {
		$cols[] = (string) $row['Field'];
	}
}
foreach (['member_id', 'username', 'password_hash', 'is_active', 'last_login_at'] as $c) {
	check(in_array($c, $cols, true), "mc_members column: {$c}");
}

$stmt = $conn->prepare(
	'SELECT member_id, password_hash FROM mc_members WHERE username = ? AND is_active = 1 LIMIT 1'
);
check($stmt !== false, 'Member login prepared statement');

$adminStmt = $conn->prepare('SELECT admin_id, password_hash FROM mc_admins WHERE username = ? LIMIT 1');
check($adminStmt !== false, 'Admin table query works');

$hasApproval = mc_pharmacist_has_approval_columns($conn);
$sql = $hasApproval
	? 'SELECT pharmacist_id, password_hash, approval_status, is_active FROM mc_pharmacists WHERE username = ? LIMIT 1'
	: 'SELECT pharmacist_id, password_hash, is_active FROM mc_pharmacists WHERE username = ? LIMIT 1';
$phStmt = $conn->prepare($sql);
check($phStmt !== false, 'Pharmacist network login prepared statement');

$testUser = 'admin';
$testPass = 'password';
$stmt = $conn->prepare('SELECT member_id, password_hash FROM mc_members WHERE username = ? LIMIT 1');
if ($stmt) {
	$stmt->bind_param('s', $testUser);
	$stmt->execute();
	$found = $stmt->fetch();
	$stmt->close();
	check($found === null || $found === false, 'admin is not a member username (expected)');
}

$stmt = $conn->prepare('SELECT admin_id, password_hash FROM mc_admins WHERE username = ? LIMIT 1');
if ($stmt) {
	$u = 'admin';
	$stmt->bind_param('s', $u);
	$stmt->execute();
	$aid = 0;
	$hash = '';
	$stmt->bind_result($aid, $hash);
	$found = $stmt->fetch();
	$stmt->close();
	$verify = $found && password_verify($testPass, $hash);
	check($verify, 'Default admin password verify (admin / password) — pharmacy portal only');
}

echo "MediCentral network sign-in DB check\n";
echo str_repeat('-', 40) . "\n";
foreach ($passes as $p) {
	echo "[PASS] {$p}\n";
}
foreach ($failures as $f) {
	echo "[FAIL] {$f}\n";
}
echo str_repeat('-', 40) . "\n";
echo count($passes) . ' passed, ' . count($failures) . " failed\n";
exit($failures === [] ? 0 : 1);
