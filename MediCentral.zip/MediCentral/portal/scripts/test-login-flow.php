<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/session.php';
require_once dirname(__DIR__) . '/includes/username_format.php';

echo 'SCRIPT_NAME: ' . ($_SERVER['SCRIPT_NAME'] ?? '') . PHP_EOL;
$_SERVER['SCRIPT_NAME'] = '/MediCentral/portal/index.php';
echo 'Session path (from index): ' . mc_portal_session_path() . PHP_EOL;
$_SERVER['SCRIPT_NAME'] = '/MediCentral/portal/member/index.php';
echo 'Session path (from member): ' . mc_portal_session_path() . PHP_EOL;

$stmt = $conn->prepare('SELECT member_id, password_hash FROM mc_members WHERE username = ? AND is_active = 1 LIMIT 1');
$user = 'nahi';
$stmt->bind_param('s', $user);
$stmt->execute();
$stmt->bind_result($mid, $hash);
echo 'Member nahi found: ' . ($stmt->fetch() ? 'yes id=' . $mid : 'no') . PHP_EOL;
$stmt->close();
