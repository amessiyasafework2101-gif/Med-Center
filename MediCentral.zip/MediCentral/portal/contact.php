<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/public_page.php';
require_once __DIR__ . '/includes/site_contact.php';

mc_session_start();

$error = '';
$success = false;
$name = '';
$email = '';
$phone = '';
$subject = '';
$body = '';

$role = (string) ($_SESSION['mc_role'] ?? '');
$refId = null;
$senderRole = 'guest';
if ($role === 'member' && (int) ($_SESSION['mc_member_id'] ?? 0) > 0) {
	$senderRole = 'member';
	$refId = (int) $_SESSION['mc_member_id'];
	require_once __DIR__ . '/includes/member_context.php';
	$p = mc_member_load_profile($conn, $refId);
	$name = trim((string) ($p['first_name'] ?? '') . ' ' . (string) ($p['last_name'] ?? ''));
	$email = (string) ($p['email'] ?? '');
} elseif ($role === 'pharmacist' && (int) ($_SESSION['mc_pharmacist_id'] ?? 0) > 0) {
	$senderRole = 'pharmacist';
	$refId = (int) $_SESSION['mc_pharmacist_id'];
	require_once __DIR__ . '/includes/pharmacist_pro.php';
	$ph = mc_pharmacist_load($conn, $refId);
	if ($ph) {
		$name = trim((string) ($ph['first_name'] ?? '') . ' ' . (string) ($ph['last_name'] ?? ''));
		$email = (string) ($ph['email'] ?? '');
		$phone = (string) ($ph['phone'] ?? '');
	}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_send'])) {
	$name = trim((string) ($_POST['name'] ?? ''));
	$email = trim((string) ($_POST['email'] ?? ''));
	$phone = trim((string) ($_POST['phone'] ?? ''));
	$subject = trim((string) ($_POST['subject'] ?? ''));
	$body = trim((string) ($_POST['body'] ?? ''));
	$result = mc_contact_submit($conn, [
		'name' => $name,
		'email' => $email,
		'phone' => $phone,
		'subject' => $subject,
		'body' => $body,
		'role' => $senderRole,
		'ref_id' => $refId ?? 0,
	]);
	if ($result['ok']) {
		$success = true;
		$subject = '';
		$body = '';
	} else {
		$error = $result['error'];
	}
}

mc_public_page_start('Contact us', 'contact', '');
?>
<section class="mc-pub-card mc-pub-contact">
	<h1>Contact us</h1>
	<p class="mc-pub-lead">Send a message to the MediCentral administrator. We typically respond within one business day.</p>

	<?php if ($success): ?>
		<div class="mc-pub-alert success" role="status">Thank you — your message was sent to the main administrator.</div>
	<?php endif; ?>
	<?php if ($error !== ''): ?>
		<div class="mc-pub-alert error" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
	<?php endif; ?>

	<form method="post" class="mc-pub-form">
		<input type="hidden" name="contact_send" value="1">
		<div class="mc-pub-field-row">
			<div class="mc-field">
				<input type="text" name="name" id="c_name" required maxlength="120" value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>" placeholder=" ">
				<label class="mc-float-label" for="c_name">Your name</label>
			</div>
			<div class="mc-field">
				<input type="email" name="email" id="c_email" required maxlength="120" value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>" placeholder=" ">
				<label class="mc-float-label" for="c_email">Email</label>
			</div>
		</div>
		<div class="mc-field">
			<input type="text" name="phone" id="c_phone" maxlength="40" value="<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>" placeholder=" ">
			<label class="mc-float-label" for="c_phone">Phone (optional)</label>
		</div>
		<div class="mc-field">
			<input type="text" name="subject" id="c_subject" required maxlength="200" value="<?php echo htmlspecialchars($subject, ENT_QUOTES, 'UTF-8'); ?>" placeholder=" ">
			<label class="mc-float-label" for="c_subject">Subject</label>
		</div>
		<div class="mc-field">
			<textarea name="body" id="c_body" rows="6" required minlength="10" placeholder=" "><?php echo htmlspecialchars($body, ENT_QUOTES, 'UTF-8'); ?></textarea>
			<label class="mc-float-label" for="c_body">Message</label>
		</div>
		<button type="submit" class="mc-btn">Send message</button>
	</form>
</section>
<?php mc_public_page_end(); ?>
