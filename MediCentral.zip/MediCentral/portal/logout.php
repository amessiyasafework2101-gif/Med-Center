<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/auth_helpers.php';

mc_session_start();

$to = isset($_GET['to']) ? (string) $_GET['to'] : '';
$target = mc_signout_target($to);

$_SESSION = [];
session_destroy();
mc_clear_session_cookie();
session_write_close();

header('Location: ' . $target);
exit;
