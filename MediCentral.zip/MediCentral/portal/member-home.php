<?php

declare(strict_types=1);

header('Location: member/index.php', true, 302);
exit;
